"""
app/db.py

Couche base de données. Utilise SQLite via le module standard `sqlite3`
pour la phase Pilot (aucune dépendance externe nécessaire — fonctionne
partout où Python 3 est installé, y compris sans accès internet).

MIGRATION VERS POSTGRESQL (recommandée avant la mise à l'échelle) :
Remplacez les appels sqlite3.connect() par psycopg2 ou SQLAlchemy avec
une URL PostgreSQL (ex: postgresql://user:pass@host/dbname). PostgreSQL
gère nativement les écritures concurrentes multi-thread — le verrou
Python ci-dessous (_write_lock) ne serait alors plus nécessaire.
"""

import sqlite3
import os
import threading

DB_PATH = os.environ.get("BUDDY_DB_PATH", "buddy_system.db")

_local = threading.local()

# CORRECTIF RÉEL (trouvé par les tests de cette session, en deux temps) :
# le serveur HTTP stdlib traite chaque requête sur un thread séparé.
# Un verrou limité aux seules écritures s'est révélé insuffisant : sous
# stdlib pur, sans pool de connexions, des lectures et écritures
# entrelacées entre threads déclenchaient encore des erreurs
# intermittentes `database is locked`. La solution retenue, simple et
# fiable pour le volume d'une phase Pilot : sérialiser TOUTE opération
# de base de données (lecture ET écriture) derrière un unique verrou
# Python. Ce n'est pas un goulot d'étranglement réel à cette échelle,
# et disparaît de toute façon lors de la migration vers PostgreSQL
# (qui gère nativement l'accès concurrent multi-thread).
_db_lock = threading.Lock()


def get_connection():
    """Une connexion par thread — nécessaire car le serveur HTTP stdlib
    traite chaque requête sur un thread dédié (voir server.py).

    Note : le mode WAL est activé UNE SEULE FOIS dans init_db() — il est
    persisté dans le fichier de base de données lui-même, donc chaque
    nouvelle connexion en hérite automatiquement. Le réémettre à chaque
    connexion (comme dans une version précédente de ce fichier) forçait
    une prise de verrou exclusif à chaque nouvelle requête et provoquait
    des erreurs `database is locked` sous charge — c'était la véritable
    cause du bug, pas l'absence de verrou Python."""
    if not hasattr(_local, "conn"):
        _local.conn = sqlite3.connect(DB_PATH, timeout=10)
        _local.conn.row_factory = sqlite3.Row
        _local.conn.execute("PRAGMA busy_timeout=10000;")
    return _local.conn


def execute_write(query: str, params: tuple = ()):
    """Point d'entrée pour toute écriture (INSERT/UPDATE/DELETE).
    Acquiert le verrou global avant d'écrire, commit, puis relâche.

    CORRECTIF CRITIQUE (cause racine réelle du bug `database is locked`,
    trouvée par les tests de cette session) : si `conn.execute()` lève une
    exception (ex: sqlite3.IntegrityError sur une clé API dupliquée),
    SQLite laisse une transaction implicite OUVERTE et NON validée sur
    cette connexion. Comme chaque thread garde sa propre connexion pour
    toute sa durée de vie sans jamais la fermer explicitement, cette
    transaction bloquée finissait par verrouiller le fichier pour TOUTES
    les écritures suivantes, même venant d'autres threads/connexions —
    d'où des échecs en cascade bien après l'erreur d'origine. Le
    `rollback()` explicite ci-dessous, systématique en cas d'échec,
    élimine ce verrou fantôme."""
    with _db_lock:
        conn = get_connection()
        try:
            conn.execute(query, params)
            conn.commit()
        except Exception:
            conn.rollback()
            raise


def execute_write_many(statements: list):
    """Exécute plusieurs (requête, params) dans UNE seule transaction —
    utilisé par insert_full_checkin() pour garantir que checkins,
    checkin_inputs et les 8 lignes de checkin_risk_scores sont écrits
    ensemble ou pas du tout (pas de risque_scores orphelins si l'écriture
    du checkin échoue à mi-chemin). Même politique de rollback explicite
    que execute_write() ci-dessus, pour la même raison (voir sa docstring)."""
    with _db_lock:
        conn = get_connection()
        try:
            for query, params in statements:
                conn.execute(query, params)
            conn.commit()
        except Exception:
            conn.rollback()
            raise


def execute_read(query: str, params: tuple = (), one: bool = False):
    """Point d'entrée pour toute lecture (SELECT). Passe par le même
    verrou global que execute_write — voir la note ci-dessus sur
    pourquoi les lectures sont elles aussi sérialisées ici."""
    with _db_lock:
        conn = get_connection()
        cursor = conn.execute(query, params)
        return cursor.fetchone() if one else cursor.fetchall()


SCHEMA = """
CREATE TABLE IF NOT EXISTS audit_log (
    id TEXT PRIMARY KEY,
    created_at TEXT NOT NULL,
    actor_type TEXT NOT NULL CHECK(actor_type IN ('admin','tenant','worker','system')),
    actor_ref TEXT,
    action TEXT NOT NULL,
    target_type TEXT,
    target_id TEXT,
    tenant_id TEXT,
    details TEXT
    -- ملاحظة تصميم متعمّدة: لا يُخزَّن أي رمز سري (PIN) أو محتوى بلاغ
    -- مجهول في هذا الجدول تحت أي ظرف — فقط البيانات الوصفية للحدث.
);

CREATE INDEX IF NOT EXISTS idx_audit_created_at ON audit_log(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_tenant ON audit_log(tenant_id);

CREATE TABLE IF NOT EXISTS tenants (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    api_key TEXT NOT NULL UNIQUE,
    rotation_cycle_days INTEGER NOT NULL DEFAULT 28,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS workers (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL REFERENCES tenants(id),
    employee_id TEXT NOT NULL,
    pin_salt TEXT NOT NULL,
    pin_hash TEXT NOT NULL,
    worker_id_hash TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_workers_tenant_employee ON workers(tenant_id, employee_id);
CREATE INDEX IF NOT EXISTS idx_workers_tenant ON workers(tenant_id);

CREATE TABLE IF NOT EXISTS checkins (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL REFERENCES tenants(id),
    worker_id_hash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    bprs_score REAL NOT NULL,
    risk_level TEXT NOT NULL CHECK(risk_level IN ('green','yellow','orange','red')),
    site_code TEXT
);

CREATE TABLE IF NOT EXISTS anonymous_reports (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL REFERENCES tenants(id),
    created_at TEXT NOT NULL,
    category TEXT NOT NULL CHECK(category IN ('mobbing','harassment','burnout','other')),
    site_code TEXT,
    message TEXT NOT NULL
    -- Volontairement : AUCUNE colonne d'identité de l'auteur. C'est la
    -- garantie technique de l'anonymat exigée par le mémoire (canal
    -- d'alerte sans stigmatisation).
);

CREATE INDEX IF NOT EXISTS idx_checkins_created_at ON checkins(created_at);
CREATE INDEX IF NOT EXISTS idx_checkins_tenant ON checkins(tenant_id);
CREATE INDEX IF NOT EXISTS idx_checkins_site ON checkins(site_code);
CREATE INDEX IF NOT EXISTS idx_reports_tenant ON anonymous_reports(tenant_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_tenants_api_key ON tenants(api_key);

-- ============================================================
-- PsychoTech Layer — إضافة إضافية فوق البنية المُختبرة أعلاه، لا تُعدّل
-- أي جدول موجود سابقاً (checkins يبقى كما هو تماماً لتفادي كسر أي
-- تكامل قديم مع 03_pwa_app أو 01_flutter_mobile_app). هذه الجداول
-- تُغذّى فقط من نقطة النهاية الجديدة /v1/checkins/full (حساب من
-- طرف الخادم)، وتبقى فارغة لأي تكامل ما يزال يستخدم
-- /v1/checkins/anonymous القديمة (حساب من طرف العميل).
-- ============================================================

CREATE TABLE IF NOT EXISTS checkin_inputs (
    checkin_id TEXT PRIMARY KEY REFERENCES checkins(id),
    tenant_id TEXT NOT NULL,
    physical_fatigue REAL NOT NULL,
    mental_fatigue REAL NOT NULL,
    sleep_disruption REAL NOT NULL,
    low_empowerment REAL NOT NULL,
    low_resilience REAL NOT NULL,
    isolation REAL NOT NULL,
    day_in_rotation_cycle INTEGER NOT NULL,
    days_since_last_checkin INTEGER NOT NULL,
    hours_worked_last_24h REAL NOT NULL,
    is_night_shift INTEGER NOT NULL,
    distance_from_family_km REAL NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS checkin_risk_scores (
    id TEXT PRIMARY KEY,
    checkin_id TEXT NOT NULL REFERENCES checkins(id),
    tenant_id TEXT NOT NULL,
    risk_id TEXT NOT NULL,
    score REAL NOT NULL,
    level TEXT NOT NULL CHECK(level IN ('green','yellow','orange','red')),
    site_code TEXT,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_risk_scores_tenant_risk_created ON checkin_risk_scores(tenant_id, risk_id, created_at);
CREATE INDEX IF NOT EXISTS idx_risk_scores_site ON checkin_risk_scores(site_code);
CREATE INDEX IF NOT EXISTS idx_risk_scores_checkin ON checkin_risk_scores(checkin_id);

-- ============================================================
-- Fatigue Engine — جدول منفصل عن checkin_risk_scores لأن الإرهاق
-- محرك فيزيولوجي/تشغيلي مستقل الغرض عن المخاطر الثمانية النفسية
-- (انظر app/fatigue_engine.py). يخزّن أيضاً worker_id_hash صراحة (غير
-- مخزَّن في checkin_risk_scores) لأن حساب المتوسط المتحرك لكل عامل على
-- حدة يحتاج تجميعاً بمفتاح العامل، لا التينانت فقط.
-- ============================================================

CREATE TABLE IF NOT EXISTS checkin_fatigue_scores (
    id TEXT PRIMARY KEY,
    checkin_id TEXT NOT NULL REFERENCES checkins(id),
    tenant_id TEXT NOT NULL,
    worker_id_hash TEXT NOT NULL,
    score REAL NOT NULL,
    level TEXT NOT NULL CHECK(level IN ('green','yellow','orange','red')),
    sleep_hours_used REAL NOT NULL,
    sleep_hours_is_estimated INTEGER NOT NULL,
    site_code TEXT,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_fatigue_worker_created ON checkin_fatigue_scores(tenant_id, worker_id_hash, created_at);
CREATE INDEX IF NOT EXISTS idx_fatigue_tenant_created ON checkin_fatigue_scores(tenant_id, created_at);

-- ============================================================
-- Buddy System — تعيين ومتابعة وتدخلات. جداول جديدة فقط، لا تعديل
-- على أي جدول موجود. مبني فوق checkins/checkin_risk_scores الموجودة
-- (قراءة فقط) لعرض حالة العامل الحالية للـBuddy Officer.
-- ============================================================

CREATE TABLE IF NOT EXISTS buddy_officers (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL,
    name TEXT NOT NULL,
    contact_info TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS buddy_assignments (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL,
    buddy_officer_id TEXT NOT NULL REFERENCES buddy_officers(id),
    worker_id_hash TEXT NOT NULL,
    assigned_at TEXT NOT NULL,
    unassigned_at TEXT,
    active INTEGER NOT NULL DEFAULT 1
);

CREATE INDEX IF NOT EXISTS idx_buddy_assign_worker ON buddy_assignments(tenant_id, worker_id_hash, active);
CREATE INDEX IF NOT EXISTS idx_buddy_assign_officer ON buddy_assignments(tenant_id, buddy_officer_id, active);

CREATE TABLE IF NOT EXISTS buddy_interventions (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL,
    buddy_officer_id TEXT NOT NULL REFERENCES buddy_officers(id),
    worker_id_hash TEXT NOT NULL,
    intervention_type TEXT NOT NULL,
    notes TEXT,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_buddy_interv_worker ON buddy_interventions(tenant_id, worker_id_hash, created_at);
CREATE INDEX IF NOT EXISTS idx_buddy_interv_officer ON buddy_interventions(tenant_id, buddy_officer_id, created_at);

CREATE TABLE IF NOT EXISTS buddy_notifications (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL,
    buddy_officer_id TEXT NOT NULL REFERENCES buddy_officers(id),
    worker_id_hash TEXT NOT NULL,
    previous_level TEXT,
    new_level TEXT NOT NULL,
    created_at TEXT NOT NULL,
    acknowledged INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_buddy_notif_officer ON buddy_notifications(tenant_id, buddy_officer_id, created_at);
"""


def seed_default_tenants_if_empty():
    """Crée des tenants de démonstration si la table est vide — pratique
    pour le développement local et les tests. En production, les tenants
    sont créés via /v1/admin/tenants (voir server.py)."""
    import uuid
    from datetime import datetime, timezone

    existing = execute_read("SELECT COUNT(*) as n FROM tenants", one=True)["n"]
    if existing > 0:
        return

    demo_tenants = [
        ("Sonatrach — Pilot CPH", "pilot-demo-key-2026", 28),
    ]
    for name, api_key, cycle in demo_tenants:
        execute_write(
            "INSERT INTO tenants (id, name, api_key, rotation_cycle_days, created_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (str(uuid.uuid4()), name, api_key, cycle, datetime.now(timezone.utc).isoformat()),
        )


def init_db():
    with _db_lock:
        conn = get_connection()
        conn.execute("PRAGMA journal_mode=WAL;")  # une seule fois, persisté dans le fichier
        conn.executescript(SCHEMA)
        conn.commit()
    seed_default_tenants_if_empty()


def create_tenant(name: str, api_key: str, rotation_cycle_days: int = 28):
    """Crée un nouveau tenant. Lève sqlite3.IntegrityError si la clé API
    existe déjà (contrainte UNIQUE sur tenants.api_key) — l'appelant
    (server.py) doit intercepter cette erreur et répondre 409 Conflict."""
    import uuid
    from datetime import datetime, timezone

    tenant_id = str(uuid.uuid4())
    execute_write(
        "INSERT INTO tenants (id, name, api_key, rotation_cycle_days, created_at) "
        "VALUES (?, ?, ?, ?, ?)",
        (tenant_id, name, api_key, rotation_cycle_days, datetime.now(timezone.utc).isoformat()),
    )
    return tenant_id


def list_tenants():
    """Renvoie tous les tenants SANS exposer leur clé API en clair
    (uniquement les 4 derniers caractères, pour identification visuelle
    sans risque de fuite si la réponse est journalisée quelque part)."""
    rows = execute_read(
        "SELECT id, name, api_key, rotation_cycle_days, created_at FROM tenants ORDER BY created_at"
    )
    return [
        {
            "id": r["id"],
            "name": r["name"],
            "api_key_suffix": "..." + r["api_key"][-4:] if len(r["api_key"]) >= 4 else "***",
            "rotation_cycle_days": r["rotation_cycle_days"],
            "created_at": r["created_at"],
        }
        for r in rows
    ]


def create_worker(tenant_id: str, employee_id: str, pin: str):
    """Provisionne un nouvel employé pour un tenant donné. Lève
    sqlite3.IntegrityError si (tenant_id, employee_id) existe déjà.

    Le PIN n'est JAMAIS stocké en clair : on génère un sel aléatoire par
    employé puis on hache (sel + PIN) avec SHA-256. `worker_id_hash` est
    l'identifiant anonymisé et STABLE utilisé ensuite dans checkins et
    anonymous_reports — dérivé lui aussi par hachage, jamais l'employee_id
    en clair."""
    import uuid
    import hashlib
    import secrets
    from datetime import datetime, timezone

    worker_id = str(uuid.uuid4())
    pin_salt = secrets.token_hex(16)
    pin_hash = hashlib.sha256((pin_salt + pin).encode("utf-8")).hexdigest()
    worker_id_hash = hashlib.sha256(f"{tenant_id}:{employee_id}".encode("utf-8")).hexdigest()

    execute_write(
        "INSERT INTO workers (id, tenant_id, employee_id, pin_salt, pin_hash, worker_id_hash, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (worker_id, tenant_id, employee_id, pin_salt, pin_hash, worker_id_hash,
         datetime.now(timezone.utc).isoformat()),
    )
    return {"id": worker_id, "workerIdHash": worker_id_hash}


def verify_worker_pin(tenant_id: str, employee_id: str, pin: str):
    """Vérifie les identifiants d'un employé. Renvoie
    {'id', 'workerIdHash'} si valides, sinon None. La comparaison du
    hash utilise hmac.compare_digest pour éviter les attaques par
    mesure de temps (timing attacks)."""
    import hashlib
    import hmac as hmac_module

    row = execute_read(
        "SELECT id, pin_salt, pin_hash, worker_id_hash FROM workers "
        "WHERE tenant_id = ? AND employee_id = ?",
        (tenant_id, employee_id),
        one=True,
    )
    if row is None:
        return None

    computed = hashlib.sha256((row["pin_salt"] + pin).encode("utf-8")).hexdigest()
    if not hmac_module.compare_digest(computed, row["pin_hash"]):
        return None

    return {"id": row["id"], "workerIdHash": row["worker_id_hash"]}


def log_audit_event(actor_type: str, action: str, actor_ref: str = None,
                     target_type: str = None, target_id: str = None,
                     tenant_id: str = None, details: str = None):
    """يُسجّل حدثاً في سجل التدقيق. يُستدعى من server.py عند كل إجراء
    إداري أو أمني حساس (إنشاء عميل، تزويد عامل، نجاح/قفل تسجيل دخول).
    لا يُمرَّر أبداً أي PIN أو محتوى بلاغ مجهول كـ details — فقط بيانات
    وصفية غير حساسة."""
    import uuid
    from datetime import datetime, timezone

    execute_write(
        "INSERT INTO audit_log (id, created_at, actor_type, actor_ref, action, target_type, target_id, tenant_id, details) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (str(uuid.uuid4()), datetime.now(timezone.utc).isoformat(), actor_type, actor_ref,
         action, target_type, target_id, tenant_id, details),
    )


def list_audit_log(limit: int = 100, tenant_id: str = None, action: str = None):
    query = "SELECT * FROM audit_log"
    conditions = []
    params = []
    if tenant_id:
        conditions.append("tenant_id = ?")
        params.append(tenant_id)
    if action:
        conditions.append("action = ?")
        params.append(action)
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
    query += " ORDER BY created_at DESC LIMIT ?"
    params.append(limit)

    rows = execute_read(query, tuple(params))
    return [dict(r) for r in rows]


def insert_full_checkin(tenant_id: str, worker_id_hash: str, created_at: str, site_code,
                         bprs_score: float, risk_level: str, inputs: dict, context: dict,
                         risk_scores: list, fatigue_score: dict = None):
    """Écrit le check-in complet (PsychoTech Layer) : la ligne checkins
    existante (compatible avec les endpoints/agrégats déjà testés) +
    les entrées brutes + les 8 scores par risque + le score de fatigue
    (Fatigue Engine, optionnel pour compatibilité ascendante), dans UNE
    transaction.

    `risk_scores` est une liste de dicts {id, score, level} (voir
    app/psychosocial_risks.py:RiskScore). `fatigue_score` est un dict
    {score, level, sleep_hours_used, sleep_hours_is_estimated} ou None."""
    import uuid
    from datetime import datetime, timezone

    checkin_id = str(uuid.uuid4())
    now = datetime.now(timezone.utc).isoformat()

    statements = [
        (
            "INSERT INTO checkins (id, tenant_id, worker_id_hash, created_at, bprs_score, risk_level, site_code) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (checkin_id, tenant_id, worker_id_hash, created_at, bprs_score, risk_level, site_code),
        ),
        (
            "INSERT INTO checkin_inputs (checkin_id, tenant_id, physical_fatigue, mental_fatigue, "
            "sleep_disruption, low_empowerment, low_resilience, isolation, day_in_rotation_cycle, "
            "days_since_last_checkin, hours_worked_last_24h, is_night_shift, distance_from_family_km, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                checkin_id, tenant_id,
                inputs["physical_fatigue"], inputs["mental_fatigue"], inputs["sleep_disruption"],
                inputs["low_empowerment"], inputs["low_resilience"], inputs["isolation"],
                context["day_in_rotation_cycle"], context["days_since_last_checkin"],
                context["hours_worked_last_24h"], 1 if context["is_night_shift"] else 0,
                context["distance_from_family_km"], now,
            ),
        ),
    ]
    for rs in risk_scores:
        statements.append((
            "INSERT INTO checkin_risk_scores (id, checkin_id, tenant_id, risk_id, score, level, site_code, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (str(uuid.uuid4()), checkin_id, tenant_id, rs["id"], rs["score"], rs["level"], site_code, now),
        ))

    if fatigue_score is not None:
        statements.append((
            "INSERT INTO checkin_fatigue_scores (id, checkin_id, tenant_id, worker_id_hash, score, level, "
            "sleep_hours_used, sleep_hours_is_estimated, site_code, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                str(uuid.uuid4()), checkin_id, tenant_id, worker_id_hash,
                fatigue_score["score"], fatigue_score["level"], fatigue_score["sleep_hours_used"],
                1 if fatigue_score["sleep_hours_is_estimated"] else 0, site_code, now,
            ),
        ))

    execute_write_many(statements)
    return checkin_id


def recent_fatigue_scores_for_worker(tenant_id: str, worker_id_hash: str, limit: int = 7):
    """آخر درجات إرهاق (الأحدث أولاً) لعامل بعينه — تغذّي المتوسط
    المتحرك في fatigue_engine.blend_with_rolling_average()."""
    rows = execute_read(
        "SELECT score FROM checkin_fatigue_scores WHERE tenant_id = ? AND worker_id_hash = ? "
        "ORDER BY created_at DESC LIMIT ?",
        (tenant_id, worker_id_hash, limit),
    )
    return [r["score"] for r in rows]


def worker_timeline(tenant_id: str, worker_id_hash: str, limit: int = 60):
    """السجل الزمني الكامل لعامل بعينه: BPRS + سياق الدورة + الإرهاق لكل
    نبضة عافية — يغذّي 'Timeline للعامل' (اليوم/الأسبوع/الدورة). ترتيب
    تنازلي (الأحدث أولاً)."""
    checkins = execute_read(
        "SELECT id, created_at, bprs_score, risk_level, site_code FROM checkins "
        "WHERE tenant_id = ? AND worker_id_hash = ? ORDER BY created_at DESC LIMIT ?",
        (tenant_id, worker_id_hash, limit),
    )
    if not checkins:
        return []

    checkin_ids = [c["id"] for c in checkins]
    placeholders = ",".join("?" * len(checkin_ids))

    inputs_rows = execute_read(
        f"SELECT * FROM checkin_inputs WHERE checkin_id IN ({placeholders})", tuple(checkin_ids)
    )
    inputs_by_checkin = {r["checkin_id"]: dict(r) for r in inputs_rows}

    fatigue_rows = execute_read(
        f"SELECT * FROM checkin_fatigue_scores WHERE checkin_id IN ({placeholders})", tuple(checkin_ids)
    )
    fatigue_by_checkin = {r["checkin_id"]: dict(r) for r in fatigue_rows}

    risk_rows = execute_read(
        f"SELECT * FROM checkin_risk_scores WHERE checkin_id IN ({placeholders})", tuple(checkin_ids)
    )
    risks_by_checkin = {}
    for r in risk_rows:
        risks_by_checkin.setdefault(r["checkin_id"], []).append(
            {"id": r["risk_id"], "score": r["score"], "level": r["level"]}
        )

    timeline = []
    for c in checkins:
        cid = c["id"]
        ctx_row = inputs_by_checkin.get(cid)
        fatigue_row = fatigue_by_checkin.get(cid)
        timeline.append({
            "checkinId": cid,
            "createdAt": c["created_at"],
            "siteCode": c["site_code"],
            "bprs": {"score": c["bprs_score"], "level": c["risk_level"]},
            "dayInRotationCycle": ctx_row["day_in_rotation_cycle"] if ctx_row else None,
            "risks": risks_by_checkin.get(cid, []),
            "fatigue": (
                {"score": fatigue_row["score"], "level": fatigue_row["level"]}
                if fatigue_row else None
            ),
        })
    return timeline


def latest_risk_scores(tenant_id: str, since_iso: str, site_code: str = None):
    """Pour chaque risk_id, renvoie le dernier score connu (le plus
    récent) dans la fenêtre temporelle donnée — alimente les pastilles
    de couleur en temps réel du tableau /v1/dashboard/risks."""
    query = ("SELECT risk_id, score, level, created_at FROM checkin_risk_scores "
             "WHERE tenant_id = ? AND created_at >= ?")
    params = [tenant_id, since_iso]
    if site_code:
        query += " AND site_code = ?"
        params.append(site_code)
    query += " ORDER BY created_at ASC"
    rows = execute_read(query, tuple(params))
    latest = {}
    for r in rows:
        latest[r["risk_id"]] = {"score": r["score"], "level": r["level"], "created_at": r["created_at"]}
    return latest


def average_risk_scores(tenant_id: str, since_iso: str, site_code: str = None):
    """Moyenne par risk_id sur la période — utilisé en complément du
    'dernier score' pour donner une tendance, pas juste un instantané."""
    query = ("SELECT risk_id, AVG(score) as avg_score, COUNT(*) as n FROM checkin_risk_scores "
             "WHERE tenant_id = ? AND created_at >= ?")
    params = [tenant_id, since_iso]
    if site_code:
        query += " AND site_code = ?"
        params.append(site_code)
    query += " GROUP BY risk_id"
    rows = execute_read(query, tuple(params))
    return {r["risk_id"]: {"avg_score": round(r["avg_score"], 1), "n": r["n"]} for r in rows}


def weekly_risk_trend(tenant_id: str, risk_id: str, start_iso: str, end_iso: str, site_code: str = None):
    query = ("SELECT AVG(score) as avg_score, COUNT(*) as n FROM checkin_risk_scores "
             "WHERE tenant_id = ? AND risk_id = ? AND created_at >= ? AND created_at < ?")
    params = [tenant_id, risk_id, start_iso, end_iso]
    if site_code:
        query += " AND site_code = ?"
        params.append(site_code)
    return execute_read(query, tuple(params), one=True)


def create_buddy_officer(tenant_id: str, name: str, contact_info: str = None):
    import uuid
    from datetime import datetime, timezone
    officer_id = str(uuid.uuid4())
    execute_write(
        "INSERT INTO buddy_officers (id, tenant_id, name, contact_info, created_at) VALUES (?, ?, ?, ?, ?)",
        (officer_id, tenant_id, name, contact_info, datetime.now(timezone.utc).isoformat()),
    )
    return officer_id


def list_buddy_officers(tenant_id: str):
    return execute_read(
        "SELECT id, name, contact_info, created_at FROM buddy_officers WHERE tenant_id = ? ORDER BY created_at DESC",
        (tenant_id,),
    )


def get_buddy_officer(tenant_id: str, officer_id: str):
    return execute_read(
        "SELECT id, name, contact_info FROM buddy_officers WHERE tenant_id = ? AND id = ?",
        (tenant_id, officer_id), one=True,
    )


def assign_buddy_officer(tenant_id: str, buddy_officer_id: str, worker_id_hash: str):
    """يدعم إعادة التعيين: أي تعيين نشط سابق لنفس العامل يُغلَق
    (active=0, unassigned_at) قبل إنشاء تعيين جديد نشط — سجل تاريخي
    كامل، لا استبدال صامت."""
    import uuid
    from datetime import datetime, timezone
    now = datetime.now(timezone.utc).isoformat()
    assignment_id = str(uuid.uuid4())

    statements = [
        (
            "UPDATE buddy_assignments SET active = 0, unassigned_at = ? "
            "WHERE tenant_id = ? AND worker_id_hash = ? AND active = 1",
            (now, tenant_id, worker_id_hash),
        ),
        (
            "INSERT INTO buddy_assignments (id, tenant_id, buddy_officer_id, worker_id_hash, assigned_at, active) "
            "VALUES (?, ?, ?, ?, ?, 1)",
            (assignment_id, tenant_id, buddy_officer_id, worker_id_hash, now),
        ),
    ]
    execute_write_many(statements)
    return assignment_id


def get_active_buddy_assignment(tenant_id: str, worker_id_hash: str):
    return execute_read(
        "SELECT id, buddy_officer_id, assigned_at FROM buddy_assignments "
        "WHERE tenant_id = ? AND worker_id_hash = ? AND active = 1",
        (tenant_id, worker_id_hash), one=True,
    )


def buddy_workers_with_status(tenant_id: str, buddy_officer_id: str, level_filter: str = None):
    """قائمة عمال Buddy Officer معيّن، مع آخر BPRS/مستوى/أبرز مخاطره —
    قراءة فقط من checkins/checkin_risk_scores الموجودة، بلا أي تعديل
    عليها."""
    assignments = execute_read(
        "SELECT worker_id_hash, assigned_at FROM buddy_assignments "
        "WHERE tenant_id = ? AND buddy_officer_id = ? AND active = 1 ORDER BY assigned_at DESC",
        (tenant_id, buddy_officer_id),
    )
    results = []
    for a in assignments:
        worker_hash = a["worker_id_hash"]
        latest = execute_read(
            "SELECT id, created_at, bprs_score, risk_level FROM checkins "
            "WHERE tenant_id = ? AND worker_id_hash = ? ORDER BY created_at DESC LIMIT 1",
            (tenant_id, worker_hash), one=True,
        )
        if latest is None:
            entry = {
                "workerIdHash": worker_hash, "assignedAt": a["assigned_at"],
                "status": "no_data", "bprs": None, "topRisks": [],
            }
        else:
            if level_filter and latest["risk_level"] != level_filter:
                continue
            top_risks = execute_read(
                "SELECT risk_id, score, level FROM checkin_risk_scores "
                "WHERE checkin_id = ? ORDER BY score DESC LIMIT 3",
                (latest["id"],),
            )
            entry = {
                "workerIdHash": worker_hash, "assignedAt": a["assigned_at"],
                "status": "ok",
                "bprs": {"score": latest["bprs_score"], "level": latest["risk_level"], "asOf": latest["created_at"]},
                "topRisks": [{"id": r["risk_id"], "score": r["score"], "level": r["level"]} for r in top_risks],
            }
        results.append(entry)
    return results


def insert_buddy_intervention(tenant_id: str, buddy_officer_id: str, worker_id_hash: str,
                               intervention_type: str, notes: str, created_at: str):
    import uuid
    intervention_id = str(uuid.uuid4())
    execute_write(
        "INSERT INTO buddy_interventions (id, tenant_id, buddy_officer_id, worker_id_hash, "
        "intervention_type, notes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (intervention_id, tenant_id, buddy_officer_id, worker_id_hash, intervention_type, notes, created_at),
    )
    return intervention_id


def list_buddy_interventions_for_worker(tenant_id: str, worker_id_hash: str):
    rows = execute_read(
        "SELECT bi.id, bi.buddy_officer_id, bo.name as officer_name, bi.intervention_type, "
        "bi.notes, bi.created_at FROM buddy_interventions bi "
        "JOIN buddy_officers bo ON bo.id = bi.buddy_officer_id "
        "WHERE bi.tenant_id = ? AND bi.worker_id_hash = ? ORDER BY bi.created_at DESC",
        (tenant_id, worker_id_hash),
    )
    return [dict(r) for r in rows]


def get_latest_checkin_level(tenant_id: str, worker_id_hash: str):
    """يُستدعى *قبل* إدراج نبضة عافية جديدة، لمعرفة المستوى السابق —
    يُستخدَم لكشف التصعيد (أخضر→أصفر/برتقالي/أحمر) وإنشاء إشعار."""
    row = execute_read(
        "SELECT risk_level FROM checkins WHERE tenant_id = ? AND worker_id_hash = ? "
        "ORDER BY created_at DESC LIMIT 1",
        (tenant_id, worker_id_hash), one=True,
    )
    return row["risk_level"] if row else None


def insert_buddy_notification(tenant_id: str, buddy_officer_id: str, worker_id_hash: str,
                               previous_level, new_level: str):
    import uuid
    from datetime import datetime, timezone
    notif_id = str(uuid.uuid4())
    execute_write(
        "INSERT INTO buddy_notifications (id, tenant_id, buddy_officer_id, worker_id_hash, "
        "previous_level, new_level, created_at, acknowledged) VALUES (?, ?, ?, ?, ?, ?, ?, 0)",
        (notif_id, tenant_id, buddy_officer_id, worker_id_hash, previous_level, new_level,
         datetime.now(timezone.utc).isoformat()),
    )
    return notif_id


def list_buddy_notifications(tenant_id: str, buddy_officer_id: str, limit: int = 50):
    rows = execute_read(
        "SELECT id, worker_id_hash, previous_level, new_level, created_at, acknowledged "
        "FROM buddy_notifications WHERE tenant_id = ? AND buddy_officer_id = ? "
        "ORDER BY created_at DESC LIMIT ?",
        (tenant_id, buddy_officer_id, limit),
    )
    return [dict(r) for r in rows]


def reset_db_for_tests():
    """Utilisé uniquement par la suite de tests — supprime le fichier
    de base de données pour repartir d'un état propre."""
    if hasattr(_local, "conn"):
        _local.conn.close()
        del _local.conn
    for suffix in ("", "-wal", "-shm"):
        path = DB_PATH + suffix
        if os.path.exists(path):
            os.remove(path)
