#!/usr/bin/env bash
set -euo pipefail

fail() { echo "ERROR: $*" >&2; exit 1; }

[[ -f pubspec.yaml ]] || fail "Run from 01_flutter_mobile_app."
command -v flutter >/dev/null || fail "Flutter SDK is not installed or not on PATH."
command -v dart >/dev/null || fail "Dart SDK is not installed or not on PATH."

flutter --version
flutter doctor -v
flutter pub get
dart run build_runner build --delete-conflicting-outputs
test -s lib/models/daily_checkin.g.dart
test -s lib/models/anonymous_report.g.dart
flutter analyze
flutter test

cd android
if [[ ! -s gradle/wrapper/gradle-wrapper.jar ]]; then
  if command -v gradle >/dev/null; then
    gradle wrapper --gradle-version 8.6 --distribution-type all
  else
    fail "gradle-wrapper.jar is missing and Gradle is unavailable. In CI use gradle/actions/setup-gradle."
  fi
fi
test -s gradle/wrapper/gradle-wrapper.jar
./gradlew :app:assembleDebug --no-daemon --stacktrace
cd ..

flutter build apk --debug

echo "PASS: Flutter analysis, tests, Android Gradle build and APK build completed."
