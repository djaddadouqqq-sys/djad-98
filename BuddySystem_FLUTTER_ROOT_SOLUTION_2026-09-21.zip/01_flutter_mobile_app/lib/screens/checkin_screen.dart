/// lib/screens/checkin_screen.dart
/// "نبض العافية اليومي" — MVP scope 2/3.
/// Écran le plus important du projet : 4 sliders, moins de 30 secondes,
/// calcul BPRS immédiat et local, écriture Hive optimiste.
library checkin_screen;

import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';

import '../models/daily_checkin.dart';
import '../services/bprs_engine.dart';
import '../services/providers.dart';
import 'entry_screen.dart' show BuddyColors;

class CheckinScreen extends ConsumerStatefulWidget {
  const CheckinScreen({super.key});

  @override
  ConsumerState<CheckinScreen> createState() => _CheckinScreenState();
}

class _CheckinScreenState extends ConsumerState<CheckinScreen> {
  double _physicalFatigue = 3;
  double _mentalFatigue = 3;
  double _sleepQuality = 6;
  double _empowerment = 6;
  double _resilience = 6;
  double _isolation = 3;

  // 🆕 Contexte de rotation — désormais saisi réellement par l'utilisateur
  // (auparavant des constantes en dur non éditables). Valeurs par défaut
  // raisonnables conservées pour ne pas allonger le MVP inutilement.
  double _dayInCycle = 14;
  double _hoursWorked = 10;
  bool _nightShift = false;
  double _distanceKm = 750;
  double? _sleepHours; // optionnel — Fatigue Engine

  bool _saved = false;
  bool _submitting = false;
  BprsResult? _result;
  Map<String, dynamic>? _serverResult;

  Future<void> _submit() async {
    if (_submitting) return;
    setState(() => _submitting = true);
    try {
      final storage = ref.read(localStorageProvider);
      final workerAuth = ref.read(workerAuthServiceProvider);
      final workerIdHash = await workerAuth.getEffectiveWorkerIdHash();

      final inputs = BprsInputs(
        physicalFatigue: _physicalFatigue,
        mentalFatigue: _mentalFatigue,
        sleepDisruption: 10 - _sleepQuality,
        lowEmpowerment: 10 - _empowerment,
        lowResilience: 10 - _resilience,
        isolation: _isolation,
      );

      final daysSinceAtEntry = storage.daysSinceLastCheckin();
      final rotationContext = RotationContext(
        dayInRotationCycle: _dayInCycle.round(),
        daysSinceLastCheckin: daysSinceAtEntry,
        hoursWorkedLast24h: _hoursWorked,
        isNightShift: _nightShift,
        distanceFromFamilyKm: _distanceKm,
      );

      final localResult = BprsEngine.compute(
        declarativeInputs: inputs,
        rotationContext: rotationContext,
      );

      final checkin = DailyCheckin(
        id: const Uuid().v4(),
        workerIdHash: workerIdHash,
        createdAt: DateTime.now(),
        physicalFatigue: _physicalFatigue,
        mentalFatigue: _mentalFatigue,
        sleepQuality: _sleepQuality,
        empowermentFeeling: _empowerment,
        resilienceFeeling: _resilience,
        isolationFeeling: _isolation,
        bprsScoreAtEntry: localResult.score,
        riskLevelAtEntry: localResult.level.name,
        dayInRotationCycle: _dayInCycle.round(),
        daysSinceLastCheckinAtEntry: daysSinceAtEntry,
        hoursWorkedLast24h: _hoursWorked,
        isNightShift: _nightShift,
        distanceFromFamilyKm: _distanceKm,
        sleepHoursLast24h: _sleepHours,
      );

      await storage.saveCheckin(checkin);

      // إذا كان الخادم متاحاً، انتظر النتيجة الرسمية فوراً. إذا كان
      // الاتصال غير متاح، يبقى التسجيل محلياً ويُزامن لاحقاً.
      final sync = ref.read(syncServiceProvider);
      final serverResult = await sync.pushSingleCheckin(checkin);

      if (!mounted) return;
      setState(() {
        _saved = true;
        _result = localResult;
        _serverResult = serverResult;
      });

      if (serverResult == null) {
        unawaited(sync.syncPendingCheckins());
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  Widget _slider(String label, double value, ValueChanged<double> onChanged,
      {String lowHint = '', String highHint = '', double min = 0, double max = 10, int? divisions}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(value.toStringAsFixed(max > 20 ? 0 : 1),
                  style: const TextStyle(fontWeight: FontWeight.w800, color: BuddyColors.navy)),
              Text(label,
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
            ],
          ),
          Slider(
            value: value,
            min: min,
            max: max,
            divisions: divisions ?? 10,
            activeColor: BuddyColors.sage,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: BuddyColors.paper,
      appBar: AppBar(
        backgroundColor: BuddyColors.paper,
        elevation: 0,
        title: const Text('نبض العافية اليومي',
            style: TextStyle(color: BuddyColors.navy, fontWeight: FontWeight.w800)),
        iconTheme: const IconThemeData(color: BuddyColors.navy),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: _saved && _result != null
            ? _buildResult(_result!)
            : ListView(
                children: [
                  _slider('الإرهاق الجسدي', _physicalFatigue,
                      (v) => setState(() => _physicalFatigue = v)),
                  _slider('الإرهاق الذهني', _mentalFatigue,
                      (v) => setState(() => _mentalFatigue = v)),
                  _slider('جودة النوم', _sleepQuality,
                      (v) => setState(() => _sleepQuality = v)),
                  _slider('الشعور بالتمكين', _empowerment,
                      (v) => setState(() => _empowerment = v)),
                  _slider('الشعور بالصمود', _resilience,
                      (v) => setState(() => _resilience = v)),
                  _slider('الشعور بالعزلة', _isolation,
                      (v) => setState(() => _isolation = v)),
                  const SizedBox(height: 8),
                  const Text('سياق الدورة (يُرسَل رسمياً للخادم)',
                      style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5, color: BuddyColors.navy)),
                  const SizedBox(height: 6),
                  _slider('يوم الدورة (1-28)', _dayInCycle,
                      (v) => setState(() => _dayInCycle = v),
                      min: 1, max: 28, divisions: 27),
                  _slider('ساعات العمل آخر 24 ساعة', _hoursWorked,
                      (v) => setState(() => _hoursWorked = v),
                      min: 0, max: 24, divisions: 48),
                  _slider('البعد عن الأسرة (كم)', _distanceKm,
                      (v) => setState(() => _distanceKm = v),
                      min: 0, max: 2000, divisions: 40),
                  SwitchListTile(
                    value: _nightShift,
                    onChanged: (v) => setState(() => _nightShift = v),
                    activeColor: BuddyColors.sage,
                    title: const Text('مناوبة ليلية', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700)),
                    contentPadding: EdgeInsets.zero,
                  ),
                  const SizedBox(height: 4),
                  const Text('ساعات النوم الفعلية (اختياري — محرك الإرهاق)',
                      style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                  TextField(
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(hintText: 'اتركه فارغاً إن لم تكن متأكداً'),
                    onChanged: (v) => _sleepHours = double.tryParse(v),
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: _submitting ? null : _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: BuddyColors.terracotta,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 15),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(11),
                      ),
                    ),
                    child: Text(_submitting ? 'جارٍ الإرسال...' : 'إرسال', style: const TextStyle(fontWeight: FontWeight.w800)),
                  ),
                ],
              ),
      ),
    );
  }

  Color _levelColor(String level) {
    switch (level) {
      case 'green':
        return BuddyColors.sage;
      case 'yellow':
        return const Color(0xFFD8B34E);
      case 'orange':
        return BuddyColors.terracotta;
      case 'red':
      default:
        return const Color(0xFFB8544A);
    }
  }

  Widget _buildResult(BprsResult localResult) {
    final server = _serverResult;
    final bprs = server?['bprs'] as Map<String, dynamic>?;
    final risks = (server?['risks'] as List<dynamic>?) ?? const [];
    final officialScore = (bprs?['score'] as num?)?.toDouble();
    final officialLevel = bprs?['level'] as String?;
    final isOfficial = bprs != null && officialScore != null && officialLevel != null;
    final score = isOfficial ? officialScore! : localResult.score;
    final level = isOfficial ? officialLevel! : localResult.level.name;
    final label = isOfficial
        ? (bprs?['levelLabelAr'] as String? ?? level)
        : localResult.levelLabelAr;
    final urgent = server?['urgent'] == true;

    return ListView(
      children: [
        Center(
          child: Column(
            children: [
              Text(score.toStringAsFixed(0),
                  style: const TextStyle(fontSize: 48, fontWeight: FontWeight.w800, color: BuddyColors.navy)),
              const SizedBox(height: 6),
              Text(label, style: TextStyle(fontWeight: FontWeight.w800, color: _levelColor(level))),
              const SizedBox(height: 5),
              Text(isOfficial ? 'نتيجة رسمية من الخادم' : 'تقدير محلي — بانتظار المزامنة',
                  style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700,
                      color: isOfficial ? BuddyColors.sage : BuddyColors.terracotta)),
            ],
          ),
        ),
        if (urgent) ...[
          const SizedBox(height: 14),
          Card(
            color: const Color(0xFFFFE8E5),
            child: const Padding(
              padding: EdgeInsets.all(14),
              child: Text('🚨 توجد إشارة حمراء تستدعي التصعيد وفق نتيجة الخادم.',
                  style: TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF9E3E35))),
            ),
          ),
        ],
        if (risks.isNotEmpty) ...[
          const SizedBox(height: 14),
          const Text('المخاطر النفسية-الاجتماعية الثمانية',
              style: TextStyle(fontWeight: FontWeight.w800, color: BuddyColors.navy)),
          const SizedBox(height: 8),
          ...risks.map((raw) {
            final risk = raw as Map<String, dynamic>;
            final riskLevel = risk['level'] as String? ?? 'green';
            final riskScore = (risk['score'] as num?)?.toDouble() ?? 0;
            final reasons = (risk['reasons'] as List<dynamic>?) ?? const [];
            return Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text('${risk['icon'] ?? ''} ', style: const TextStyle(fontSize: 18)),
                        Expanded(child: Text(risk['nameAr']?.toString() ?? risk['id'].toString(),
                            style: const TextStyle(fontWeight: FontWeight.w800))),
                        Text(riskScore.toStringAsFixed(1),
                            style: TextStyle(fontWeight: FontWeight.w800, color: _levelColor(riskLevel))),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(risk['levelLabelAr']?.toString() ?? riskLevel,
                        style: TextStyle(fontSize: 11, color: _levelColor(riskLevel), fontWeight: FontWeight.w700)),
                    if (reasons.isNotEmpty) ...[
                      const SizedBox(height: 5),
                      ...reasons.map((reason) => Text('• $reason',
                          style: const TextStyle(fontSize: 10.5, color: BuddyColors.inkSoft))),
                    ],
                  ],
                ),
              ),
            );
          }),
        ],
        if (!isOfficial && localResult.passiveRiskFactors.isNotEmpty) ...[
          const SizedBox(height: 8),
          const Text('عوامل رفعت المؤشر محلياً:', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
          const SizedBox(height: 5),
          ...localResult.passiveRiskFactors.map((r) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 2),
                child: Text('• $r', textAlign: TextAlign.right,
                    style: const TextStyle(fontSize: 11.5, color: BuddyColors.inkSoft)),
              )),
        ],
        const SizedBox(height: 20),
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('عودة للرئيسية',
              style: TextStyle(color: BuddyColors.sage, fontWeight: FontWeight.w700)),
        ),
      ],
    );
  }

}
