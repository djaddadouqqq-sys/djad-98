/// lib/services/sync_service.dart
///
/// Couche de synchronisation. Détecte le retour de connectivité (Wi-Fi de
/// la base de vie) et transmet les données vers le serveur central.
///
/// ⚠️ MISE À JOUR : ce fichier appelle désormais POST /v1/checkins/full
/// (pas /v1/checkins/anonymous) — le serveur recalcule BPRS + les 8
/// risques + le moteur de fatigue à partir des valeurs brutes (voir
/// DailyCheckin.toFullCheckinPayload()), source de vérité unique cohérente
/// avec 03_pwa_app et 04_website/worker_unified.html. L'ancien endpoint
/// reste fonctionnel côté serveur (compatibilité ascendante), simplement
/// plus appelé par ce client.
library sync_service;

import 'dart:convert';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:http/http.dart' as http;

import '../models/daily_checkin.dart';
import 'local_storage_service.dart';
import 'worker_auth_service.dart';
import 'sync_config.dart';

class SyncService {
  final LocalStorageService storage;
  final WorkerAuthService workerAuth = WorkerAuthService();
  SyncService(this.storage);

  /// À appeler au démarrage de l'app et à chaque changement de
  /// connectivité détecté (voir main.dart).
  void listenForConnectivity() {
    Connectivity().onConnectivityChanged.listen((results) async {
      final hasConnection =
          results.any((r) => r != ConnectivityResult.none);
      if (hasConnection) {
        await syncPendingCheckins();
      }
    });
  }

  /// إرسال check-in واحد وانتظار النتيجة الرسمية من الخادم.
  /// يستخدمه مسار الإرسال التفاعلي كي يرى العامل نتيجة BPRS والمخاطر
  /// الثمانية فوراً عند توفر الاتصال، مع الحفاظ على Offline-First عند الفشل.
  Future<Map<String, dynamic>?> pushSingleCheckin(DailyCheckin checkin) async {
    final serverResult = await _pushCheckinToServer(checkin.toFullCheckinPayload());
    if (serverResult != null) {
      checkin.serverResultJson = jsonEncode(serverResult);
      await storage.markSynced(checkin.id);
    }
    return serverResult;
  }

  Future<void> syncPendingCheckins() async {
    final pending = storage.getPendingSyncItems();
    for (final checkin in pending) {
      final serverResult = await _pushCheckinToServer(checkin.toFullCheckinPayload());
      if (serverResult != null) {
        checkin.serverResultJson = jsonEncode(serverResult);
        await storage.markSynced(checkin.id);
      }
    }

    final pendingReports = storage.getPendingSyncReports();
    for (final report in pendingReports) {
      final success = await _pushReportToServer(report.toApiPayload());
      if (success) {
        await storage.markReportSynced(report.id);
      }
    }
  }

  /// Appel HTTP réel vers POST /v1/checkins/full — endpoint testé dans
  /// buddy_backend/tests/test_api.py (section "PsychoTech Layer") et
  /// tests/test_e2e_full_system.py. Le serveur devient l'unique source
  /// de vérité pour BPRS + les 8 risques + le moteur de fatigue.
  /// Si un jeton d'employé authentifié existe (voir WorkerAuthService),
  /// il est joint via X-Worker-Token — le serveur l'utilise alors comme
  /// source de vérité pour l'identité, au lieu du workerIdHash local.
  /// Renvoie le JSON de réponse du serveur (null en cas d'échec) au lieu
  /// d'un simple booléen, pour que l'appelant puisse afficher le résultat
  /// officiel (score, 8 risques, fatigue, urgence, notification Buddy).
  Future<Map<String, dynamic>?> _pushCheckinToServer(Map<String, dynamic> payload) async {
    try {
      final token = await workerAuth.getStoredToken();
      final headers = {
        'Content-Type': 'application/json',
        'X-API-Key': SyncConfig.apiKey,
        if (token != null) 'X-Worker-Token': token,
      };

      final response = await http
          .post(
            Uri.parse('${SyncConfig.apiBaseUrl}/v1/checkins/full'),
            headers: headers,
            body: jsonEncode(payload),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode != 201) return null;
      return jsonDecode(response.body) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }

  /// Appel HTTP réel vers POST /v1/reports/anonymous — endpoint testé
  /// dans buddy_backend/tests/test_api.py (test_anonymous_report_submission).
  Future<bool> _pushReportToServer(Map<String, dynamic> payload) async {
    try {
      final response = await http
          .post(
            Uri.parse('${SyncConfig.apiBaseUrl}/v1/reports/anonymous'),
            headers: {
              'Content-Type': 'application/json',
              'X-API-Key': SyncConfig.apiKey,
            },
            body: jsonEncode(payload),
          )
          .timeout(const Duration(seconds: 10));

      return response.statusCode == 201;
    } catch (_) {
      // Pas de connexion, serveur injoignable, timeout, etc. — normal et
      // attendu dans un environnement pétrolier isolé. On réessaiera plus
      // tard, aucune donnée n'est perdue (elle reste dans Hive en local).
      return false;
    }
  }

  /// 🆕 نظام Buddy — العامل يرى Buddy Officer الخاص به + مؤشر التحسّن +
  /// سجل تدخلاته عبر GET /v1/workers/timeline (نفس نقطة PWA وworker_unified.html
  /// بالضبط). ملاحظة أمانة: نقاط /v1/buddy/officers|assign|intervention|workers
  /// إدارية لـHSE/Buddy Officer أنفسهم (buddy_dashboard.html)، لا معنى
  /// لاستدعائها من تطبيق عامل ميداني يستهلك حالة تعيينه فقط.
  Future<Map<String, dynamic>?> fetchMyTimeline(String workerIdHash) async {
    try {
      final token = await workerAuth.getStoredToken();
      final headers = {
        'X-API-Key': SyncConfig.apiKey,
        if (token != null) 'X-Worker-Token': token,
      };
      final response = await http
          .get(
            Uri.parse('${SyncConfig.apiBaseUrl}/v1/workers/timeline?workerIdHash=$workerIdHash'),
            headers: headers,
          )
          .timeout(const Duration(seconds: 10));
      if (response.statusCode != 200) return null;
      return jsonDecode(response.body) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }
}

