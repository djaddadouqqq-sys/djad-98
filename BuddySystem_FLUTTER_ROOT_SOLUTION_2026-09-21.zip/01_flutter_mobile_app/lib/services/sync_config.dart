/// lib/services/sync_config.dart
/// Configuration réseau : les valeurs de déploiement sont injectées au build
/// via --dart-define, sans modifier le code source. Les valeurs par défaut
/// restent adaptées à un émulateur Android local.
library sync_config;

class SyncConfig {
  static const String apiBaseUrl = String.fromEnvironment(
    'BUDDY_API_BASE_URL',
    defaultValue: 'http://10.0.2.2:8000',
  );

  static const String apiKey = String.fromEnvironment(
    'BUDDY_API_KEY',
    defaultValue: 'pilot-demo-key-2026',
  );
}
