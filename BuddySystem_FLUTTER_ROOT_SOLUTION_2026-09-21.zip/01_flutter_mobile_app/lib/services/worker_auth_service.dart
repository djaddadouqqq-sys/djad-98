/// lib/services/worker_auth_service.dart
///
/// Authentification individuelle de l'employé — appelle réellement
/// POST /v1/auth/worker/login (endpoint testé dans buddy_backend,
/// voir test_worker_provision_login_and_authenticated_checkin_flow).
///
/// Le jeton reçu est stocké dans flutter_secure_storage (Keystore/
/// Keychain natif) — jamais dans Hive ni en mémoire simple — car c'est
/// un secret de session, pas une donnée métier.
///
/// 🔧 CORRECTIF workerIdHash : le serveur renvoie désormais le
/// `workerIdHash` officiel du travailleur dans la réponse de
/// `/v1/auth/worker/login` (voir buddy_backend/app/server.py, ligne
/// `self._send_json(200, {"token": token, "workerIdHash": ...})`). Ce
/// service stocke maintenant cette valeur à côté du jeton, et expose
/// `getEffectiveWorkerIdHash()` comme SEULE source de vérité pour
/// l'identité locale de l'employé — plus aucune constante en dur
/// partagée entre installations (`'local-fallback-hash'`) n'est
/// utilisée ailleurs dans l'app (voir checkin_screen.dart et
/// home_screen.dart). En mode "الدخول بشكل مجهول" (sans jeton), un
/// identifiant anonyme est généré UNE SEULE FOIS par appareil puis
/// conservé dans le Keystore/Keychain — chaque installation anonyme a
/// donc sa propre identité stable, au lieu que tous les utilisateurs
/// anonymes ne partagent la même valeur figée (ce qui aurait fusionné
/// leurs check-ins côté serveur sous un seul et même workerIdHash).
library worker_auth_service;

import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'package:uuid/uuid.dart';

import 'sync_config.dart';

class WorkerLoginResult {
  final bool success;
  final String? errorMessage;
  WorkerLoginResult.ok() : success = true, errorMessage = null;
  WorkerLoginResult.fail(this.errorMessage) : success = false;
}

class WorkerAuthService {
  static const _secureStorage = FlutterSecureStorage();
  static const _tokenKey = 'buddy_worker_token_v1';
  static const _workerIdHashKey = 'buddy_worker_id_hash_v1';
  static const _employeeIdKey = 'buddy_employee_id_v1';
  static const _anonymousIdKey = 'buddy_anonymous_device_id_v1';

  /// Appelle le backend réel. En cas d'échec réseau (site isolé, hors
  /// ligne), renvoie un échec explicite — l'appelant (entry_screen)
  /// doit alors proposer "الدخول بشكل مجهول" comme repli, jamais
  /// bloquer l'utilisateur.
  Future<WorkerLoginResult> login({
    required String employeeId,
    required String pin,
  }) async {
    try {
      final response = await http
          .post(
            Uri.parse('${SyncConfig.apiBaseUrl}/v1/auth/worker/login'),
            headers: {
              'Content-Type': 'application/json',
              'X-API-Key': SyncConfig.apiKey,
            },
            body: jsonEncode({'employeeId': employeeId, 'pin': pin}),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final body = jsonDecode(response.body) as Map<String, dynamic>;
        await _secureStorage.write(key: _tokenKey, value: body['token'] as String);
        await _secureStorage.write(key: _employeeIdKey, value: employeeId);
        // 🔧 Le serveur renvoie le workerIdHash officiel associé à ce
        // jeton — on le stocke pour en faire l'identité effective de
        // la session (voir getEffectiveWorkerIdHash() ci-dessous).
        final workerIdHash = body['workerIdHash'] as String?;
        if (workerIdHash != null && workerIdHash.isNotEmpty) {
          await _secureStorage.write(key: _workerIdHashKey, value: workerIdHash);
        }
        return WorkerLoginResult.ok();
      }
      if (response.statusCode == 401) {
        return WorkerLoginResult.fail('الرقم الوظيفي أو الرمز السري غير صحيح.');
      }
      return WorkerLoginResult.fail('تعذّر تسجيل الدخول (رمز: ${response.statusCode}).');
    } catch (_) {
      return WorkerLoginResult.fail(
          'لا يوجد اتصال بالخادم الآن. يمكنك المتابعة والمزامنة لاحقاً، أو الدخول بشكل مجهول.');
    }
  }

  Future<String?> getStoredToken() => _secureStorage.read(key: _tokenKey);

  Future<String?> getStoredEmployeeId() => _secureStorage.read(key: _employeeIdKey);

  /// Supprime la session authentifiée (jeton + workerIdHash officiel).
  /// N'efface PAS l'identifiant anonyme de l'appareil : un utilisateur
  /// qui se déconnecte puis revient en mode anonyme doit retrouver le
  /// même historique anonyme local, pas un nouveau à chaque fois.
  Future<void> clearToken() async {
    await _secureStorage.delete(key: _tokenKey);
    await _secureStorage.delete(key: _workerIdHashKey);
    await _secureStorage.delete(key: _employeeIdKey);
  }

  /// 🔧 Identité effective de l'employé, à utiliser PARTOUT dans l'app
  /// (check-in, timeline Buddy) au lieu de toute constante en dur :
  ///   1. Si une session authentifiée existe (login réussi), renvoie le
  ///      workerIdHash officiel retourné par le serveur au login — la
  ///      même valeur que le serveur dérive de X-Worker-Token, donc
  ///      cohérente avec /v1/checkins/full même avant la première
  ///      synchronisation.
  ///   2. Sinon (mode "الدخول بشكل مجهول" ou hors-ligne sans connexion
  ///      jamais établie), renvoie un identifiant anonyme généré une
  ///      seule fois par appareil et conservé de façon persistante —
  ///      jamais une valeur partagée entre installations.
  Future<String> getEffectiveWorkerIdHash() async {
    final authenticated = await _secureStorage.read(key: _workerIdHashKey);
    if (authenticated != null && authenticated.isNotEmpty) {
      return authenticated;
    }

    final existingAnonymous = await _secureStorage.read(key: _anonymousIdKey);
    if (existingAnonymous != null && existingAnonymous.isNotEmpty) {
      return existingAnonymous;
    }

    final generated = 'anon-${const Uuid().v4()}';
    await _secureStorage.write(key: _anonymousIdKey, value: generated);
    return generated;
  }

  /// true si une session employé authentifiée (avec jeton) est active.
  Future<bool> isAuthenticated() async {
    final token = await getStoredToken();
    return token != null && token.isNotEmpty;
  }
}
