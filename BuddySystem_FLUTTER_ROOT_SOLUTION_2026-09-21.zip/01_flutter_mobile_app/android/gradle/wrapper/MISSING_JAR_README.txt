Buddy System — Gradle Wrapper note

This package contains gradle-wrapper.properties and the wrapper scripts, but
android/gradle/wrapper/gradle-wrapper.jar is intentionally not fabricated.

Reason: the build environment used to prepare this package has no Gradle or
Android/Flutter SDK and no outbound network access, so a valid wrapper JAR
cannot be generated or downloaded here.

On a machine with Gradle installed, regenerate the wrapper from the android/
directory with the Gradle version declared in gradle-wrapper.properties (8.6),
or let a Flutter/Android project setup regenerate the wrapper files.

This is a remaining environment/build-packaging item, not claimed as fixed.
