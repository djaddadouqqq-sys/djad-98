# Verification contract — Buddy System Flutter

هذه الوثيقة تلغي الاعتماد على أي نسبة إنجاز غير مبنية على تنفيذ فعلي.

## معيار القبول

يُعتبر Android Flutter build صالحاً فقط إذا نجحت كل المراحل التالية في CI أو على جهاز تطوير حقيقي:

1. `flutter pub get`
2. `dart run build_runner build --delete-conflicting-outputs`
3. وجود `daily_checkin.g.dart` و`anonymous_report.g.dart`
4. `flutter analyze`
5. `flutter test`
6. وجود `android/gradle/wrapper/gradle-wrapper.jar`
7. `./gradlew :app:assembleDebug`
8. `flutter build apk --debug`
9. وجود `build/app/outputs/flutter-apk/app-debug.apk`

## لماذا هذا حل جذري؟

البيئة التي تم فيها إعداد المشروع لا تحتوي Flutter/Dart/Android SDK. لذلك لا يجوز اعتبار أي ملف أو نسبة بديلاً عن build حقيقي.

الـ GitHub Actions workflow الموجود في `.github/workflows/flutter_android.yml` يوفّر بيئة Flutter وJava وGradle حقيقية ويوقف العملية عند أول خطأ، ثم يرفع APK إذا نجحت جميع المراحل.

## بعد نجاح الـ CI

الخطوة التالية ليست تعديل الكود عشوائياً؛ بل تثبيت الـ APK على هاتف Android وإجراء اختبار التكامل:

`Login → Check-in → BPRS → 8 risks → Fatigue → Buddy → Offline → Sync`

## ملاحظة أمنية

القيم الافتراضية الحالية للـ API مناسبة للـ pilot/local emulator فقط. قبل نشر حقيقي يجب تمرير `BUDDY_API_BASE_URL` و`BUDDY_API_KEY` عبر إعدادات CI/بيئة التشغيل وعدم وضع أسرار الإنتاج داخل المستودع.
