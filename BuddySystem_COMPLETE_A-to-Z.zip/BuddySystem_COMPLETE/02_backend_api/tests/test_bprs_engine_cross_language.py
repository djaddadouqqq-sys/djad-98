"""
tests/test_bprs_engine_cross_language.py

Reproduit les 4 scénarios de test EXACTS du fichier Dart original
(buddy_flutter/test/bprs_engine_test.dart) contre le portage Python
(app/bprs_engine.py), et ajoute des assertions de valeur numérique
EXACTE (le fichier Dart original ne vérifiait que des plages/booléens
— ici on va plus loin en fixant les valeurs précises calculées à la
main, pour détecter la moindre divergence future entre les deux
implémentations).

Ces valeurs exactes ont été calculées manuellement avant l'écriture de
ce fichier (voir le raisonnement détaillé dans la conversation) :

  Scénario 1 : tous les inputs=1, poids somment à 1.0 -> weighted=1.0
               -> score_base = 10.0. Aucun facteur passif. Score final = 10.0.

  Scénario 2 : declarative_inputs=None -> base=0. daysSinceLastCheckin=9
               (>=7) -> +15. Score final = 15.0.

  Scénario 3 : weighted = 6*0.18 + 6*0.18 + 6*0.16 + 5*0.16 + 5*0.16 + 6*0.16
                        = 1.08 + 1.08 + 0.96 + 0.8 + 0.8 + 0.96 = 5.68
               score_base = 56.8
               + dayInRotationCycle=25(>=21) -> +10
               + hoursWorkedLast24h=13(>12) -> +8
               + isNightShift=true -> +5
               + distanceFromFamilyKm=900(>=700) -> +5
               total addition = 28 -> score final = 56.8 + 28 = 84.8 -> RED

  Scénario 4 : tous les inputs=10 -> weighted=10*1.0=10 -> score_base=100
               + dayInRotationCycle=28(>=21) -> +10
               + daysSinceLastCheckin=20(>=7) -> +15
               + hoursWorkedLast24h=16(>12) -> +8
               + isNightShift=true -> +5
               + distanceFromFamilyKm=1500(>=700) -> +5
               total addition = 43 -> raw = 143 -> clamp(0,100) -> 100.0 -> RED
"""

import unittest
from app.bprs_engine import compute, BprsInputs, RotationContext, RiskLevel


class TestBprsEngineCrossLanguage(unittest.TestCase):

    def test_scenario_1_healthy_profile_stays_green_exact_score(self):
        result = compute(
            declarative_inputs=BprsInputs(
                physical_fatigue=1, mental_fatigue=1, sleep_disruption=1,
                low_empowerment=1, low_resilience=1, isolation=1,
            ),
            rotation_context=RotationContext(
                day_in_rotation_cycle=3, days_since_last_checkin=0,
                hours_worked_last_24h=8, is_night_shift=False,
                distance_from_family_km=200,
            ),
        )
        self.assertEqual(result.level, RiskLevel.GREEN)
        self.assertEqual(result.passive_risk_factors, [])
        self.assertAlmostEqual(result.score, 10.0, places=9)

    def test_scenario_2_missing_checkin_7days_triggers_alert_exact_score(self):
        result = compute(
            declarative_inputs=None,
            rotation_context=RotationContext(
                day_in_rotation_cycle=5, days_since_last_checkin=9,
                hours_worked_last_24h=8, is_night_shift=False,
                distance_from_family_km=100,
            ),
        )
        self.assertGreater(result.score, 0)
        self.assertTrue(len(result.passive_risk_factors) > 0)
        self.assertAlmostEqual(result.score, 15.0, places=9)
        self.assertEqual(result.level, RiskLevel.GREEN)  # 15 < 30 -> vert, malgré l'alerte passive documentée

    def test_scenario_3_cumulative_risk_reaches_orange_or_red_exact_score(self):
        result = compute(
            declarative_inputs=BprsInputs(
                physical_fatigue=6, mental_fatigue=6, sleep_disruption=6,
                low_empowerment=5, low_resilience=5, isolation=6,
            ),
            rotation_context=RotationContext(
                day_in_rotation_cycle=25, days_since_last_checkin=1,
                hours_worked_last_24h=13, is_night_shift=True,
                distance_from_family_km=900,
            ),
        )
        self.assertIn(result.level, (RiskLevel.ORANGE, RiskLevel.RED))
        self.assertAlmostEqual(result.score, 84.8, places=9)
        self.assertEqual(result.level, RiskLevel.RED)

    def test_scenario_4_extreme_cumulative_risk_clamped_at_100(self):
        result = compute(
            declarative_inputs=BprsInputs(
                physical_fatigue=10, mental_fatigue=10, sleep_disruption=10,
                low_empowerment=10, low_resilience=10, isolation=10,
            ),
            rotation_context=RotationContext(
                day_in_rotation_cycle=28, days_since_last_checkin=20,
                hours_worked_last_24h=16, is_night_shift=True,
                distance_from_family_km=1500,
            ),
        )
        self.assertLessEqual(result.score, 100)
        self.assertEqual(result.level, RiskLevel.RED)
        self.assertAlmostEqual(result.score, 100.0, places=9)


if __name__ == "__main__":
    unittest.main(verbosity=2)
