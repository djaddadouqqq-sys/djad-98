"""
tests/test_psychosocial_risks.py

اختبارات وحدة حقيقية لمحرك المخاطر الثمانية (app/psychosocial_risks.py) —
لا محاكاة، حساب فعلي عبر compute_all() ومقارنة بأرقام محسوبة يدوياً.
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.bprs_engine import BprsInputs, RotationContext, RiskLevel
from app.psychosocial_risks import (
    compute_all, compute_one, RISK_DEFINITIONS, RISK_DEFINITIONS_BY_ID,
    recommend_interventions, overall_urgent_actions,
)


class TestPsychosocialRisks(unittest.TestCase):
    def test_eight_documented_risks_are_all_present(self):
        ids = {r.id for r in RISK_DEFINITIONS}
        self.assertEqual(len(RISK_DEFINITIONS), 8)
        self.assertEqual(ids, {
            "burnout", "alienation", "mobbing", "isolation",
            "occupational_stress", "low_motivation", "psychological_trauma",
            "harmful_behaviors_fatigue",
        })

    def test_all_healthy_inputs_stay_green_for_every_risk(self):
        inputs = BprsInputs(physical_fatigue=1, mental_fatigue=1, sleep_disruption=1,
                             low_empowerment=1, low_resilience=1, isolation=1)
        ctx = RotationContext(day_in_rotation_cycle=3, days_since_last_checkin=0,
                               hours_worked_last_24h=8, is_night_shift=False,
                               distance_from_family_km=50)
        scores = compute_all(inputs, ctx)
        self.assertEqual(len(scores), 8)
        for rs in scores:
            self.assertEqual(rs.level, RiskLevel.GREEN, f"{rs.id} should be green, got {rs.score}")

    def test_extreme_inputs_push_burnout_and_fatigue_risks_to_red(self):
        inputs = BprsInputs(physical_fatigue=10, mental_fatigue=10, sleep_disruption=10,
                             low_empowerment=10, low_resilience=10, isolation=10)
        ctx = RotationContext(day_in_rotation_cycle=27, days_since_last_checkin=10,
                               hours_worked_last_24h=14, is_night_shift=True,
                               distance_from_family_km=900)
        scores = {rs.id: rs for rs in compute_all(inputs, ctx)}
        self.assertEqual(scores["burnout"].level, RiskLevel.RED)
        self.assertEqual(scores["harmful_behaviors_fatigue"].level, RiskLevel.RED)
        self.assertEqual(scores["isolation"].level, RiskLevel.RED)

    def test_scores_are_clamped_between_0_and_100(self):
        inputs = BprsInputs(physical_fatigue=10, mental_fatigue=10, sleep_disruption=10,
                             low_empowerment=10, low_resilience=10, isolation=10)
        ctx = RotationContext(day_in_rotation_cycle=28, days_since_last_checkin=30,
                               hours_worked_last_24h=24, is_night_shift=True,
                               distance_from_family_km=2000)
        for rs in compute_all(inputs, ctx):
            self.assertGreaterEqual(rs.score, 0.0)
            self.assertLessEqual(rs.score, 100.0)

    def test_none_inputs_rely_only_on_passive_context_factors(self):
        # نفس فلسفة bprs_engine.compute(): بلا تصريح من العامل، لا
        # نختلق درجة سلوكية — فقط العوامل السياقية السلبية تُحسَب.
        ctx = RotationContext(day_in_rotation_cycle=25, days_since_last_checkin=8,
                               hours_worked_last_24h=13, is_night_shift=True,
                               distance_from_family_km=800)
        scores = {rs.id: rs for rs in compute_all(None, ctx)}
        self.assertGreater(scores["harmful_behaviors_fatigue"].score, 0)
        self.assertEqual(scores["psychological_trauma"].score, 0.0)  # لا عوامل سلبية لهذا الخطر

    def test_red_level_intervention_includes_sos_protocol_mention(self):
        rs = compute_one(
            "psychological_trauma",
            BprsInputs(physical_fatigue=9, mental_fatigue=9, sleep_disruption=9,
                       low_empowerment=9, low_resilience=9, isolation=9),
            RotationContext(day_in_rotation_cycle=25, days_since_last_checkin=0,
                             hours_worked_last_24h=10, is_night_shift=False,
                             distance_from_family_km=100),
        )
        self.assertEqual(rs.level, RiskLevel.RED)
        actions = recommend_interventions(rs)
        self.assertTrue(any("SOS" in a for a in actions))
        self.assertTrue(any("أخصائي" in a for a in actions))

    def test_psychological_trauma_carries_clinical_caution_disclaimer(self):
        definition = RISK_DEFINITIONS_BY_ID["psychological_trauma"]
        self.assertIsNotNone(definition.clinical_caution)
        self.assertIn("تشخيص", definition.clinical_caution)

    def test_overall_urgent_actions_deduplicates_across_red_risks(self):
        inputs = BprsInputs(physical_fatigue=10, mental_fatigue=10, sleep_disruption=10,
                             low_empowerment=10, low_resilience=10, isolation=10)
        ctx = RotationContext(day_in_rotation_cycle=27, days_since_last_checkin=10,
                               hours_worked_last_24h=14, is_night_shift=True,
                               distance_from_family_km=900)
        scores = compute_all(inputs, ctx)
        actions = overall_urgent_actions(scores)
        self.assertEqual(len(actions), len(set(actions)))  # لا تكرار
        self.assertTrue(len(actions) > 0)

    def test_green_level_has_no_urgent_actions(self):
        inputs = BprsInputs(physical_fatigue=1, mental_fatigue=1, sleep_disruption=1,
                             low_empowerment=1, low_resilience=1, isolation=1)
        ctx = RotationContext(day_in_rotation_cycle=3, days_since_last_checkin=0,
                               hours_worked_last_24h=8, is_night_shift=False,
                               distance_from_family_km=50)
        scores = compute_all(inputs, ctx)
        self.assertEqual(overall_urgent_actions(scores), [])


if __name__ == "__main__":
    unittest.main()
