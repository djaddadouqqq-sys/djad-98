"""
scripts/simulate_pilot.py

Simulation réaliste du Pilot institutionnel décrit dans la feuille de
route (Semaines 9-12 : "10 à 20 travailleurs volontaires"). Génère des
données de check-in quotidiennes pour 15 travailleurs simulés sur un
cycle complet de 28 jours, avec des patterns RÉALISTES et non uniformes :

- Certains travailleurs (les plus consciencieux) font leur check-in
  presque tous les jours.
- D'autres oublient plusieurs jours d'affilée — déclenchant les
  majorations passives du moteur BPRS (voir app/bprs_engine.py).
- Une partie est en quart de nuit.
- Les distances domicile-site varient (certaines dépassent le seuil
  documenté de 700km).
- Le score de chaque check-in est calculé par le MÊME moteur BPRS
  vérifié cross-langage (app/bprs_engine.py) — donc scientifiquement
  cohérent avec ce que produirait l'application Flutter réelle.

Toutes les données sont ensuite soumises au vrai backend testé
(POST /v1/checkins/anonymous et /v1/reports/anonymous) via de vrais
appels HTTP — pas d'insertion directe en base qui contournerait la
validation réelle de l'API.

Usage :
    python3 -m app.server &          # démarrer le serveur dans un terminal
    python3 scripts/simulate_pilot.py --api-key pilot-demo-key-2026
"""

import argparse
import json
import random
import sys
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone

sys.path.insert(0, ".")
from app.bprs_engine import compute, BprsInputs, RotationContext, RiskLevel


WORKER_PROFILES = [
    # (nom_interne, conscienciosité[0-1], quart_nuit, distance_km, stabilité_psy[0-1])
    ("W01", 0.95, False, 320, 0.85),
    ("W02", 0.90, False, 180, 0.80),
    ("W03", 0.85, True, 610, 0.70),
    ("W04", 0.80, False, 250, 0.90),
    ("W05", 0.75, True, 890, 0.55),   # profil à risque : nuit + éloignement
    ("W06", 0.70, False, 140, 0.75),
    ("W07", 0.65, False, 400, 0.60),
    ("W08", 0.60, True, 950, 0.45),   # profil à risque élevé
    ("W09", 0.90, False, 90, 0.88),
    ("W10", 0.55, False, 720, 0.50),  # oublieux + éloigné
    ("W11", 0.85, True, 300, 0.78),
    ("W12", 0.75, False, 210, 0.82),
    ("W13", 0.50, True, 1100, 0.40), # profil le plus à risque du groupe
    ("W14", 0.88, False, 160, 0.86),
    ("W15", 0.68, False, 480, 0.65),
]

REPORT_CATEGORIES = ["mobbing", "harassment", "burnout", "other"]


def simulate_checkin(profile, day_in_cycle: int, days_since_last: int):
    """Génère un BprsInputs réaliste à partir de la stabilité
    psychologique du profil, avec un peu de bruit aléatoire — puis le
    fait passer par le VRAI moteur BPRS vérifié."""
    _, _, night, distance, stability = profile

    # Plus stability est faible, plus les valeurs déclaratives sont élevées.
    noise = lambda base: max(0, min(10, base + random.uniform(-1.5, 1.5)))
    risk_base = (1 - stability) * 8

    inputs = BprsInputs(
        physical_fatigue=noise(risk_base),
        mental_fatigue=noise(risk_base),
        sleep_disruption=noise(risk_base * 0.9),
        low_empowerment=noise(risk_base * 0.8),
        low_resilience=noise(risk_base * 0.85),
        isolation=noise(risk_base * (1.3 if distance >= 700 else 0.8)),
    )

    ctx = RotationContext(
        day_in_rotation_cycle=day_in_cycle,
        days_since_last_checkin=days_since_last,
        hours_worked_last_24h=random.uniform(8, 14),
        is_night_shift=night,
        distance_from_family_km=distance,
    )

    return compute(rotation_context=ctx, declarative_inputs=inputs)


def post(base_url, path, payload, api_key):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(base_url + path, data=data, method="POST")
    req.add_header("Content-Type", "application/json")
    req.add_header("X-API-Key", api_key)
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, json.loads(resp.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())


def run(base_url: str, api_key: str, days: int = 28, seed: int = 7):
    random.seed(seed)
    start_date = datetime.now(timezone.utc) - timedelta(days=days)

    stats = {"submitted": 0, "failed": 0, "by_level": {"green": 0, "yellow": 0, "orange": 0, "red": 0}}
    last_checkin_day = {p[0]: None for p in WORKER_PROFILES}

    for day_offset in range(days):
        current_date = start_date + timedelta(days=day_offset)
        day_in_cycle = (day_offset % 28) + 1

        for profile in WORKER_PROFILES:
            name, conscientiousness, *_ = profile
            # Décide si ce travailleur fait son check-in aujourd'hui.
            if random.random() > conscientiousness:
                continue

            days_since_last = (
                day_offset if last_checkin_day[name] is None
                else day_offset - last_checkin_day[name]
            )
            last_checkin_day[name] = day_offset

            result = simulate_checkin(profile, day_in_cycle, days_since_last)

            status, body = post(base_url, "/v1/checkins/anonymous", {
                "workerIdHash": f"pilot-sim-{name}",
                "createdAt": current_date.isoformat(),
                "bprsScore": round(result.score, 2),
                "riskLevel": result.level.value,
                "siteCode": "CPH-PILOT",
            }, api_key)

            if status == 201:
                stats["submitted"] += 1
                stats["by_level"][result.level.value] += 1
            else:
                stats["failed"] += 1
                print(f"  ⚠️ échec soumission {name} jour {day_offset}: {status} {body}")

            # Occasionnellement, un travailleur à faible stabilité soumet
            # un signalement anonyme — réaliste, pas systématique.
            if result.level in (RiskLevel.ORANGE, RiskLevel.RED) and random.random() < 0.08:
                cat = random.choice(REPORT_CATEGORIES)
                post(base_url, "/v1/reports/anonymous", {
                    "category": cat,
                    "message": f"Signalement simulé (profil {name}, cat={cat}) — jour {day_offset}.",
                    "siteCode": "CPH-PILOT",
                }, api_key)

    return stats


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default="http://localhost:8000")
    parser.add_argument("--api-key", required=True)
    parser.add_argument("--days", type=int, default=28)
    args = parser.parse_args()

    print(f"Simulation Pilot : {len(WORKER_PROFILES)} travailleurs sur {args.days} jours...")
    stats = run(args.base_url, args.api_key, days=args.days)
    print(json.dumps(stats, indent=2, ensure_ascii=False))
