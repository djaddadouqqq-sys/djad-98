"""
app/psychosocial_risks.py — PsychoTech Layer: محرك المخاطر النفسية-الاجتماعية الثمانية

الغرض
-----
محرك BPRS (`bprs_engine.py`) يُنتج درجة واحدة مركّبة (0-100) ومستوى عام
واحد. هذا الملف يبني عليه طبقة إضافية تُفكّك تلك الدرجة إلى **ثمانية
مخاطر مسمّاة**، وهي بالضبط المخاطر الثمانية الموثّقة في المذكرة
الأكاديمية والدليل التقني (انظر MASTER_README.md §1):

  الاحتراق الوظيفي · الاغتراب المهني · التنكيد المهني · العزلة المهنية ·
  الإجهاد المهني · انخفاض الدافعية · الصدمات النفسية ·
  السلوكيات الضارة والإرهاق

⚠️ إخلاء مسؤولية منهجي — مهم جداً
----------------------------------
الدراسة الميدانية (N=90، α=0.798) اختبرت **الاستبيان المُجمَّع** الذي
يغذّي محرك BPRS ذا الستة متغيرات. لم تُختبر ميدانياً ثماني درجات فرعية
مستقلة لكل خطر على حدة (لا توجد بيانات عن ثمانية استبيانات فرعية بمعامل
ثبات خاص بكل واحد منها). التوزيع أدناه — أي وزن، أي عتبة تفعيل سياقي —
هو **تحليل تقني معقول (Reasoned Technical Mapping) بناه المطوّر**، بربط
كل خطر بأقرب المتغيرات الستة المُقاسة فعلياً + عوامل الدورة/العمل ذات
الصلة بالأدبيات العلمية العامة (الإرهاق، العزلة الجغرافية، دورة 28/28).
هذا **ليس** أداة تشخيص سريري وليس مقياساً نفسياً مُعتمَداً بذاته لكل خطر
فرعي — يحتاج تحقق أكاديمي/ميداني منفصل قبل أي استخدام سريري أو قانوني.
هذا التنبيه يظهر أيضاً في COMPLIANCE_MAPPING.md ويجب أن يبقى ظاهراً في
أي واجهة تعرض نتائج هذا المحرك.

كل خطر خاضع لنفس تصنيف المستويات الأربعة المستخدم في bprs_engine.py
(أخضر <30، أصفر <55، برتقالي <75، أحمر ≥75) — نفس العتبات، لا عتبات
مختلفة بلا مبرر.
"""

from dataclasses import dataclass, field
from typing import Callable

from .bprs_engine import BprsInputs, RotationContext, RiskLevel, _classify

# إعادة استخدام نفس دالة التصنيف ونفس تعداد المستويات من bprs_engine.py
# عمداً — لا نعيد كتابة العتبات هنا لتفادي انحراف عتبات بين الملفين.


LEVEL_LABEL_AR = {
    RiskLevel.GREEN: "أخضر",
    RiskLevel.YELLOW: "أصفر",
    RiskLevel.ORANGE: "برتقالي",
    RiskLevel.RED: "أحمر",
}


@dataclass(frozen=True)
class RiskDefinition:
    id: str
    name_ar: str
    icon: str
    # أوزان على متغيرات BprsInputs الستة (يجب أن يكون مجموعها <= 1.0)
    declarative_weights: dict
    # دالة تُرجع (نقاط إضافية، أسباب) من سياق الدورة — خاصة بكل خطر
    passive_factor_fn: Callable[[RotationContext], tuple]
    standard_refs: list
    clinical_caution: str | None = None  # تحذير إضافي إن وُجد (مثل الصدمات)


def _passive_fatigue_cycle(ctx: RotationContext):
    """عوامل سياقية عامة مشتركة: تُستخدم بأوزان مختلفة حسب الخطر."""
    pts, reasons = 0.0, []
    if ctx.day_in_rotation_cycle >= 21:
        pts += 10
        reasons.append(f"اليوم {ctx.day_in_rotation_cycle}/28 من دورة العمل — تراكم موثّق ميدانياً")
    if ctx.hours_worked_last_24h > 12:
        pts += 8
        reasons.append(f"{ctx.hours_worked_last_24h:.1f} ساعة عمل خلال 24 ساعة — يتجاوز عتبة API RP 755")
    if ctx.is_night_shift:
        pts += 5
        reasons.append("مناوبة ليلية")
    return pts, reasons


def _passive_isolation(ctx: RotationContext):
    pts, reasons = 0.0, []
    if ctx.distance_from_family_km >= 700:
        pts += 8
        reasons.append("بُعد جغرافي عن الأسرة يفوق 700 كم")
    if ctx.days_since_last_checkin >= 7:
        pts += 10
        reasons.append(f"لا متابعة منذ {ctx.days_since_last_checkin} أيام")
    elif ctx.days_since_last_checkin >= 3:
        pts += 5
        reasons.append(f"غياب متابعة {ctx.days_since_last_checkin} أيام")
    return pts, reasons


def _passive_followup_gap_only(ctx: RotationContext):
    pts, reasons = 0.0, []
    if ctx.days_since_last_checkin >= 7:
        pts += 12
        reasons.append(f"لا متابعة منذ {ctx.days_since_last_checkin} أيام — قد يخفي تدهوراً غير مُبلَّغ")
    elif ctx.days_since_last_checkin >= 3:
        pts += 5
        reasons.append(f"غياب متابعة {ctx.days_since_last_checkin} أيام")
    return pts, reasons


def _passive_none(ctx: RotationContext):
    return 0.0, []


RISK_DEFINITIONS: list = [
    RiskDefinition(
        id="burnout",
        name_ar="الاحتراق الوظيفي",
        icon="🔥",
        declarative_weights={
            "mental_fatigue": 0.35, "physical_fatigue": 0.25,
            "sleep_disruption": 0.20, "low_resilience": 0.20,
        },
        passive_factor_fn=_passive_fatigue_cycle,
        standard_refs=["ISO 45003 §تحديد عوامل الخطر النفسي", "API RP 755 — حدود ساعات العمل"],
    ),
    RiskDefinition(
        id="alienation",
        name_ar="الاغتراب المهني",
        icon="🎭",
        declarative_weights={
            "low_empowerment": 0.45, "mental_fatigue": 0.30, "low_resilience": 0.25,
        },
        passive_factor_fn=_passive_followup_gap_only,
        standard_refs=["ISO 45003 §المشاركة والتشاور"],
    ),
    RiskDefinition(
        id="mobbing",
        name_ar="التنكيد المهني",
        icon="💢",
        declarative_weights={
            "low_empowerment": 0.30, "isolation": 0.30, "low_resilience": 0.20, "mental_fatigue": 0.20,
        },
        passive_factor_fn=_passive_none,
        standard_refs=["ISO 45003 §قنوات إبلاغ آمنة", "بلاغات /v1/reports/anonymous (فئة mobbing) — إشارة سلوكية حقيقية إضافية على مستوى المجموع، انظر aggregates.py"],
        clinical_caution="الدرجة الفردية هنا مبنية فقط على التمكين/العزلة الذاتية المُصرَّح بها؛ الإشارة الأدق على مستوى الموقع هي عدد بلاغات mobbing الفعلية (بيانات سلوكية لا تصريحية).",
    ),
    RiskDefinition(
        id="isolation",
        name_ar="العزلة المهنية",
        icon="🏚️",
        declarative_weights={
            "isolation": 0.55, "low_empowerment": 0.25, "low_resilience": 0.20,
        },
        passive_factor_fn=_passive_isolation,
        standard_refs=["الدراسة الميدانية: 44% من العينة يسكنون على بُعد >700كم"],
    ),
    RiskDefinition(
        id="occupational_stress",
        name_ar="الإجهاد المهني",
        icon="⚡",
        declarative_weights={
            "mental_fatigue": 0.35, "physical_fatigue": 0.25, "sleep_disruption": 0.20, "low_resilience": 0.20,
        },
        passive_factor_fn=_passive_fatigue_cycle,
        standard_refs=["API RP 755 — إدارة مخاطر الإرهاق", "ISO 45001 البند 6 — تحديد المخاطر"],
    ),
    RiskDefinition(
        id="low_motivation",
        name_ar="انخفاض الدافعية",
        icon="📉",
        declarative_weights={
            "low_empowerment": 0.5, "low_resilience": 0.3, "mental_fatigue": 0.2,
        },
        passive_factor_fn=_passive_followup_gap_only,
        standard_refs=["ISO 45003 §المشاركة والتشاور"],
    ),
    RiskDefinition(
        id="psychological_trauma",
        name_ar="الصدمات النفسية",
        icon="💔",
        declarative_weights={
            "low_resilience": 0.4, "isolation": 0.3, "mental_fatigue": 0.3,
        },
        passive_factor_fn=_passive_none,
        standard_refs=["ISO 45003 §التقييم المستمر"],
        clinical_caution="هذه درجة فحص أولي (Screening) من نبض عافية يومي — ليست أداة تشخيص صدمة نفسية. مستوى أحمر هنا يجب أن يُوجَّه فوراً لأخصائي نفسي مؤهل، لا يُعامَل كتشخيص نهائي بحد ذاته.",
    ),
    RiskDefinition(
        id="harmful_behaviors_fatigue",
        name_ar="السلوكيات الضارة والإرهاق",
        icon="🔋",
        declarative_weights={
            "physical_fatigue": 0.3, "sleep_disruption": 0.35, "mental_fatigue": 0.15, "low_resilience": 0.20,
        },
        passive_factor_fn=_passive_fatigue_cycle,
        standard_refs=["API RP 755 — حدود ساعات العمل، مخاطر المناوبات الليلية، دورات العمل الممتدة"],
    ),
]

RISK_DEFINITIONS_BY_ID = {r.id: r for r in RISK_DEFINITIONS}


@dataclass(frozen=True)
class RiskScore:
    id: str
    name_ar: str
    icon: str
    score: float
    level: RiskLevel
    level_label_ar: str
    reasons: list
    standard_refs: list
    clinical_caution: str | None = None


def _weighted_declarative(inputs: BprsInputs, weights: dict) -> float:
    total = 0.0
    for field_name, w in weights.items():
        total += getattr(inputs, field_name) * w
    return total * 10  # نفس تحويل bprs_engine.py من مقياس 0-10 إلى 0-100


def compute_one(risk_id: str, inputs: BprsInputs | None, ctx: RotationContext) -> RiskScore:
    definition = RISK_DEFINITIONS_BY_ID[risk_id]
    base = _weighted_declarative(inputs, definition.declarative_weights) if inputs is not None else 0.0
    passive_pts, reasons = definition.passive_factor_fn(ctx)
    score = max(0.0, min(100.0, base + passive_pts))
    level = _classify(score)
    return RiskScore(
        id=definition.id, name_ar=definition.name_ar, icon=definition.icon,
        score=round(score, 1), level=level, level_label_ar=LEVEL_LABEL_AR[level],
        reasons=reasons, standard_refs=definition.standard_refs,
        clinical_caution=definition.clinical_caution,
    )


def compute_all(inputs: BprsInputs | None, ctx: RotationContext) -> list:
    """يحسب المخاطر الثمانية دفعة واحدة — الترتيب ثابت (نفس ترتيب
    RISK_DEFINITIONS) حتى تبقى الواجهة قابلة للتنبؤ."""
    return [compute_one(r.id, inputs, ctx) for r in RISK_DEFINITIONS]


# ---------------------------------------------------------------------------
# محرك التدخلات والتوصيات — يتغيّر حسب المستوى، خصوصاً عند الانتقال إلى
# أصفر/أحمر. النصوص هنا وقائية وتوجيهية، وليست بديلاً عن تقييم مختص.
# ---------------------------------------------------------------------------

GENERAL_INTERVENTIONS = {
    RiskLevel.GREEN: [
        "لا إجراء عاجل مطلوب — استمر في نبض العافية اليومي.",
    ],
    RiskLevel.YELLOW: [
        "تفعيل متابعة Buddy Officer خلال 48 ساعة (محادثة غير رسمية).",
        "تذكير العامل بقنوات الدعم المتاحة (الإبلاغ المجهول، جسر الأسرة).",
    ],
    RiskLevel.ORANGE: [
        "تدخل مباشر من Buddy Officer خلال 24 ساعة.",
        "إشعار مشرف HSE لمتابعة الحالة ضمن لوحة المؤشرات.",
        "اقتراح تخفيف عبء المناوبة إن أمكن تشغيلياً.",
    ],
    RiskLevel.RED: [
        "🚨 تدخل نفسي عاجل — تفعيل بروتوكول SOS فوراً.",
        "تسلسل التصعيد الثلاثي: Buddy Officer ← مشرف HSE ← أخصائي نفسي، خلال دقائق لا ساعات.",
        "لا تترك العامل بمفرده حتى وصول المتابعة المختصة.",
        "توثيق الحالة في سجل التدقيق (audit log) دون كشف أي بيانات هوية في القنوات المجهولة.",
    ],
}

RISK_SPECIFIC_INTERVENTIONS = {
    "burnout": {
        RiskLevel.ORANGE: ["تقييم إمكانية تقليص ساعات العمل خلال الأيام القادمة من الدورة."],
        RiskLevel.RED: ["تقييم طبي/نفسي لمدى القدرة على متابعة العمل حتى نهاية الدورة الحالية."],
    },
    "isolation": {
        RiskLevel.YELLOW: ["تفعيل قناة \"جسر الأسرة\" لتواصل إضافي هذا الأسبوع."],
        RiskLevel.ORANGE: ["ترتيب مكالمة عائلية مدعومة عبر Buddy Officer."],
    },
    "harmful_behaviors_fatigue": {
        RiskLevel.ORANGE: ["مراجعة جدول المناوبات مقابل حدود API RP 755 (>12 ساعة/24 ساعة)."],
        RiskLevel.RED: ["إيقاف مؤقت عن العمل الليلي/الإضافي حتى تقييم الإرهاق من الأخصائي."],
    },
    "psychological_trauma": {
        RiskLevel.ORANGE: ["إحالة لأخصائي نفسي خلال 48 ساعة (فحص أولي، ليس تشخيصاً)."],
        RiskLevel.RED: ["إحالة عاجلة لأخصائي نفسي مؤهل — لا يُكتفى بمتابعة Buddy Officer وحدها."],
    },
    "mobbing": {
        RiskLevel.ORANGE: ["تفعيل تحقق HSE في نمط البلاغات المجهولة لهذا الموقع (site_code)."],
        RiskLevel.RED: ["تحقيق إداري رسمي مستقل عن هوية العامل صاحب الدرجة العالية (لا يُربط الاثنان)."],
    },
}


def recommend_interventions(risk_score: RiskScore) -> list:
    actions = list(GENERAL_INTERVENTIONS[risk_score.level])
    specific = RISK_SPECIFIC_INTERVENTIONS.get(risk_score.id, {}).get(risk_score.level, [])
    return actions + specific


def overall_urgent_actions(risk_scores: list) -> list:
    """يُستدعى عند وجود مستوى أحمر واحد على الأقل ضمن المخاطر الثمانية —
    يجمع كل التدخلات العاجلة الخاصة بالمخاطر الحمراء دون تكرار."""
    seen = set()
    actions = []
    for rs in risk_scores:
        if rs.level != RiskLevel.RED:
            continue
        for a in recommend_interventions(rs):
            if a not in seen:
                seen.add(a)
                actions.append(a)
    return actions
