"""
app/bprs_engine.py

Portage Python EXACT du moteur BPRS original (lib/services/bprs_engine.dart
côté Flutter). Chaque poids, chaque seuil, chaque majoration passive est
identique au fichier Dart, valeur pour valeur — voir
tests/test_bprs_engine_cross_language.py pour la preuve de cette
équivalence (les 4 scénarios de test Dart originaux sont reproduits ici
et doivent produire des résultats numériquement identiques).

Pourquoi ce portage existe : le calcul BPRS actuel se fait uniquement
côté client (Flutter), pour rester Offline-First. Ce portage serveur
permet (a) de simuler des scénarios de Pilot réalistes sans dépendre de
l'app mobile, et (b) de poser les bases d'une future recomputation
serveur pour audit/vérification — sans jamais remplacer le calcul local
qui doit rester la source de vérité en l'absence de réseau.
"""

from dataclasses import dataclass, field
from enum import Enum


@dataclass(frozen=True)
class BprsInputs:
    """Six entrées brutes, normalisées par l'appelant sur une échelle de
    0.0 (aucun risque) à 10.0 (risque maximal) AVANT pondération — sauf
    indication contraire (voir docstrings, identiques au fichier Dart)."""
    physical_fatigue: float
    mental_fatigue: float
    sleep_disruption: float   # 0 = sommeil excellent, 10 = très perturbé
    low_empowerment: float    # 0 = empowerment élevé (protecteur), 10 = faible
    low_resilience: float     # 0 = résilience élevée (protectrice), 10 = faible
    isolation: float


@dataclass(frozen=True)
class RotationContext:
    day_in_rotation_cycle: int
    days_since_last_checkin: int
    hours_worked_last_24h: float
    is_night_shift: bool
    distance_from_family_km: float


class RiskLevel(str, Enum):
    GREEN = "green"
    YELLOW = "yellow"
    ORANGE = "orange"
    RED = "red"


LEVEL_LABEL_AR = {
    RiskLevel.GREEN: "أخضر — استفسار",
    RiskLevel.YELLOW: "أصفر — متابعة وتبليغ",
    RiskLevel.ORANGE: "برتقالي — تدخل",
    RiskLevel.RED: "أحمر — تدخل نفسي فوري",
}


@dataclass(frozen=True)
class BprsResult:
    score: float
    level: RiskLevel
    passive_risk_factors: list = field(default_factory=list)

    @property
    def level_label_ar(self) -> str:
        return LEVEL_LABEL_AR[self.level]


# Pondérations — IDENTIQUES à bprs_engine.dart (_wPhysicalFatigue, etc.)
_W_PHYSICAL_FATIGUE = 0.18
_W_MENTAL_FATIGUE = 0.18
_W_SLEEP = 0.16
_W_EMPOWERMENT = 0.16
_W_RESILIENCE = 0.16
_W_ISOLATION = 0.16


def _declarative_score(i: BprsInputs) -> float:
    weighted = (
        i.physical_fatigue * _W_PHYSICAL_FATIGUE
        + i.mental_fatigue * _W_MENTAL_FATIGUE
        + i.sleep_disruption * _W_SLEEP
        + i.low_empowerment * _W_EMPOWERMENT
        + i.low_resilience * _W_RESILIENCE
        + i.isolation * _W_ISOLATION
    )
    return weighted * 10  # échelle 0-10 -> 0-100, comme dans le Dart


def _apply_passive_risk_factors(base_score: float, ctx: RotationContext):
    score = base_score
    reasons = []

    if ctx.days_since_last_checkin >= 7:
        score += 15
        reasons.append(
            f"لم يسجّل العامل أي بيانات منذ {ctx.days_since_last_checkin} أيام — ارتفاع تلقائي للحذر"
        )
    elif ctx.days_since_last_checkin >= 3:
        score += 7
        reasons.append(f"غياب متابعة لمدة {ctx.days_since_last_checkin} أيام")

    if ctx.day_in_rotation_cycle >= 21:
        score += 10
        reasons.append(
            f"اليوم {ctx.day_in_rotation_cycle} من دورة 28/28 — تجاوز عتبة التراكم النفسي الموثقة ميدانياً"
        )

    if ctx.hours_worked_last_24h > 12:
        score += 8
        reasons.append(
            f"{ctx.hours_worked_last_24h:.1f} ساعة عمل خلال 24 ساعة — يتجاوز عتبة API RP 755 للإرهاق"
        )

    if ctx.is_night_shift:
        score += 5
        reasons.append("مناوبة ليلية — عامل خطر إضافي موثّق")

    if ctx.distance_from_family_km >= 700:
        score += 5
        reasons.append("بُعد جغرافي عن الأسرة يفوق 700 كم — عتبة العزلة الموثّقة في الدراسة الميدانية")

    # clamp(0, 100) — identique à score.clamp(0, 100).toDouble() en Dart
    score = max(0.0, min(100.0, score))
    return score, reasons


def _classify(score: float) -> RiskLevel:
    if score < 30:
        return RiskLevel.GREEN
    if score < 55:
        return RiskLevel.YELLOW
    if score < 75:
        return RiskLevel.ORANGE
    return RiskLevel.RED


def compute(rotation_context: RotationContext, declarative_inputs: BprsInputs | None = None) -> BprsResult:
    """Point d'entrée principal — équivalent exact de BprsEngine.compute()
    côté Dart. Si declarative_inputs est None (l'employé n'a rien
    rempli), le score de base est 0 et seuls les facteurs passifs du
    contexte de rotation déterminent le score — jamais d'hallucination
    d'un état psychologique non déclaré."""
    base = _declarative_score(declarative_inputs) if declarative_inputs is not None else 0.0
    final_score, reasons = _apply_passive_risk_factors(base, rotation_context)
    return BprsResult(score=final_score, level=_classify(final_score), passive_risk_factors=reasons)
