"""
app/db.py

Couche base de données. Utilise SQLite via le module standard `sqlite3`
pour la phase Pilot (aucune dépendance externe nécessaire — fonctionne
partout où Python 3 est installé, y compris sans accès internet).

MIGRATION VERS POSTGRESQL (recommandée avant la mise à l'échelle) :
Remplacez les appels sqlite3.connect() par psycopg2 ou SQLAlchemy avec
une URL PostgreSQL (ex: postgresql://user:pass@host/dbname). PostgreSQL
gère nativement les écritures concurrentes multi-thread — le verrou
Python ci-dessous (_write_lock) ne serait alors plus nécessaire.
"""

import sqlite3
import os
import threading

DB_PATH = os.environ.get("BUDDY_DB_PATH", "buddy_system.db")

_local = threading.local()

# CORRECTIF RÉEL (trouvé par les tests de cette session, en deux temps) :
# le serveur HTTP stdlib traite chaque requête sur un thread séparé.
# Un verrou limité aux seules écritures s'est révélé insuffisant : sous
# stdlib pur, sans pool de connexions, des lectures et écritures
# entrelacées entre threads déclenchaient encore des erreurs
# intermittentes `database is locked`. La solution retenue, simple et
# fiable pour le volume d'une phase Pilot : sérialiser TOUTE opération
# de base de données (lecture ET écriture) derrière un unique verrou
# Python. Ce n'est pas un goulot d'étranglement réel à cette échelle,
# et disparaît de toute façon lors de la migration vers PostgreSQL
# (qui gère nativement l'accès concurrent multi-thread).
_db_lock = threading.Lock()


def get_connection():
    """Une connexion par thread — nécessaire car le serveur HTTP stdlib
    traite chaque requête sur un thread dédié (voir server.py).

    Note : le mode WAL est activé UNE SEULE FOIS dans init_db() — il est
    persisté dans le fichier de base de données lui-même, donc chaque
    nouvelle connexion en hérite automatiquement. Le réémettre à chaque
    connexion (comme dans une version précédente de ce fichier) forçait
    une prise de verrou exclusif à chaque nouvelle requête et provoquait
    des erreurs `database is locked` sous charge — c'était la véritable
    cause du bug, pas l'absence de verrou Python."""
    if not hasattr(_local, "conn"):
        _local.conn = sqlite3.connect(DB_PATH, timeout=10)
        _local.conn.row_factory = sqlite3.Row
        _local.conn.execute("PRAGMA busy_timeout=10000;")
    return _local.conn


def execute_write(query: str, params: tuple = ()):
    """Point d'entrée pour toute écriture (INSERT/UPDATE/DELETE).
    Acquiert le verrou global avant d'écrire, commit, puis relâche.

    CORRECTIF CRITIQUE (cause racine réelle du bug `database is locked`,
    trouvée par les tests de cette session) : si `conn.execute()` lève une
    exception (ex: sqlite3.IntegrityError sur une clé API dupliquée),
    SQLite laisse une transaction implicite OUVERTE et NON validée sur
    cette connexion. Comme chaque thread garde sa propre connexion pour
    toute sa durée de vie sans jamais la fermer explicitement, cette
    transaction bloquée finissait par verrouiller le fichier pour TOUTES
    les écritures suivantes, même venant d'autres threads/connexions —
    d'où des échecs en cascade bien après l'erreur d'origine. Le
    `rollback()` explicite ci-dessous, systématique en cas d'échec,
    élimine ce verrou fantôme."""
    with _db_lock:
        conn = get_connection()
        try:
            conn.execute(query, params)
            conn.commit()
        except Exception:
            conn.rollback()
            raise


def execute_write_many(statements: list):
    """Exécute plusieurs (requête, params) dans UNE seule transaction —
    utilisé par insert_full_checkin() pour garantir que checkins,
    checkin_inputs et les 8 lignes de checkin_risk_scores sont écrits
    ensemble ou pas du tout (pas de risque_scores orphelins si l'écriture
    du checkin échoue à mi-chemin). Même politique de rollback explicite
    que execute_write() ci-dessus, pour la même raison (voir sa docstring)."""
    with _db_lock:
        conn = get_connection()
        try:
            for query, params in statements:
                conn.execute(query, params)
            conn.commit()
        except Exception:
            conn.rollback()
            raise


def execute_read(query: str, params: tuple = (), one: bool = False):
    """Point d'entrée pour toute lecture (SELECT). Passe par le même
    verrou global que execute_write — voir la note ci-dessus sur
    pourquoi les lectures sont elles aussi sérialisées ici."""
    with _db_lock:
        conn = get_connection()
        cursor = conn.execute(query, params)
        return cursor.fetchone() if one else cursor.fetchall()


SCHEMA = """
CREATE TABLE IF NOT EXISTS audit_log (
    id TEXT PRIMARY KEY,
    created_at TEXT NOT NULL,
    actor_type TEXT NOT NULL CHECK(actor_type IN ('admin','tenant','worker','system')),
    actor_ref TEXT,
    action TEXT NOT NULL,
    target_type TEXT,
    target_id TEXT,
    tenant_id TEXT,
    details TEXT
    -- ملاحظة تصميم متعمّدة: لا يُخزَّن أي رمز سري (PIN) أو محتوى بلاغ
    -- مجهول في هذا الجدول تحت أي ظرف — فقط البيانات الوصفية للحدث.
);

CREATE INDEX IF NOT EXISTS idx_audit_created_at ON audit_log(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_tenant ON audit_log(tenant_id);

CREATE TABLE IF NOT EXISTS tenants (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    api_key TEXT NOT NULL UNIQUE,
    rotation_cycle_days INTEGER NOT NULL DEFAULT 28,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS workers (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL REFERENCES tenants(id),
    employee_id TEXT NOT NULL,
    pin_salt TEXT NOT NULL,
    pin_hash TEXT NOT NULL,
    worker_id_hash TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_workers_tenant_employee ON workers(tenant_id, employee_id);
CREATE INDEX IF NOT EXISTS idx_workers_tenant ON workers(tenant_id);

CREATE TABLE IF NOT EXISTS checkins (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL REFERENCES tenants(id),
    worker_id_hash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    bprs_score REAL NOT NULL,
    risk_level TEXT NOT NULL CHECK(risk_level IN ('green','yellow','orange','red')),
    site_code TEXT
);

CREATE TABLE IF NOT EXISTS anonymous_reports (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL REFERENCES tenants(id),
    created_at TEXT NOT NULL,
    category TEXT NOT NULL CHECK(category IN ('mobbing','harassment','burnout','other')),
    site_code TEXT,
    message TEXT NOT NULL
    -- Volontairement : AUCUNE colonne d'identité de l'auteur. C'est la
    -- garantie technique de l'anonymat exigée par le mémoire (canal
    -- d'alerte sans stigmatisation).
);

CREATE INDEX IF NOT EXISTS idx_checkins_created_at ON checkins(created_at);
CREATE INDEX IF NOT EXISTS idx_checkins_tenant ON checkins(tenant_id);
CREATE INDEX IF NOT EXISTS idx_checkins_site ON checkins(site_code);
CREATE INDEX IF NOT EXISTS idx_reports_tenant ON anonymous_reports(tenant_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_tenants_api_key ON tenants(api_key);

-- ============================================================
-- PsychoTech Layer — إضافة إضافية فوق البنية المُختبرة أعلاه، لا تُعدّل
-- أي جدول موجود سابقاً (checkins يبقى كما هو تماماً لتفادي كسر أي
-- تكامل قديم مع 03_pwa_app أو 01_flutter_mobile_app). هذه الجداول
-- تُغذّى فقط من نقطة النهاية الجديدة /v1/checkins/full (حساب من
-- طرف الخادم)، وتبقى فارغة لأي تكامل ما يزال يستخدم
-- /v1/checkins/anonymous القديمة (حساب من طرف العميل).
-- ============================================================

CREATE TABLE IF NOT EXISTS checkin_inputs (
    checkin_id TEXT PRIMARY KEY REFERENCES checkins(id),
    tenant_id TEXT NOT NULL,
    physical_fatigue REAL NOT NULL,
    mental_fatigue REAL NOT NULL,
    sleep_disruption REAL NOT NULL,
    low_empowerment REAL NOT NULL,
    low_resilience REAL NOT NULL,
    isolation REAL NOT NULL,
    day_in_rotation_cycle INTEGER NOT NULL,
    days_since_last_checkin INTEGER NOT NULL,
    hours_worked_last_24h REAL NOT NULL,
    is_night_shift INTEGER NOT NULL,
    distance_from_family_km REAL NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS checkin_risk_scores (
    id TEXT PRIMARY KEY,
    checkin_id TEXT NOT NULL REFERENCES checkins(id),
    tenant_id TEXT NOT NULL,
    risk_id TEXT NOT NULL,
    score REAL NOT NULL,
    level TEXT NOT NULL CHECK(level IN ('green','yellow','orange','red')),
    site_code TEXT,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_risk_scores_tenant_risk_created ON checkin_risk_scores(tenant_id, risk_id, created_at);
CREATE INDEX IF NOT EXISTS idx_risk_scores_site ON checkin_risk_scores(site_code);
CREATE INDEX IF NOT EXISTS idx_risk_scores_checkin ON checkin_risk_scores(checkin_id);
"""


def seed_default_tenants_if_empty():
    """Crée des tenants de démonstration si la table est vide — pratique
    pour le développement local et les tests. En production, les tenants
    sont créés via /v1/admin/tenants (voir server.py)."""
    import uuid
    from datetime import datetime, timezone

    existing = execute_read("SELECT COUNT(*) as n FROM tenants", one=True)["n"]
    if existing > 0:
        return

    demo_tenants = [
        ("Sonatrach — Pilot CPH", "pilot-demo-key-2026", 28),
    ]
    for name, api_key, cycle in demo_tenants:
        execute_write(
            "INSERT INTO tenants (id, name, api_key, rotation_cycle_days, created_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (str(uuid.uuid4()), name, api_key, cycle, datetime.now(timezone.utc).isoformat()),
        )


def init_db():
    with _db_lock:
        conn = get_connection()
        conn.execute("PRAGMA journal_mode=WAL;")  # une seule fois, persisté dans le fichier
        conn.executescript(SCHEMA)
        conn.commit()
    seed_default_tenants_if_empty()


def create_tenant(name: str, api_key: str, rotation_cycle_days: int = 28):
    """Crée un nouveau tenant. Lève sqlite3.IntegrityError si la clé API
    existe déjà (contrainte UNIQUE sur tenants.api_key) — l'appelant
    (server.py) doit intercepter cette erreur et répondre 409 Conflict."""
    import uuid
    from datetime import datetime, timezone

    tenant_id = str(uuid.uuid4())
    execute_write(
        "INSERT INTO tenants (id, name, api_key, rotation_cycle_days, created_at) "
        "VALUES (?, ?, ?, ?, ?)",
        (tenant_id, name, api_key, rotation_cycle_days, datetime.now(timezone.utc).isoformat()),
    )
    return tenant_id


def list_tenants():
    """Renvoie tous les tenants SANS exposer leur clé API en clair
    (uniquement les 4 derniers caractères, pour identification visuelle
    sans risque de fuite si la réponse est journalisée quelque part)."""
    rows = execute_read(
        "SELECT id, name, api_key, rotation_cycle_days, created_at FROM tenants ORDER BY created_at"
    )
    return [
        {
            "id": r["id"],
            "name": r["name"],
            "api_key_suffix": "..." + r["api_key"][-4:] if len(r["api_key"]) >= 4 else "***",
            "rotation_cycle_days": r["rotation_cycle_days"],
            "created_at": r["created_at"],
        }
        for r in rows
    ]


def create_worker(tenant_id: str, employee_id: str, pin: str):
    """Provisionne un nouvel employé pour un tenant donné. Lève
    sqlite3.IntegrityError si (tenant_id, employee_id) existe déjà.

    Le PIN n'est JAMAIS stocké en clair : on génère un sel aléatoire par
    employé puis on hache (sel + PIN) avec SHA-256. `worker_id_hash` est
    l'identifiant anonymisé et STABLE utilisé ensuite dans checkins et
    anonymous_reports — dérivé lui aussi par hachage, jamais l'employee_id
    en clair."""
    import uuid
    import hashlib
    import secrets
    from datetime import datetime, timezone

    worker_id = str(uuid.uuid4())
    pin_salt = secrets.token_hex(16)
    pin_hash = hashlib.sha256((pin_salt + pin).encode("utf-8")).hexdigest()
    worker_id_hash = hashlib.sha256(f"{tenant_id}:{employee_id}".encode("utf-8")).hexdigest()

    execute_write(
        "INSERT INTO workers (id, tenant_id, employee_id, pin_salt, pin_hash, worker_id_hash, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (worker_id, tenant_id, employee_id, pin_salt, pin_hash, worker_id_hash,
         datetime.now(timezone.utc).isoformat()),
    )
    return {"id": worker_id, "workerIdHash": worker_id_hash}


def verify_worker_pin(tenant_id: str, employee_id: str, pin: str):
    """Vérifie les identifiants d'un employé. Renvoie
    {'id', 'workerIdHash'} si valides, sinon None. La comparaison du
    hash utilise hmac.compare_digest pour éviter les attaques par
    mesure de temps (timing attacks)."""
    import hashlib
    import hmac as hmac_module

    row = execute_read(
        "SELECT id, pin_salt, pin_hash, worker_id_hash FROM workers "
        "WHERE tenant_id = ? AND employee_id = ?",
        (tenant_id, employee_id),
        one=True,
    )
    if row is None:
        return None

    computed = hashlib.sha256((row["pin_salt"] + pin).encode("utf-8")).hexdigest()
    if not hmac_module.compare_digest(computed, row["pin_hash"]):
        return None

    return {"id": row["id"], "workerIdHash": row["worker_id_hash"]}


def log_audit_event(actor_type: str, action: str, actor_ref: str = None,
                     target_type: str = None, target_id: str = None,
                     tenant_id: str = None, details: str = None):
    """يُسجّل حدثاً في سجل التدقيق. يُستدعى من server.py عند كل إجراء
    إداري أو أمني حساس (إنشاء عميل، تزويد عامل، نجاح/قفل تسجيل دخول).
    لا يُمرَّر أبداً أي PIN أو محتوى بلاغ مجهول كـ details — فقط بيانات
    وصفية غير حساسة."""
    import uuid
    from datetime import datetime, timezone

    execute_write(
        "INSERT INTO audit_log (id, created_at, actor_type, actor_ref, action, target_type, target_id, tenant_id, details) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (str(uuid.uuid4()), datetime.now(timezone.utc).isoformat(), actor_type, actor_ref,
         action, target_type, target_id, tenant_id, details),
    )


def list_audit_log(limit: int = 100, tenant_id: str = None, action: str = None):
    query = "SELECT * FROM audit_log"
    conditions = []
    params = []
    if tenant_id:
        conditions.append("tenant_id = ?")
        params.append(tenant_id)
    if action:
        conditions.append("action = ?")
        params.append(action)
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
    query += " ORDER BY created_at DESC LIMIT ?"
    params.append(limit)

    rows = execute_read(query, tuple(params))
    return [dict(r) for r in rows]


def insert_full_checkin(tenant_id: str, worker_id_hash: str, created_at: str, site_code,
                         bprs_score: float, risk_level: str, inputs: dict, context: dict,
                         risk_scores: list):
    """Écrit le check-in complet (PsychoTech Layer) : la ligne checkins
    existante (compatible avec les endpoints/agrégats déjà testés) +
    les entrées brutes + les 8 scores par risque, dans UNE transaction.

    `risk_scores` est une liste de dicts {id, score, level} (voir
    app/psychosocial_risks.py:RiskScore)."""
    import uuid
    from datetime import datetime, timezone

    checkin_id = str(uuid.uuid4())
    now = datetime.now(timezone.utc).isoformat()

    statements = [
        (
            "INSERT INTO checkins (id, tenant_id, worker_id_hash, created_at, bprs_score, risk_level, site_code) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (checkin_id, tenant_id, worker_id_hash, created_at, bprs_score, risk_level, site_code),
        ),
        (
            "INSERT INTO checkin_inputs (checkin_id, tenant_id, physical_fatigue, mental_fatigue, "
            "sleep_disruption, low_empowerment, low_resilience, isolation, day_in_rotation_cycle, "
            "days_since_last_checkin, hours_worked_last_24h, is_night_shift, distance_from_family_km, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                checkin_id, tenant_id,
                inputs["physical_fatigue"], inputs["mental_fatigue"], inputs["sleep_disruption"],
                inputs["low_empowerment"], inputs["low_resilience"], inputs["isolation"],
                context["day_in_rotation_cycle"], context["days_since_last_checkin"],
                context["hours_worked_last_24h"], 1 if context["is_night_shift"] else 0,
                context["distance_from_family_km"], now,
            ),
        ),
    ]
    for rs in risk_scores:
        statements.append((
            "INSERT INTO checkin_risk_scores (id, checkin_id, tenant_id, risk_id, score, level, site_code, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (str(uuid.uuid4()), checkin_id, tenant_id, rs["id"], rs["score"], rs["level"], site_code, now),
        ))

    execute_write_many(statements)
    return checkin_id


def latest_risk_scores(tenant_id: str, since_iso: str, site_code: str = None):
    """Pour chaque risk_id, renvoie le dernier score connu (le plus
    récent) dans la fenêtre temporelle donnée — alimente les pastilles
    de couleur en temps réel du tableau /v1/dashboard/risks."""
    query = ("SELECT risk_id, score, level, created_at FROM checkin_risk_scores "
             "WHERE tenant_id = ? AND created_at >= ?")
    params = [tenant_id, since_iso]
    if site_code:
        query += " AND site_code = ?"
        params.append(site_code)
    query += " ORDER BY created_at ASC"
    rows = execute_read(query, tuple(params))
    latest = {}
    for r in rows:
        latest[r["risk_id"]] = {"score": r["score"], "level": r["level"], "created_at": r["created_at"]}
    return latest


def average_risk_scores(tenant_id: str, since_iso: str, site_code: str = None):
    """Moyenne par risk_id sur la période — utilisé en complément du
    'dernier score' pour donner une tendance, pas juste un instantané."""
    query = ("SELECT risk_id, AVG(score) as avg_score, COUNT(*) as n FROM checkin_risk_scores "
             "WHERE tenant_id = ? AND created_at >= ?")
    params = [tenant_id, since_iso]
    if site_code:
        query += " AND site_code = ?"
        params.append(site_code)
    query += " GROUP BY risk_id"
    rows = execute_read(query, tuple(params))
    return {r["risk_id"]: {"avg_score": round(r["avg_score"], 1), "n": r["n"]} for r in rows}


def weekly_risk_trend(tenant_id: str, risk_id: str, start_iso: str, end_iso: str, site_code: str = None):
    query = ("SELECT AVG(score) as avg_score, COUNT(*) as n FROM checkin_risk_scores "
             "WHERE tenant_id = ? AND risk_id = ? AND created_at >= ? AND created_at < ?")
    params = [tenant_id, risk_id, start_iso, end_iso]
    if site_code:
        query += " AND site_code = ?"
        params.append(site_code)
    return execute_read(query, tuple(params), one=True)


def reset_db_for_tests():
    """Utilisé uniquement par la suite de tests — supprime le fichier
    de base de données pour repartir d'un état propre."""
    if hasattr(_local, "conn"):
        _local.conn.close()
        del _local.conn
    for suffix in ("", "-wal", "-shm"):
        path = DB_PATH + suffix
        if os.path.exists(path):
            os.remove(path)
