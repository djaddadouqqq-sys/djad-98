"""
app/rate_limiter.py

Protection contre les attaques par force brute sur /v1/auth/worker/login.
Implémentation en mémoire, thread-safe (verrou Python) — suffisante pour
un serveur mono-processus en phase Pilot. Voir la note de migration en
bas de fichier pour la mise à l'échelle.

Politique : après MAX_ATTEMPTS échecs consécutifs pour une même paire
(tenant_id, employee_id) dans la fenêtre glissante WINDOW_SECONDS, tout
nouvel essai est bloqué pendant LOCKOUT_SECONDS — même avec le bon PIN
entre-temps (sinon un attaquant pourrait "tester" si son verrou est
encore actif en devinant, ce qui fuiterait de l'information).

Un succès de connexion réinitialise immédiatement le compteur de cette
paire (un employé qui se trompe deux fois puis réussit ne doit pas rester
pénalisé).
"""

import os
import threading
import time

MAX_ATTEMPTS = int(os.environ.get("BUDDY_LOGIN_MAX_ATTEMPTS", "5"))
WINDOW_SECONDS = int(os.environ.get("BUDDY_LOGIN_WINDOW_SECONDS", "600"))     # 10 minutes
LOCKOUT_SECONDS = int(os.environ.get("BUDDY_LOGIN_LOCKOUT_SECONDS", "300"))  # 5 minutes


def configure(max_attempts=None, window_seconds=None, lockout_seconds=None):
    """Permet de surcharger les seuils au moment de l'exécution — utilisé
    par les tests pour ne pas dépendre de l'ordre d'import des modules
    (les variables d'environnement seules ne suffiraient pas, car Python
    ne réimporte pas un module déjà chargé même si l'environnement change
    entre-temps)."""
    global MAX_ATTEMPTS, WINDOW_SECONDS, LOCKOUT_SECONDS
    if max_attempts is not None:
        MAX_ATTEMPTS = max_attempts
    if window_seconds is not None:
        WINDOW_SECONDS = window_seconds
    if lockout_seconds is not None:
        LOCKOUT_SECONDS = lockout_seconds

_lock = threading.Lock()
# clé -> {"failures": [timestamps...], "locked_until": epoch|None}
_state: dict = {}


def _key(tenant_id: str, employee_id: str) -> str:
    return f"{tenant_id}:{employee_id}"


def check_locked_out(tenant_id: str, employee_id: str):
    """Renvoie le nombre de secondes restantes si verrouillé, sinon None."""
    with _lock:
        entry = _state.get(_key(tenant_id, employee_id))
        if entry is None:
            return None
        locked_until = entry.get("locked_until")
        if locked_until is not None and locked_until > time.time():
            return round(locked_until - time.time())
        return None


def record_failure(tenant_id: str, employee_id: str):
    """Enregistre un échec. Verrouille automatiquement si le seuil est
    atteint dans la fenêtre glissante."""
    with _lock:
        k = _key(tenant_id, employee_id)
        now = time.time()
        entry = _state.setdefault(k, {"failures": [], "locked_until": None})
        # ne garde que les échecs dans la fenêtre glissante
        entry["failures"] = [t for t in entry["failures"] if now - t < WINDOW_SECONDS]
        entry["failures"].append(now)
        if len(entry["failures"]) >= MAX_ATTEMPTS:
            entry["locked_until"] = now + LOCKOUT_SECONDS


def record_success(tenant_id: str, employee_id: str):
    """Réinitialise complètement l'historique de cette paire."""
    with _lock:
        _state.pop(_key(tenant_id, employee_id), None)


def reset_all_for_tests():
    """Utilisé uniquement par la suite de tests, pour repartir d'un état propre."""
    with _lock:
        _state.clear()


# MIGRATION : cette implémentation en mémoire ne survit pas à un
# redémarrage du serveur, et ne se synchronise pas entre plusieurs
# instances si le service est un jour répliqué horizontalement. Avant
# un déploiement multi-instance, remplacer par un stockage partagé
# (Redis, ou une table PostgreSQL dédiée aux tentatives).
