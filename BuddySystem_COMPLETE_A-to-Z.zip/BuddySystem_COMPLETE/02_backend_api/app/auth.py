"""
app/auth.py

Authentification multi-tenant : chaque client (Sonatrach, Schlumberger,
une entreprise de catering, etc.) possède sa PROPRE clé API, stockée dans
la table `tenants`. Résoudre la clé retourne l'identité du tenant — c'est
cette identité qui isole ensuite chaque requête dans server.py (aucune
requête ne peut jamais lire les données d'un autre tenant).

Un second niveau d'authentification, distinct, protège les endpoints
d'administration (/v1/admin/*) : une clé d'administration séparée
(BUDDY_ADMIN_KEY), qui n'appartient à aucun tenant et ne doit être
connue que de l'équipe fondatrice — jamais distribuée à un client.

AVANT MISE À L'ÉCHELLE : remplacer par OAuth2 / JWT par utilisateur au
sein de chaque tenant (ex: Firebase Auth multi-projet, ou Auth0
multi-tenant). Le principe d'isolation par tenant_id reste identique.
"""

import os
from .db import execute_read

# En production : injecter via variable d'environnement / secret manager,
# jamais en dur dans le code source.
_ADMIN_KEY = os.environ.get("BUDDY_ADMIN_KEY", "founder-admin-key-2026")


def resolve_tenant(headers):
    """Renvoie le dict du tenant (avec 'id', 'name', 'rotation_cycle_days')
    si la clé API fournie est valide, sinon None."""
    provided = headers.get("X-API-Key") or headers.get("x-api-key")
    if not provided:
        return None

    row = execute_read(
        "SELECT id, name, rotation_cycle_days FROM tenants WHERE api_key = ?",
        (provided,),
        one=True,
    )
    if row is None:
        return None
    return {"id": row["id"], "name": row["name"], "rotation_cycle_days": row["rotation_cycle_days"]}


def is_admin_authorized(headers) -> bool:
    provided = headers.get("X-Admin-Key") or headers.get("x-admin-key")
    return provided is not None and provided == _ADMIN_KEY
