"""
app/server.py

Serveur HTTP de référence pour Buddy System — Phase Pilot, MULTI-TENANT.

Chaque requête (hors /health) doit fournir une clé API valide via
l'en-tête X-API-Key. Cette clé résout un tenant précis (voir auth.py),
et TOUTES les opérations de base de données qui suivent sont filtrées
par ce tenant_id — c'est la garantie architecturale qu'un client ne
peut jamais accéder, même accidentellement, aux données d'un autre.

Endpoints :
  POST /v1/checkins/anonymous     -> enregistre un check-in anonymisé
  GET  /v1/dashboard/summary      -> KPIs agrégés pour le tableau HSE
  GET  /v1/dashboard/trend        -> tendance BPRS hebdomadaire
  POST /v1/reports/anonymous      -> signalement anonyme (mobbing, etc.)
  GET  /v1/tenant/me              -> identité du tenant courant (utile pour debug)
  GET  /health                    -> vérification de disponibilité
"""

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
import json
import uuid
from datetime import datetime, timezone

import sqlite3
from .db import (get_connection, init_db, create_tenant, list_tenants, execute_write,
                  create_worker, verify_worker_pin, log_audit_event, list_audit_log,
                  insert_full_checkin)
from .auth import resolve_tenant, is_admin_authorized
from .aggregates import dashboard_summary, weekly_trend, risk_status_summary, risk_weekly_trend
from .tokens import issue_token, verify_token
from .rate_limiter import check_locked_out, record_failure, record_success
from .bprs_engine import compute as bprs_compute, BprsInputs, RotationContext
from .psychosocial_risks import compute_all as compute_all_risks, recommend_interventions, overall_urgent_actions, RISK_DEFINITIONS_BY_ID

VALID_RISK_LEVELS = {"green", "yellow", "orange", "red"}
VALID_REPORT_CATEGORIES = {"mobbing", "harassment", "burnout", "other"}


class BuddyRequestHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def _send_cors_headers(self):
        """CORS — nécessaire pour que le tableau de bord HSE (une page
        web servie séparément, potentiellement depuis file:// ou un
        autre domaine) puisse appeler cette API depuis un navigateur.
        Sans ces en-têtes, chaque requête contenant X-API-Key échoue
        au stade du preflight OPTIONS — bug réel trouvé en testant le
        tableau de bord avec un vrai navigateur (voir Playwright)."""
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-API-Key, X-Admin-Key, X-Worker-Token")
        self.send_header("Access-Control-Max-Age", "600")

    def do_OPTIONS(self):
        """Répond aux requêtes préliminaires (preflight) que tout
        navigateur envoie automatiquement avant une requête avec des
        en-têtes personnalisés (X-API-Key, etc.)."""
        self.send_response(204)
        self._send_cors_headers()
        self.end_headers()

    def _send_json(self, status: int, payload: dict):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self._send_cors_headers()
        self.end_headers()
        self.wfile.write(body)

    def _read_json_body(self):
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        return json.loads(raw.decode("utf-8"))

    def _authenticate(self):
        """Renvoie le dict tenant si la clé API est valide, sinon envoie
        une réponse 401 et renvoie None. Chaque handler doit vérifier
        `if tenant is None: return` juste après l'appel."""
        tenant = resolve_tenant(self.headers)
        if tenant is None:
            self._send_json(401, {"error": "unauthorized", "detail": "En-tête X-API-Key manquant ou invalide."})
            return None
        return tenant

    def _require_admin(self) -> bool:
        if not is_admin_authorized(self.headers):
            self._send_json(403, {"error": "forbidden", "detail": "En-tête X-Admin-Key manquant ou invalide."})
            return False
        return True

    def _resolve_worker_id_hash(self, tenant: dict, payload: dict):
        """Si un jeton de session employé est fourni (X-Worker-Token), on
        l'utilise comme source de vérité pour l'identité — plus fiable
        qu'un workerIdHash fourni tel quel par le client. Renvoie
        (worker_id_hash, error_response_or_None). Extrait de la logique
        historique de /v1/checkins/anonymous, réutilisé aussi par
        /v1/checkins/full — comportement inchangé pour l'endpoint
        existant, testé par test_api.py."""
        worker_id_hash = payload.get("workerIdHash")
        worker_token = self.headers.get("X-Worker-Token")
        if worker_token:
            token_payload = verify_token(worker_token)
            if token_payload is None:
                return None, (401, {"error": "invalid_or_expired_worker_token"})
            if token_payload["tenantId"] != tenant["id"]:
                return None, (403, {"error": "worker_token_tenant_mismatch"})
            worker_id_hash = token_payload["workerIdHash"]
        return worker_id_hash, None

    # ---------------- GET ----------------
    def do_GET(self):
        parsed = urlparse(self.path)
        qs = parse_qs(parsed.query)

        if parsed.path == "/health":
            self._send_json(200, {"status": "ok", "time": datetime.now(timezone.utc).isoformat()})
            return

        if parsed.path == "/v1/admin/tenants":
            if not self._require_admin():
                return
            self._send_json(200, {"tenants": list_tenants()})
            return

        if parsed.path == "/v1/admin/audit-log":
            if not self._require_admin():
                return
            limit = int(qs.get("limit", [100])[0])
            tenant_id = qs.get("tenant_id", [None])[0]
            action = qs.get("action", [None])[0]
            self._send_json(200, {"entries": list_audit_log(limit=limit, tenant_id=tenant_id, action=action)})
            return

        if parsed.path == "/v1/tenant/me":
            tenant = self._authenticate()
            if tenant is None:
                return
            self._send_json(200, {"tenant": tenant})
            return

        if parsed.path == "/v1/dashboard/summary":
            tenant = self._authenticate()
            if tenant is None:
                return
            days = int(qs.get("days", [30])[0])
            site_code = qs.get("site_code", [None])[0]
            self._send_json(200, dashboard_summary(tenant["id"], days=days, site_code=site_code))
            return

        if parsed.path == "/v1/dashboard/trend":
            tenant = self._authenticate()
            if tenant is None:
                return
            weeks = int(qs.get("weeks", [6])[0])
            site_code = qs.get("site_code", [None])[0]
            self._send_json(200, {"trend": weekly_trend(tenant["id"], weeks=weeks, site_code=site_code)})
            return

        if parsed.path == "/v1/dashboard/risks":
            # PsychoTech Layer — الحالة الحية للمخاطر النفسية الثمانية.
            # الألوان هنا محسوبة من checkin_risk_scores الفعلية (عبر
            # /v1/checkins/full)، وليست ألواناً ثابتة بالواجهة. إن لم
            # تصل بيانات بعد، كل خطر يعود status='no_data' صراحة.
            tenant = self._authenticate()
            if tenant is None:
                return
            days = int(qs.get("days", [30])[0])
            site_code = qs.get("site_code", [None])[0]
            self._send_json(200, risk_status_summary(tenant["id"], days=days, site_code=site_code))
            return

        if parsed.path == "/v1/dashboard/risk-trend":
            tenant = self._authenticate()
            if tenant is None:
                return
            risk_id = qs.get("risk_id", [None])[0]
            if risk_id not in RISK_DEFINITIONS_BY_ID:
                self._send_json(422, {"error": "invalid_risk_id", "allowed": list(RISK_DEFINITIONS_BY_ID.keys())})
                return
            weeks = int(qs.get("weeks", [6])[0])
            site_code = qs.get("site_code", [None])[0]
            self._send_json(200, {
                "risk_id": risk_id,
                "trend": risk_weekly_trend(tenant["id"], risk_id, weeks=weeks, site_code=site_code),
            })
            return

        self._send_json(404, {"error": "not_found", "path": parsed.path})

    # ---------------- POST ----------------
    def do_POST(self):
        parsed = urlparse(self.path)

        if parsed.path == "/v1/admin/tenants":
            if not self._require_admin():
                return
            try:
                payload = self._read_json_body()
            except json.JSONDecodeError:
                self._send_json(400, {"error": "invalid_json"})
                return

            required = ["name", "apiKey"]
            missing = [f for f in required if f not in payload]
            if missing:
                self._send_json(422, {"error": "missing_fields", "fields": missing})
                return

            rotation_days = int(payload.get("rotationCycleDays", 28))
            try:
                tenant_id = create_tenant(
                    name=payload["name"],
                    api_key=payload["apiKey"],
                    rotation_cycle_days=rotation_days,
                )
            except sqlite3.IntegrityError:
                self._send_json(409, {"error": "api_key_already_exists"})
                return

            log_audit_event(
                actor_type="admin", action="tenant_created",
                target_type="tenant", target_id=tenant_id, tenant_id=tenant_id,
                details=f"name={payload['name']}, rotationCycleDays={rotation_days}",
            )
            self._send_json(201, {"id": tenant_id, "name": payload["name"], "stored": True})
            return

        if parsed.path == "/v1/admin/workers":
            if not self._require_admin():
                return
            try:
                payload = self._read_json_body()
            except json.JSONDecodeError:
                self._send_json(400, {"error": "invalid_json"})
                return

            required = ["tenantId", "employeeId", "pin"]
            missing = [f for f in required if f not in payload]
            if missing:
                self._send_json(422, {"error": "missing_fields", "fields": missing})
                return

            if len(str(payload["pin"])) < 4:
                self._send_json(422, {"error": "pin_too_short", "detail": "Le PIN doit contenir au moins 4 caractères."})
                return

            try:
                worker = create_worker(
                    tenant_id=payload["tenantId"],
                    employee_id=payload["employeeId"],
                    pin=str(payload["pin"]),
                )
            except sqlite3.IntegrityError:
                self._send_json(409, {"error": "employee_already_provisioned"})
                return

            log_audit_event(
                actor_type="admin", action="worker_provisioned",
                target_type="worker", target_id=worker["id"], tenant_id=payload["tenantId"],
                details=f"employeeId={payload['employeeId']}",  # لا يُسجَّل الـPIN أبداً
            )
            self._send_json(201, {"id": worker["id"], "stored": True})
            return

        if parsed.path == "/v1/auth/worker/login":
            tenant = self._authenticate()
            if tenant is None:
                return
            try:
                payload = self._read_json_body()
            except json.JSONDecodeError:
                self._send_json(400, {"error": "invalid_json"})
                return

            if "employeeId" not in payload or "pin" not in payload:
                self._send_json(422, {"error": "missing_fields", "fields": ["employeeId", "pin"]})
                return

            employee_id = payload["employeeId"]

            locked_seconds = check_locked_out(tenant["id"], employee_id)
            if locked_seconds is not None:
                log_audit_event(
                    actor_type="system", action="login_blocked_rate_limit",
                    target_type="worker_login", target_id=employee_id, tenant_id=tenant["id"],
                    details=f"retryAfterSeconds={locked_seconds}",
                )
                self._send_json(429, {
                    "error": "too_many_attempts",
                    "retryAfterSeconds": locked_seconds,
                    "detail": f"عدد كبير من المحاولات الفاشلة. أعد المحاولة بعد {locked_seconds} ثانية.",
                })
                return

            worker = verify_worker_pin(tenant["id"], employee_id, str(payload["pin"]))
            if worker is None:
                record_failure(tenant["id"], employee_id)
                log_audit_event(
                    actor_type="system", action="login_failed",
                    target_type="worker_login", target_id=employee_id, tenant_id=tenant["id"],
                )
                self._send_json(401, {"error": "invalid_credentials"})
                return

            record_success(tenant["id"], employee_id)
            token = issue_token(tenant["id"], worker["workerIdHash"])
            log_audit_event(
                actor_type="worker", action="login_success",
                actor_ref=worker["workerIdHash"], target_type="worker_login",
                target_id=employee_id, tenant_id=tenant["id"],
            )
            self._send_json(200, {"token": token, "workerIdHash": worker["workerIdHash"]})
            return

        if parsed.path == "/v1/checkins/anonymous":
            tenant = self._authenticate()
            if tenant is None:
                return
            try:
                payload = self._read_json_body()
            except json.JSONDecodeError:
                self._send_json(400, {"error": "invalid_json"})
                return

            required = ["workerIdHash", "createdAt", "bprsScore", "riskLevel"]
            missing = [f for f in required if f not in payload]
            if missing:
                self._send_json(422, {"error": "missing_fields", "fields": missing})
                return

            if payload["riskLevel"] not in VALID_RISK_LEVELS:
                self._send_json(422, {"error": "invalid_risk_level", "allowed": list(VALID_RISK_LEVELS)})
                return

            # Le jeton doit appartenir au MÊME tenant que la clé API
            # utilisée, sinon la requête est rejetée (voir helper).
            worker_id_hash, err = self._resolve_worker_id_hash(tenant, payload)
            if err is not None:
                self._send_json(*err)
                return

            checkin_id = str(uuid.uuid4())
            execute_write(
                "INSERT INTO checkins (id, tenant_id, worker_id_hash, created_at, bprs_score, risk_level, site_code) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    checkin_id,
                    tenant["id"],
                    worker_id_hash,
                    payload["createdAt"],
                    float(payload["bprsScore"]),
                    payload["riskLevel"],
                    payload.get("siteCode"),
                ),
            )
            self._send_json(201, {"id": checkin_id, "stored": True, "tenant": tenant["name"]})
            return

        if parsed.path == "/v1/checkins/full":
            # PsychoTech Layer — على عكس /v1/checkins/anonymous (يثق
            # بدرجة BPRS محسوبة من طرف العميل)، هذه النقطة تستقبل
            # المُدخلات الستة الخام + سياق الدورة، وتحسب الدرجة العامة
            # والمخاطر الثمانية من طرف الخادم نفسه — الخادم هو مصدر
            # الحقيقة هنا، لا العميل. هذا يتيح أيضاً حفظ تفصيل كل خطر
            # للتتبع الزمني (checkin_risk_scores)، وهو ما لا يوفره
            # المسار القديم.
            tenant = self._authenticate()
            if tenant is None:
                return
            try:
                payload = self._read_json_body()
            except json.JSONDecodeError:
                self._send_json(400, {"error": "invalid_json"})
                return

            required_inputs = ["physicalFatigue", "mentalFatigue", "sleepDisruption",
                                "lowEmpowerment", "lowResilience", "isolation"]
            required_context = ["dayInRotationCycle", "daysSinceLastCheckin",
                                 "hoursWorkedLast24h", "isNightShift", "distanceFromFamilyKm"]
            missing = [f for f in (required_inputs + required_context + ["createdAt"]) if f not in payload]
            if missing:
                self._send_json(422, {"error": "missing_fields", "fields": missing})
                return

            worker_id_hash, err = self._resolve_worker_id_hash(tenant, payload)
            if err is not None:
                self._send_json(*err)
                return
            if not worker_id_hash:
                self._send_json(422, {"error": "missing_fields", "fields": ["workerIdHash"]})
                return

            try:
                inputs = BprsInputs(
                    physical_fatigue=float(payload["physicalFatigue"]),
                    mental_fatigue=float(payload["mentalFatigue"]),
                    sleep_disruption=float(payload["sleepDisruption"]),
                    low_empowerment=float(payload["lowEmpowerment"]),
                    low_resilience=float(payload["lowResilience"]),
                    isolation=float(payload["isolation"]),
                )
                ctx = RotationContext(
                    day_in_rotation_cycle=int(payload["dayInRotationCycle"]),
                    days_since_last_checkin=int(payload["daysSinceLastCheckin"]),
                    hours_worked_last_24h=float(payload["hoursWorkedLast24h"]),
                    is_night_shift=bool(payload["isNightShift"]),
                    distance_from_family_km=float(payload["distanceFromFamilyKm"]),
                )
            except (TypeError, ValueError):
                self._send_json(422, {"error": "invalid_field_type"})
                return

            bprs_result = bprs_compute(ctx, inputs)
            risk_scores = compute_all_risks(inputs, ctx)

            checkin_id = insert_full_checkin(
                tenant_id=tenant["id"], worker_id_hash=worker_id_hash,
                created_at=payload["createdAt"], site_code=payload.get("siteCode"),
                bprs_score=bprs_result.score, risk_level=bprs_result.level.value,
                inputs={
                    "physical_fatigue": inputs.physical_fatigue, "mental_fatigue": inputs.mental_fatigue,
                    "sleep_disruption": inputs.sleep_disruption, "low_empowerment": inputs.low_empowerment,
                    "low_resilience": inputs.low_resilience, "isolation": inputs.isolation,
                },
                context={
                    "day_in_rotation_cycle": ctx.day_in_rotation_cycle,
                    "days_since_last_checkin": ctx.days_since_last_checkin,
                    "hours_worked_last_24h": ctx.hours_worked_last_24h,
                    "is_night_shift": ctx.is_night_shift,
                    "distance_from_family_km": ctx.distance_from_family_km,
                },
                risk_scores=[{"id": rs.id, "score": rs.score, "level": rs.level.value} for rs in risk_scores],
            )

            any_red = any(rs.level.value == "red" for rs in risk_scores) or bprs_result.level.value == "red"
            if any_red:
                log_audit_event(
                    actor_type="system", action="red_alert_triggered",
                    target_type="checkin", target_id=checkin_id, tenant_id=tenant["id"],
                    details=f"bprsScore={bprs_result.score}",  # لا هوية عامل هنا أيضاً
                )

            self._send_json(201, {
                "id": checkin_id, "stored": True,
                "bprs": {"score": bprs_result.score, "level": bprs_result.level.value,
                         "levelLabelAr": bprs_result.level_label_ar,
                         "passiveRiskFactors": bprs_result.passive_risk_factors},
                "risks": [
                    {
                        "id": rs.id, "nameAr": rs.name_ar, "icon": rs.icon,
                        "score": rs.score, "level": rs.level.value, "levelLabelAr": rs.level_label_ar,
                        "reasons": rs.reasons, "standardRefs": rs.standard_refs,
                        "clinicalCaution": rs.clinical_caution,
                        "interventions": recommend_interventions(rs),
                    }
                    for rs in risk_scores
                ],
                "urgent": any_red,
                "urgentActions": overall_urgent_actions(risk_scores) if any_red else [],
            })
            return

        if parsed.path == "/v1/reports/anonymous":
            tenant = self._authenticate()
            if tenant is None:
                return
            try:
                payload = self._read_json_body()
            except json.JSONDecodeError:
                self._send_json(400, {"error": "invalid_json"})
                return

            if "category" not in payload or "message" not in payload:
                self._send_json(422, {"error": "missing_fields", "fields": ["category", "message"]})
                return
            if payload["category"] not in VALID_REPORT_CATEGORIES:
                self._send_json(422, {"error": "invalid_category", "allowed": list(VALID_REPORT_CATEGORIES)})
                return
            if not payload["message"].strip():
                self._send_json(422, {"error": "empty_message"})
                return

            report_id = str(uuid.uuid4())
            execute_write(
                "INSERT INTO anonymous_reports (id, tenant_id, created_at, category, site_code, message) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    report_id,
                    tenant["id"],
                    datetime.now(timezone.utc).isoformat(),
                    payload["category"],
                    payload.get("siteCode"),
                    payload["message"].strip(),
                ),
            )
            self._send_json(201, {"id": report_id, "stored": True})
            return

        self._send_json(404, {"error": "not_found", "path": parsed.path})


def create_server(host="0.0.0.0", port=8000):
    init_db()
    server = ThreadingHTTPServer((host, port), BuddyRequestHandler)
    return server


if __name__ == "__main__":
    srv = create_server()
    print("Buddy System API — écoute sur http://0.0.0.0:8000")
    srv.serve_forever()
