/**
 * js/sync.js
 *
 * يزامن فعلياً مع الخادم الحقيقي المُختبر (buddy_backend). عند فشل
 * الاتصال (لا خادم، لا إنترنت)، يفشل بصمت ويُبقي العنصر غير مُزامَن
 * محلياً — نفس سلوك sync_service.dart في نسخة Flutter تماماً.
 */

const BuddySync = {
  config: { apiUrl: '', apiKey: '', workerToken: null },

  configure({ apiUrl, apiKey, workerToken }) {
    this.config.apiUrl = apiUrl.replace(new RegExp('/+$'), '');
    this.config.apiKey = apiKey;
    this.config.workerToken = workerToken || null;
  },

  async syncAll() {
    const result = { checkinsPushed: 0, reportsPushed: 0, failed: 0 };
    if (!this.config.apiUrl || !this.config.apiKey) return result;

    const pendingCheckins = await BuddyDB.getPendingCheckins();
    for (const c of pendingCheckins) {
      const ok = await this._pushCheckin(c);
      if (ok) { await BuddyDB.markCheckinSynced(c.id); result.checkinsPushed++; }
      else result.failed++;
    }

    const pendingReports = await BuddyDB.getPendingReports();
    for (const r of pendingReports) {
      const ok = await this._pushReport(r);
      if (ok) { await BuddyDB.markReportSynced(r.id); result.reportsPushed++; }
      else result.failed++;
    }

    return result;
  },

  async _pushCheckin(c) {
    try {
      const headers = { 'Content-Type': 'application/json', 'X-API-Key': this.config.apiKey };
      if (this.config.workerToken) headers['X-Worker-Token'] = this.config.workerToken;

      const res = await fetch(this.config.apiUrl + '/v1/checkins/anonymous', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          workerIdHash: c.workerIdHash,
          createdAt: c.createdAt,
          bprsScore: c.bprsScore,
          riskLevel: c.riskLevel,
          siteCode: c.siteCode,
        }),
      });
      return res.status === 201;
    } catch (e) {
      return false;
    }
  },

  async _pushReport(r) {
    try {
      const res = await fetch(this.config.apiUrl + '/v1/reports/anonymous', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-API-Key': this.config.apiKey },
        // ملاحظة أمانة متعمَّدة: X-Worker-Token لا يُرفَق هنا إطلاقاً،
        // تماماً كما في sync_service.dart — البلاغ المجهول يبقى مجهولاً
        // حتى لو كان العامل مسجّلاً دخوله.
        body: JSON.stringify({ category: r.category, message: r.message, siteCode: r.siteCode }),
      });
      return res.status === 201;
    } catch (e) {
      return false;
    }
  },

  async login(apiUrl, apiKey, employeeId, pin) {
    try {
      const res = await fetch(apiUrl.replace(new RegExp('/+$'), '') + '/v1/auth/worker/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-API-Key': apiKey },
        body: JSON.stringify({ employeeId, pin }),
      });
      const body = await res.json();
      if (res.status === 200) return { success: true, token: body.token, workerIdHash: body.workerIdHash };
      return { success: false, error: body.error || res.status, detail: body.detail };
    } catch (e) {
      return { success: false, error: 'network_error' };
    }
  },
};
