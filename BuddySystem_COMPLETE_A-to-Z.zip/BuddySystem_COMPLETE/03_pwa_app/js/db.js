/**
 * js/db.js
 *
 * طبقة التخزين المحلي الحقيقية — تلعب نفس دور Hive في نسخة Flutter.
 * تستخدم IndexedDB (قاعدة بيانات حقيقية مدمجة في المتصفح، لا مجرد
 * localStorage بسيط) لتخزين نبضات العافية والبلاغات المجهولة محلياً
 * أولاً، بغض النظر عن توفر الاتصال — هذا هو جوهر Offline-First.
 *
 * ملاحظة أمانة: التخزين هنا غير مشفّر AES-256 كما في نسخة Flutter
 * (المتصفح لا يوفر وصولاً مباشراً لـKeystore/Keychain كما يفعل الهاتف).
 * هذا قيد حقيقي موثّق في README، لا ادّعاء زائف بتطابق كامل مع الهاتف.
 */

const DB_NAME = 'buddy_system_db';
const DB_VERSION = 1;
const STORE_CHECKINS = 'checkins';
const STORE_REPORTS = 'reports';

function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(STORE_CHECKINS)) {
        const store = db.createObjectStore(STORE_CHECKINS, { keyPath: 'id' });
        store.createIndex('syncedToServer', 'syncedToServer', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_REPORTS)) {
        const store = db.createObjectStore(STORE_REPORTS, { keyPath: 'id' });
        store.createIndex('syncedToServer', 'syncedToServer', { unique: false });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function tx(db, storeName, mode) {
  return db.transaction(storeName, mode).objectStore(storeName);
}

const BuddyDB = {
  async saveCheckin(checkin) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const req = tx(db, STORE_CHECKINS, 'readwrite').put(checkin);
      req.onsuccess = () => resolve(checkin);
      req.onerror = () => reject(req.error);
    });
  },

  async getAllCheckins() {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const req = tx(db, STORE_CHECKINS, 'readonly').getAll();
      req.onsuccess = () => resolve(req.result.sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
      req.onerror = () => reject(req.error);
    });
  },

  async getPendingCheckins() {
    const all = await this.getAllCheckins();
    return all.filter(c => !c.syncedToServer);
  },

  async markCheckinSynced(id) {
    const db = await openDb();
    const store = tx(db, STORE_CHECKINS, 'readwrite');
    return new Promise((resolve, reject) => {
      const getReq = store.get(id);
      getReq.onsuccess = () => {
        const item = getReq.result;
        if (item) {
          item.syncedToServer = true;
          const putReq = store.put(item);
          putReq.onsuccess = () => resolve();
          putReq.onerror = () => reject(putReq.error);
        } else resolve();
      };
      getReq.onerror = () => reject(getReq.error);
    });
  },

  async saveReport(report) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const req = tx(db, STORE_REPORTS, 'readwrite').put(report);
      req.onsuccess = () => resolve(report);
      req.onerror = () => reject(req.error);
    });
  },

  async getPendingReports() {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const req = tx(db, STORE_REPORTS, 'readonly').getAll();
      req.onsuccess = () => resolve(req.result.filter(r => !r.syncedToServer));
      req.onerror = () => reject(req.error);
    });
  },

  async markReportSynced(id) {
    const db = await openDb();
    const store = tx(db, STORE_REPORTS, 'readwrite');
    return new Promise((resolve, reject) => {
      const getReq = store.get(id);
      getReq.onsuccess = () => {
        const item = getReq.result;
        if (item) {
          item.syncedToServer = true;
          const putReq = store.put(item);
          putReq.onsuccess = () => resolve();
          putReq.onerror = () => reject(putReq.error);
        } else resolve();
      };
      getReq.onerror = () => reject(getReq.error);
    });
  },

  async daysSinceLastCheckin() {
    const all = await this.getAllCheckins();
    if (all.length === 0) return 999;
    const latest = new Date(all[0].createdAt);
    const diffMs = Date.now() - latest.getTime();
    return Math.floor(diffMs / (1000 * 60 * 60 * 24));
  },
};
