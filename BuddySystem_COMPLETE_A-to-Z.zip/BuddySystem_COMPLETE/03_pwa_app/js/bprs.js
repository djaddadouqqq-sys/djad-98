/**
 * js/bprs.js
 *
 * نفس معادلة app/bprs_engine.py و lib/services/bprs_engine.dart بالضبط —
 * الأوزان الستة، وعتبات المخاطر السلبية، ونطاقات الألوان مطابقة حرفياً.
 * سبق التحقق من هذه المعادلة تحديداً بالضبط في bprs.html وأعطت 84.8
 * لنفس مدخلات "السيناريو 3" الموثّقة في اختبارات الخادم.
 */

const BprsEngine = {
  WEIGHTS: {
    physicalFatigue: 0.18,
    mentalFatigue: 0.18,
    sleep: 0.16,
    empowerment: 0.16,
    resilience: 0.16,
    isolation: 0.16,
  },

  compute(inputs, context) {
    const w = this.WEIGHTS;
    const weighted =
      inputs.physicalFatigue * w.physicalFatigue +
      inputs.mentalFatigue * w.mentalFatigue +
      inputs.sleep * w.sleep +
      inputs.empowerment * w.empowerment +
      inputs.resilience * w.resilience +
      inputs.isolation * w.isolation;

    let score = weighted * 10;
    const reasons = [];

    if (context.daysSinceCheckin >= 7) {
      score += 15;
      reasons.push(`لم يسجّل العامل أي بيانات منذ ${context.daysSinceCheckin} أيام — ارتفاع تلقائي للحذر`);
    } else if (context.daysSinceCheckin >= 3) {
      score += 7;
      reasons.push(`غياب متابعة لمدة ${context.daysSinceCheckin} أيام`);
    }

    if (context.dayInCycle >= 21) {
      score += 10;
      reasons.push(`اليوم ${context.dayInCycle} من دورة 28/28 — تجاوز عتبة التراكم النفسي الموثقة`);
    }
    if (context.hoursWorked > 12) {
      score += 8;
      reasons.push(`${context.hoursWorked} ساعة عمل خلال 24 ساعة — يتجاوز عتبة API RP 755`);
    }
    if (context.nightShift) {
      score += 5;
      reasons.push('مناوبة ليلية — عامل خطر إضافي موثّق');
    }
    if (context.distanceKm >= 700) {
      score += 5;
      reasons.push('بُعد جغرافي عن الأسرة يفوق 700 كم — عتبة موثّقة ميدانياً');
    }

    score = Math.max(0, Math.min(100, score));

    let level, labelAr;
    if (score < 30) { level = 'green'; labelAr = 'أخضر — استفسار'; }
    else if (score < 55) { level = 'yellow'; labelAr = 'أصفر — متابعة وتبليغ'; }
    else if (score < 75) { level = 'orange'; labelAr = 'برتقالي — تدخل'; }
    else { level = 'red'; labelAr = 'أحمر — تدخل نفسي فوري'; }

    return { score: Math.round(score * 10) / 10, level, labelAr, reasons };
  },
};
