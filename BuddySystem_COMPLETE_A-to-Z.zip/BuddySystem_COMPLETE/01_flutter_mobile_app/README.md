## 🔧 تحديث — إصلاح فعلي لبنية المشروع (وليس دليل تشغيل فقط)

هذا القسم يوثّق بصدق ما تغيّر فعلاً في هذه الجلسة. **لم يتم تشغيل أي أمر
Flutter/Gradle فعلياً** — البيئة التي كُتب فيها هذا الإصلاح لا تحتوي على
Flutter SDK ولا Android SDK ولا اتصال شبكة صادر (نفس القيد الموثَّق سابقاً
في هذا الملف). كل ما يلي هو **مراجعة يدوية دقيقة وإصلاح ساكن (static)**،
وليس نتيجة اختبار فعلي — يجب تشغيل `flutter pub get && flutter analyze &&
flutter test && flutter build apk --debug` على جهازك للتأكد.

**ما تم إصلاحه فعلياً في الكود:**
1. `lib/services/worker_auth_service.dart` — إصلاح جذري لمشكلة
   `workerIdHash`: كان `'local-fallback-hash'` قيمة ثابتة مكررة في كل من
   `checkin_screen.dart` و`home_screen.dart`. الآن `WorkerAuthService`
   يخزّن `workerIdHash` الحقيقي المُعاد من `/v1/auth/worker/login`، ويوفّر
   `getEffectiveWorkerIdHash()` كمصدر وحيد للهوية: التوكن المصادَق عليه إن
   وُجد، وإلا معرّف مجهول ثابت لكل جهاز (وليس قيمة مشتركة بين كل
   المستخدمين المجهولين).
2. `lib/models/daily_checkin.g.dart` و`lib/models/anonymous_report.g.dart`
   — كُتبا يدوياً (لا يوجد Dart SDK لتشغيل `build_runner`) ليطابقا تماماً
   المخرجات القياسية لـ`hive_generator` بناءً على حقول `@HiveField` في كل
   نموذج.
3. `android/` — بنية كاملة جديدة (كانت غائبة تماماً): `settings.gradle`,
   `build.gradle`, `gradle.properties`, `app/build.gradle`
   (compileSdk 34 / minSdk 23 / Java 17)، AndroidManifest (main/debug/
   profile)، `MainActivity.kt`، أيقونات، وأهم من ذلك:
   `network_security_config.xml` للسماح بـHTTP الصريح (لأن
   `SyncConfig.apiBaseUrl` يستخدم `http://` وAndroid 9+ يحجب هذا افتراضياً
   — بدون هذا الملف كانت كل طلبات الشبكة ستفشل بصمت على أي جهاز حقيقي).
4. `lib/main.dart` — تمت إضافة محاولة مزامنة عند بدء التشغيل (وليس فقط عند
   تغيّر حالة الاتصال)، لإصلاح ثغرة منطقية في مسار Offline→Sync.
5. `lib/screens/anonymous_report_screen.dart` — أضيفت نفس محاولة المزامنة
   الفورية بعد الإرسال المحلي، بما يطابق سلوك `checkin_screen.dart`.
6. `analysis_options.yaml` — لم يكن موجوداً رغم أن `flutter_lints` معلن في
   `pubspec.yaml`.

**ما لا يزال ناقصاً ويتطلب جهازك/بيئتك (موثّق بالتفصيل في تقرير المحادثة):**
`android/gradle/wrapper/gradle-wrapper.jar` (ملف ثنائي لا يمكن توليده بدون
اتصال شبكة أو Gradle مثبّت محلياً)، تنفيذ فعلي لـ`flutter pub get` /
`flutter analyze` / `flutter test` / `flutter build apk --debug`، وربط
`workmanager` فعلياً للمزامنة الخلفية (معلنة كاعتمادية لكن غير مُهيَّأة في
الكود بعد).

---

# Buddy System — Base de code Flutter (MVP réel)

Ce dossier n'est **pas une maquette**. C'est un vrai projet Flutter, avec une
logique métier correcte et testée (voir `test/bprs_engine_test.dart`), que
vous pouvez ouvrir dans VS Code / Android Studio, lancer
`flutter pub get`, puis `flutter run`, à condition d'avoir le SDK Flutter
installé sur votre machine (ce que l'environnement où j'ai écrit ce code
ne possède pas — je n'ai donc pas pu compiler ni exécuter ce projet
moi-même ; je l'ai vérifié ligne par ligne et testé sa logique à la main,
voir plus bas, mais **faites tourner `flutter pub get` et `flutter test`
vous-même avant de faire confiance à 100%**).

## Ce qui est réellement fonctionnel dans ce code

| Composant | État | Fichier |
|---|---|---|
| Moteur BPRS (score composite + 4 niveaux de couleur + majoration passive) | ✅ Logique complète, testée manuellement (4 scénarios tracés à la main) | `lib/services/bprs_engine.dart` |
| Stockage local chiffré (Hive + AES-256 + clé en Keystore/Keychain) | ✅ Pattern correct et standard | `lib/services/local_storage_service.dart` |
| Modèle de données du check-in quotidien | ✅ | `lib/models/daily_checkin.dart` |
| Modèle du signalement anonyme (aucun champ d'identité, par conception) | ✅ | `lib/models/anonymous_report.dart` |
| 3 écrans MVP (Entrée, Check-in, Accueil) + écran Signalement anonyme | ✅ Widgets Flutter réels et cohérents, câblés à Hive + au backend testé | `lib/screens/*.dart` |
| Tests unitaires du moteur BPRS | ✅ 4 tests, logique vérifiée manuellement | `test/bprs_engine_test.dart` |
| Synchronisation vers un serveur central | 🟢 **Câblé vers un vrai backend testé** (`buddy_backend/`, 9/9 tests passants) — reste à ajuster `SyncConfig.apiBaseUrl` selon l'environnement de déploiement | `lib/services/sync_service.dart` |
| Hachage sécurisé de l'identifiant employé | 🟡 **STUB** — utilise un placeholder, pas encore un vrai hash (SHA-256 + sel) | `lib/screens/checkin_screen.dart` |
| Backend FastAPI / PostgreSQL | ❌ **N'existe pas encore** — rien n'a été écrit côté serveur | — |
| Tableau de bord HSE | ❌ **N'existe pas dans ce code** — la maquette visuelle existe (fichiers PNG/HTML fournis séparément dans la conversation), mais aucune app web/dashboard réelle n'est câblée dessus | — |
| Intelligence artificielle / prédiction | ❌ **N'existe pas** — aucun modèle ML n'a été entraîné ni intégré | — |
| Authentification réelle (Firebase Auth ou équivalent) | 🟢 **Câblée vers le vrai système d'authentification par employé** (`/v1/auth/worker/login`, testé 22/22 côté backend) — voir `lib/services/worker_auth_service.dart` et l'écran `entry_screen.dart` | — |

## Pourquoi je m'arrête ici, honnêtement

Vous avez demandé un système de plus de 100 écrans avec IA, backend
PostgreSQL, tableaux de bord complets, tests d'intégration et documentation
technique complète, livré en 28 jours. Je suis un assistant conversationnel :
je n'ai pas de processus d'exécution autonome de 28 jours, et je n'ai pas
d'environnement Flutter/serveur pour compiler, déployer ou tester ce projet
en conditions réelles dans cette session. Vous promettre cela serait
recommencer exactement l'erreur qui vous a déçu précédemment — une promesse
plus grande, suivie du même échec.

Ce que j'ai fait à la place : écrire le **véritable cœur scientifique et
architectural** du projet — le moteur de calcul BPRS (votre propriété
intellectuelle la plus importante) et le pattern Offline-First complet —
avec un code correct, commenté, et prêt à être repris par un développeur
Flutter réel.

## Mise à jour : l'authentification par employé est maintenant câblée de bout en bout

L'écran d'entrée appelle réellement `POST /v1/auth/worker/login`. En cas de
succès, le jeton signé est stocké dans `flutter_secure_storage` et joint
automatiquement (`X-Worker-Token`) à chaque check-in synchronisé — le
serveur en fait alors la source de vérité pour l'identité (voir
`buddy_backend/README.md`, section authentification individuelle). Le
bouton "الدخول بشكل مجهول" reste disponible et ne stocke aucun jeton —
comportement volontaire pour préserver le choix de confidentialité totale.

## Mise à jour : le backend Pilot existe déjà et est testé

Un backend réel (Python stdlib, sans dépendances externes, 9/9 tests
d'intégration passants) est fourni séparément dans `buddy_backend/`.
`sync_service.dart` y est déjà câblé — il ne reste qu'à :
1. Déployer `buddy_backend/` sur un serveur accessible depuis les sites Sonatrach
2. Mettre à jour `SyncConfig.apiBaseUrl` dans `sync_service.dart`
3. Générer un vrai hash (SHA-256 + sel) pour `workerIdHash` avant la mise en Pilot

## Plan de construction réaliste (à donner à un développeur)

Ceci correspond exactement à ce que vos propres notes techniques
recommandent — un MVP progressif, pas une plateforme géante d'un coup :

**Semaines 1–2 — Fondations**
- Reprendre ce code, exécuter `flutter pub get`, `flutter test`
- Générer les adaptateurs Hive (`flutter pub run build_runner build`)
- Brancher une vraie authentification (Firebase Auth ou backend maison)
- Implémenter le hachage réel de l'identifiant (SHA-256 + sel)

**Semaines 3–5 — Cœur fonctionnel**
- Construire le vrai backend FastAPI (endpoints `/checkins/anonymous`,
  authentification par jeton)
- Câbler `sync_service.dart` dessus (remplacer le stub)
- Ajouter le module "Signalement anonyme" (mobbing/tension)

**Semaines 6–8 — Tableau HSE**
- Construire une vraie application web (ex: Next.js ou Flutter Web) qui
  consomme les agrégats anonymisés du backend
- Reproduire les KPI déjà validés dans la maquette (taux d'absentéisme,
  score BPRS moyen, carte de chaleur par site)

**Semaines 9–12 — Pilot Sonatrach**
- Déploiement sur 10 à 20 travailleurs volontaires (comme le recommandent
  vos propres notes)
- Itération sur les retours réels avant tout déploiement plus large

## Comment vérifier ce code vous-même

```bash
cd buddy_system
flutter pub get
flutter pub run build_runner build --delete-conflicting-outputs
flutter test        # doit faire passer les 4 tests de bprs_engine_test.dart
flutter run         # lance l'app sur un émulateur ou un téléphone connecté
```

Si `flutter test` échoue, c'est une information réelle et utile — corrigez
avant d'aller plus loin. Je préfère que vous trouviez une erreur maintenant,
par vous-même, plutôt que je vous assure que "tout fonctionne" sans l'avoir
vérifié.
