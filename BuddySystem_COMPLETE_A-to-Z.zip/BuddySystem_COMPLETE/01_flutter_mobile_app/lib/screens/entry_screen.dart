/// lib/screens/entry_screen.dart
/// Écran d'entrée — appelle réellement WorkerAuthService (voir
/// services/worker_auth_service.dart), qui appelle le vrai backend testé.
library entry_screen;

import 'package:flutter/material.dart';
import 'home_screen.dart';
import '../services/worker_auth_service.dart';

class BuddyColors {
  static const paper = Color(0xFFF7F4EE);
  static const navy = Color(0xFF0F2A3D);
  static const terracotta = Color(0xFFBE6A47);
  static const sage = Color(0xFF4F8C7A);
  static const ink = Color(0xFF20262B);
  static const inkSoft = Color(0xFF5B6570);
}

class EntryScreen extends StatefulWidget {
  const EntryScreen({super.key});

  @override
  State<EntryScreen> createState() => _EntryScreenState();
}

class _EntryScreenState extends State<EntryScreen> {
  final _employeeIdController = TextEditingController();
  final _pinController = TextEditingController();
  final _workerAuth = WorkerAuthService();

  bool _loading = false;
  String? _errorText;

  @override
  void dispose() {
    _employeeIdController.dispose();
    _pinController.dispose();
    super.dispose();
  }

  void _goHome() {
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const HomeScreen()),
    );
  }

  Future<void> _login() async {
    if (_employeeIdController.text.trim().isEmpty || _pinController.text.trim().isEmpty) {
      setState(() => _errorText = 'يرجى إدخال الرقم الوظيفي والرمز السري.');
      return;
    }

    setState(() {
      _loading = true;
      _errorText = null;
    });

    final result = await _workerAuth.login(
      employeeId: _employeeIdController.text.trim(),
      pin: _pinController.text.trim(),
    );

    if (!mounted) return;
    setState(() => _loading = false);

    if (result.success) {
      _goHome();
    } else {
      setState(() => _errorText = result.errorMessage);
    }
  }

  /// الدخول بشكل مجهول: لا يستدعي /v1/auth/worker/login إطلاقاً، ولا
  /// يُخزَّن أي جلسة — نبض العافية سيُرسَل لاحقاً بدون X-Worker-Token،
  /// أي أن الخادم سيقبل workerIdHash المحلي كما هو (سلوك أقل دقة، لكن
  /// مقصود لمن يريد الخصوصية الكاملة حتى عن هوية الجلسة).
  Future<void> _continueAnonymously() async {
    await _workerAuth.clearToken();
    _goHome();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: BuddyColors.paper,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 40),
              Align(
                alignment: Alignment.center,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                  decoration: BoxDecoration(
                    color: BuddyColors.sage.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: BuddyColors.sage.withOpacity(0.35)),
                  ),
                  child: const Text(
                    'يعمل دون اتصال بالكامل',
                    style: TextStyle(
                      color: BuddyColors.sage,
                      fontWeight: FontWeight.w800,
                      fontSize: 12,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 36),
              const Center(
                child: Text(
                  'BUDDY SYSTEM',
                  style: TextStyle(
                    color: BuddyColors.navy,
                    fontWeight: FontWeight.w800,
                    fontSize: 24,
                    letterSpacing: 1,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'رفيقك في نظام 28/28. بدون الحاجة لأي إشارة.',
                textAlign: TextAlign.center,
                style: TextStyle(color: BuddyColors.inkSoft, fontSize: 13),
              ),
              const SizedBox(height: 32),
              const Text('الرقم الوظيفي',
                  textAlign: TextAlign.right,
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
              const SizedBox(height: 6),
              TextField(
                controller: _employeeIdController,
                textAlign: TextAlign.right,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(11),
                    borderSide: const BorderSide(color: Color(0xFFE1DACB)),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const Text('الرمز السري',
                  textAlign: TextAlign.right,
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
              const SizedBox(height: 6),
              TextField(
                controller: _pinController,
                obscureText: true,
                textAlign: TextAlign.center,
                keyboardType: TextInputType.number,
                style: const TextStyle(letterSpacing: 6, fontWeight: FontWeight.w700),
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(11),
                    borderSide: const BorderSide(color: Color(0xFFE1DACB)),
                  ),
                ),
              ),
              if (_errorText != null) ...[
                const SizedBox(height: 10),
                Text(
                  _errorText!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: BuddyColors.terracotta, fontSize: 12, fontWeight: FontWeight.w700),
                ),
              ],
              const SizedBox(height: 22),
              ElevatedButton(
                onPressed: _loading ? null : _login,
                style: ElevatedButton.styleFrom(
                  backgroundColor: BuddyColors.terracotta,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(11),
                  ),
                ),
                child: _loading
                    ? const SizedBox(
                        height: 18, width: 18,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                      )
                    : const Text('متابعة', style: TextStyle(fontWeight: FontWeight.w800)),
              ),
              TextButton(
                onPressed: _loading ? null : _continueAnonymously,
                child: const Text('الدخول بشكل مجهول',
                    style: TextStyle(color: BuddyColors.sage, fontWeight: FontWeight.w700)),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}
