/// lib/screens/anonymous_report_screen.dart
/// "الإبلاغ المجهول" — يكمل الحلقة الكاملة: واجهة ← تخزين محلي مشفّر ←
/// مزامنة ← POST /v1/reports/anonymous (مُختبر في buddy_backend).
library anonymous_report_screen;

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';

import '../models/anonymous_report.dart';
import '../services/providers.dart';
import 'entry_screen.dart' show BuddyColors;

class AnonymousReportScreen extends ConsumerStatefulWidget {
  const AnonymousReportScreen({super.key});

  @override
  ConsumerState<AnonymousReportScreen> createState() => _AnonymousReportScreenState();
}

class _AnonymousReportScreenState extends ConsumerState<AnonymousReportScreen> {
  ReportCategory? _selectedCategory;
  final _messageController = TextEditingController();
  bool _submitted = false;

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_selectedCategory == null || _messageController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('يرجى اختيار نوع البلاغ وكتابة رسالة')),
      );
      return;
    }

    final storage = ref.read(localStorageProvider);
    final report = AnonymousReport(
      id: const Uuid().v4(),
      createdAt: DateTime.now(),
      category: _selectedCategory!.apiValue,
      message: _messageController.text.trim(),
      siteCode: 'CPH-12', // TODO: à tirer du profil du site configuré
    );

    // كتابة محلية فورية — لا انتظار للشبكة (Offline-First). لا يوجد أي
    // حقل هوية في هذا الكائن أصلاً (انظر AnonymousReport) — هذا ضمان
    // بنيوي على مستوى الكود، لا مجرد سياسة.
    await storage.saveAnonymousReport(report);

    setState(() => _submitted = true);

    // 🔧 نفس سلوك checkin_screen.dart: محاولة مزامنة فورية إن كان
    // الاتصال متوفراً (fire-and-forget) — قبل هذا الإصلاح كان البلاغ
    // المجهول يبقى محلياً بانتظار أول تغيّر في حالة الاتصال فقط
    // (listenForConnectivity في main.dart)، بدل محاولة إرسال فورية
    // مثل الـcheck-in تماماً. لا يحجب واجهة المستخدم ولا يُفشل الحفظ
    // المحلي إن تعذّر الاتصال.
    final sync = ref.read(syncServiceProvider);
    unawaited(sync.syncPendingCheckins());
  }

  Widget _categoryChip(ReportCategory cat) {
    final selected = _selectedCategory == cat;
    return GestureDetector(
      onTap: () => setState(() => _selectedCategory = cat),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: selected ? BuddyColors.sage.withOpacity(0.14) : Colors.white,
          border: Border.all(
            color: selected ? BuddyColors.sage : const Color(0xFFE1DACB),
            width: selected ? 1.6 : 1,
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            if (selected)
              const Icon(Icons.check_circle, color: BuddyColors.sage, size: 18)
            else
              const SizedBox(width: 18),
            Text(
              cat.labelAr,
              style: TextStyle(
                fontWeight: FontWeight.w700,
                color: selected ? BuddyColors.sage : BuddyColors.ink,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: BuddyColors.paper,
      appBar: AppBar(
        backgroundColor: BuddyColors.paper,
        elevation: 0,
        title: const Text('الإبلاغ المجهول',
            style: TextStyle(color: BuddyColors.navy, fontWeight: FontWeight.w800)),
        iconTheme: const IconThemeData(color: BuddyColors.navy),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: _submitted ? _buildConfirmation() : _buildForm(),
      ),
    );
  }

  Widget _buildForm() {
    return ListView(
      children: [
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: BuddyColors.sage.withOpacity(0.08),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: BuddyColors.sage.withOpacity(0.25)),
          ),
          child: const Text(
            'هذا البلاغ مجهول بالكامل. لا يُطلب منك أي معلومة تعرّف بهويتك، ولا تُخزَّن أي بيانات كهذه في أي مكان.',
            textAlign: TextAlign.right,
            style: TextStyle(fontSize: 12, color: BuddyColors.inkSoft, fontWeight: FontWeight.w600),
          ),
        ),
        const SizedBox(height: 20),
        const Text('نوع البلاغ',
            textAlign: TextAlign.right,
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: BuddyColors.navy)),
        const SizedBox(height: 10),
        ...ReportCategory.values.map(_categoryChip),
        const SizedBox(height: 10),
        const Text('التفاصيل',
            textAlign: TextAlign.right,
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: BuddyColors.navy)),
        const SizedBox(height: 8),
        TextField(
          controller: _messageController,
          maxLines: 6,
          textAlign: TextAlign.right,
          decoration: InputDecoration(
            hintText: 'اكتب ما حدث بأسلوبك الخاص...',
            filled: true,
            fillColor: Colors.white,
            contentPadding: const EdgeInsets.all(14),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFFE1DACB)),
            ),
          ),
        ),
        const SizedBox(height: 22),
        ElevatedButton(
          onPressed: _submit,
          style: ElevatedButton.styleFrom(
            backgroundColor: BuddyColors.terracotta,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 15),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
          ),
          child: const Text('إرسال البلاغ', style: TextStyle(fontWeight: FontWeight.w800)),
        ),
      ],
    );
  }

  Widget _buildConfirmation() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(Icons.check_circle, color: BuddyColors.sage, size: 56),
        const SizedBox(height: 16),
        const Text('تم استلام بلاغك',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: BuddyColors.navy)),
        const SizedBox(height: 8),
        const Text(
          'سيُراجَع من قِبل الجهة المختصة. لن يُربَط هذا البلاغ بهويتك في أي وقت.',
          textAlign: TextAlign.center,
          style: TextStyle(color: BuddyColors.inkSoft, fontSize: 13),
        ),
        const SizedBox(height: 24),
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('عودة للرئيسية',
              style: TextStyle(color: BuddyColors.sage, fontWeight: FontWeight.w700)),
        ),
      ],
    );
  }
}
