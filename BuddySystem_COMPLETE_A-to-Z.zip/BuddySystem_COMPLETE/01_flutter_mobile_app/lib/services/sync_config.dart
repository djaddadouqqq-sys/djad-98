/// lib/services/sync_config.dart
/// Configuration réseau partagée — isolée dans son propre fichier pour
/// que sync_service.dart et worker_auth_service.dart puissent tous deux
/// s'y référer sans dépendance circulaire entre eux.
library sync_config;

class SyncConfig {
  /// En développement local : 'http://10.0.2.2:8000' (émulateur Android)
  /// ou 'http://localhost:8000' (iOS simulator / web).
  /// En Pilot déployé : l'URL réelle du serveur (ex: derrière Nginx+TLS).
  static const String apiBaseUrl = 'http://10.0.2.2:8000';

  /// Doit correspondre à une clé API créée via /v1/admin/tenants côté
  /// serveur (voir buddy_backend/app/auth.py et README backend). À
  /// déplacer vers une configuration sécurisée avant la mise en
  /// production réelle — la valeur en dur ici est acceptable uniquement
  /// pour le Pilot.
  static const String apiKey = 'pilot-demo-key-2026';
}
