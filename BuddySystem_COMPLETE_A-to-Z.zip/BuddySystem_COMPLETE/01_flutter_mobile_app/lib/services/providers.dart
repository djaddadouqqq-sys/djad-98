/// lib/services/providers.dart
/// Câblage Riverpod — un seul point central pour accéder aux services.
library providers;

import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'local_storage_service.dart';
import 'sync_service.dart';
import 'worker_auth_service.dart';

final localStorageProvider = Provider<LocalStorageService>((ref) {
  throw UnimplementedError(
      'localStorageProvider doit être surchargé (override) dans main.dart '
      'après l\'initialisation asynchrone de Hive.');
});

/// Point d'accès unique à l'identité de session (jeton + workerIdHash
/// effectif) — partagé par entry_screen, checkin_screen, home_screen et
/// sync_service pour ne jamais dupliquer la logique d'identité.
final workerAuthServiceProvider = Provider<WorkerAuthService>((ref) {
  return WorkerAuthService();
});

final syncServiceProvider = Provider<SyncService>((ref) {
  final storage = ref.watch(localStorageProvider);
  return SyncService(storage);
});
