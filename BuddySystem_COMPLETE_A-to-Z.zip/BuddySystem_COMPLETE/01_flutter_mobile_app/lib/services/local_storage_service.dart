/// lib/services/local_storage_service.dart
///
/// Implémente le pattern "Repository" décrit dans le cahier des charges :
/// la base de données locale (Hive) est LA source de vérité. Le serveur
/// central n'est qu'une réplique synchronisée quand le réseau est
/// disponible — jamais une dépendance bloquante.
///
/// Chiffrement : la boîte Hive est chiffrée en AES-256. La clé elle-même
/// n'est JAMAIS stockée en clair dans le code ni dans les préférences
/// partagées : elle est générée une seule fois puis conservée dans le
/// Keystore (Android) / Keychain (iOS) via flutter_secure_storage, qui
/// s'appuie sur le stockage sécurisé natif de l'OS.
library local_storage_service;

import 'dart:convert';
import 'dart:math';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../models/daily_checkin.dart';
import '../models/anonymous_report.dart';

class LocalStorageService {
  static const _secureStorage = FlutterSecureStorage();
  static const _encryptionKeyName = 'buddy_hive_encryption_key_v1';
  static const _checkinBoxName = 'daily_checkins';
  static const _reportBoxName = 'anonymous_reports';

  late Box<DailyCheckin> _checkinBox;
  late Box<AnonymousReport> _reportBox;

  /// Doit être appelé une seule fois au démarrage de l'app, avant
  /// runApp(). Initialise Hive, récupère (ou génère) la clé de
  /// chiffrement AES-256, puis ouvre les boîtes chiffrées.
  Future<void> init() async {
    await Hive.initFlutter();
    Hive.registerAdapter(DailyCheckinAdapter());
    Hive.registerAdapter(AnonymousReportAdapter());

    final encryptionKey = await _getOrCreateEncryptionKey();

    _checkinBox = await Hive.openBox<DailyCheckin>(
      _checkinBoxName,
      encryptionCipher: HiveAesCipher(encryptionKey),
    );
    _reportBox = await Hive.openBox<AnonymousReport>(
      _reportBoxName,
      encryptionCipher: HiveAesCipher(encryptionKey),
    );
  }

  Future<List<int>> _getOrCreateEncryptionKey() async {
    final existing = await _secureStorage.read(key: _encryptionKeyName);
    if (existing != null) {
      return base64Url.decode(existing);
    }
    // Génère 256 bits (32 octets) cryptographiquement aléatoires.
    final random = Random.secure();
    final keyBytes = List<int>.generate(32, (_) => random.nextInt(256));
    await _secureStorage.write(
      key: _encryptionKeyName,
      value: base64UrlEncode(keyBytes),
    );
    return keyBytes;
  }

  /// Écrit immédiatement en local. Ne dépend d'aucune connexion.
  /// L'appelant doit mettre à jour l'UI de façon optimiste juste après
  /// cet appel (voir screens/checkin_screen.dart).
  Future<void> saveCheckin(DailyCheckin checkin) async {
    await _checkinBox.put(checkin.id, checkin);
  }

  List<DailyCheckin> getAllCheckins() {
    return _checkinBox.values.toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  DailyCheckin? getLatestCheckin() {
    final all = getAllCheckins();
    return all.isEmpty ? null : all.first;
  }

  int daysSinceLastCheckin() {
    final latest = getLatestCheckin();
    if (latest == null) return 999; // jamais rempli -> risque maximal
    return DateTime.now().difference(latest.createdAt).inDays;
  }

  /// Renvoie tous les check-ins pas encore synchronisés — utilisé par
  /// le service de synchronisation en arrière-plan.
  List<DailyCheckin> getPendingSyncItems() {
    return _checkinBox.values.where((c) => !c.syncedToServer).toList();
  }

  Future<void> markSynced(String checkinId) async {
    final item = _checkinBox.get(checkinId);
    if (item != null) {
      item.syncedToServer = true;
      await item.save();
    }
  }

  // ---------------- Signalement anonyme ----------------

  /// Écrit immédiatement en local, comme pour le check-in. Aucune
  /// donnée d'identité n'est jamais passée ici — voir AnonymousReport.
  Future<void> saveAnonymousReport(AnonymousReport report) async {
    await _reportBox.put(report.id, report);
  }

  List<AnonymousReport> getAllAnonymousReports() {
    return _reportBox.values.toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  List<AnonymousReport> getPendingSyncReports() {
    return _reportBox.values.where((r) => !r.syncedToServer).toList();
  }

  Future<void> markReportSynced(String reportId) async {
    final item = _reportBox.get(reportId);
    if (item != null) {
      item.syncedToServer = true;
      await item.save();
    }
  }
}
