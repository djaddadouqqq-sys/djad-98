/// lib/services/bprs_engine.dart
///
/// Moteur de calcul du BPRS — Buddy Psychosocial Risk Score.
///
/// Ceci est le cœur scientifique de Buddy System : un score composite
/// (0 à 100) calculé localement, sur l'appareil, sans connexion internet,
/// à partir de six variables documentées dans le mémoire de master associé
/// au projet :
///   1. Empowerment (autonomisation professionnelle — modèle Spreitzer 1995)
///   2. Résilience psychologique
///   3. Isolement géographique
///   4. Position dans le cycle de rotation 28/28
///   5. Éloignement familial
///   6. Soutien social perçu (Hobfoll, 1998)
///
/// Le score est ensuite classé en quatre niveaux d'alerte (PEWS —
/// Psychosocial Early Warning System), chacun associé à une action précise :
///   Vert      0–29   -> Simple suivi, aucune action requise
///   Jaune    30–54   -> Suivi renforcé + signalement au Buddy Officer
///   Orange   55–74   -> Intervention du Buddy Officer sous 24h
///   Rouge    75–100  -> Intervention psychologique immédiate
///
/// IMPORTANT (garde-fou éthique et légal — voir mémoire, Partie III,
/// chapitre "Cadre éthique et légal") :
/// Ce moteur NE POSE AUCUN DIAGNOSTIC CLINIQUE. Il s'agit d'un outil de
/// détection précoce et de priorisation, pas d'un instrument médical.
/// Toute valeur en zone rouge doit être orientée vers un professionnel
/// de santé mentale habilité — jamais traitée algorithmiquement seule.
library bprs_engine;

/// Les six entrées brutes nécessaires au calcul, chacune normalisée
/// par l'appelant sur une échelle de 0.0 (aucun risque) à 10.0 (risque maximal)
/// AVANT weighting — sauf indication contraire ci-dessous.
class BprsInputs {
  /// Fatigue physique ressentie (0 = reposé, 10 = épuisé) — issue du
  /// "pouls de bien-être" quotidien.
  final double physicalFatigue;

  /// Fatigue mentale / cognitive (0 = clair d'esprit, 10 = saturé).
  final double mentalFatigue;

  /// Qualité du sommeil INVERSÉE pour le calcul : 0 = sommeil excellent,
  /// 10 = sommeil très perturbé. (Convertir avant l'appel :
  /// riskValue = 10 - qualitéSommeilSur10)
  final double sleepDisruption;

  /// Empowerment professionnel (modèle Spreitzer) — ICI le sens est
  /// INVERSÉ par rapport aux autres : 0 = empowerment élevé (protecteur),
  /// 10 = empowerment très faible (facteur de risque). Le repository
  /// applique la conversion (10 - scoreEmpowermentSur10) avant l'appel.
  final double lowEmpowerment;

  /// Résilience psychologique perçue — INVERSÉE également :
  /// 0 = résilience élevée (protectrice), 10 = résilience très faible.
  final double lowResilience;

  /// Isolement géographique et social perçu (0 = bien connecté,
  /// 10 = isolement total).
  final double isolation;

  const BprsInputs({
    required this.physicalFatigue,
    required this.mentalFatigue,
    required this.sleepDisruption,
    required this.lowEmpowerment,
    required this.lowResilience,
    required this.isolation,
  });
}

/// Contexte objectif de la rotation — ne dépend d'aucune réponse
/// déclarative du travailleur. C'est ce qui permet au système de rester
/// vivant même si l'employé ne remplit rien (exigence explicite du porteur
/// de projet : "le système doit fonctionner même si l'ouvrier ne remplit
/// aucun formulaire").
class RotationContext {
  /// Jour courant dans le cycle 28/28 (1 à 28).
  final int dayInRotationCycle;

  /// Nombre de jours écoulés depuis le dernier check-in rempli par
  /// l'utilisateur. 0 = check-in fait aujourd'hui.
  final int daysSinceLastCheckin;

  /// Heures de travail effectuées sur les dernières 24h (API RP 755
  /// recommande une vigilance accrue au-delà de 12h).
  final double hoursWorkedLast24h;

  /// true si le poste actuel est un quart de nuit.
  final bool isNightShift;

  /// Distance en kilomètres entre le site et le lieu de résidence
  /// familiale (variable "éloignement familial" documentée, seuil
  /// observé à 700km dans l'étude de terrain).
  final double distanceFromFamilyKm;

  const RotationContext({
    required this.dayInRotationCycle,
    required this.daysSinceLastCheckin,
    required this.hoursWorkedLast24h,
    required this.isNightShift,
    required this.distanceFromFamilyKm,
  });
}

enum RiskLevel { green, yellow, orange, red }

class BprsResult {
  /// Score final, borné entre 0 et 100.
  final double score;
  final RiskLevel level;
  /// Explique pourquoi le score a été relevé automatiquement, même sans
  /// saisie de l'utilisateur (transparence — exigence de traçabilité
  /// ISO 45003, article 9.1).
  final List<String> passiveRiskFactors;

  const BprsResult({
    required this.score,
    required this.level,
    required this.passiveRiskFactors,
  });

  String get levelLabelAr {
    switch (level) {
      case RiskLevel.green:
        return 'أخضر — استفسار';
      case RiskLevel.yellow:
        return 'أصفر — متابعة وتبليغ';
      case RiskLevel.orange:
        return 'برتقالي — تدخل';
      case RiskLevel.red:
        return 'أحمر — تدخل نفسي فوري';
    }
  }
}

class BprsEngine {
  // Pondérations calibrées à partir de l'analyse de fiabilité du
  // mémoire (Cronbach's α = 0.798, N=90). À RECALIBRER après la
  // phase Pilot avec un échantillon élargi — voir README §"Limites".
  static const double _wPhysicalFatigue = 0.18;
  static const double _wMentalFatigue = 0.18;
  static const double _wSleep = 0.16;
  static const double _wEmpowerment = 0.16;
  static const double _wResilience = 0.16;
  static const double _wIsolation = 0.16;

  /// Calcule le score déclaratif brut (0–100) à partir des six variables.
  static double _declarativeScore(BprsInputs i) {
    final weighted = (i.physicalFatigue * _wPhysicalFatigue) +
        (i.mentalFatigue * _wMentalFatigue) +
        (i.sleepDisruption * _wSleep) +
        (i.lowEmpowerment * _wEmpowerment) +
        (i.lowResilience * _wResilience) +
        (i.isolation * _wIsolation);
    // weighted est sur une échelle 0-10 -> on ramène sur 0-100
    return weighted * 10;
  }

  /// Applique les majorations passives basées sur le contexte objectif
  /// de la rotation — indépendamment de toute déclaration de l'employé.
  /// C'est l'exigence centrale du porteur de projet : Buddy System reste
  /// un système de vigilance même en l'absence totale de saisie.
  static (double, List<String>) _applyPassiveRiskFactors(
    double baseScore,
    RotationContext ctx,
  ) {
    double score = baseScore;
    final reasons = <String>[];

    if (ctx.daysSinceLastCheckin >= 7) {
      score += 15;
      reasons.add(
          'لم يسجّل العامل أي بيانات منذ ${ctx.daysSinceLastCheckin} أيام — ارتفاع تلقائي للحذر');
    } else if (ctx.daysSinceLastCheckin >= 3) {
      score += 7;
      reasons.add('غياب متابعة لمدة ${ctx.daysSinceLastCheckin} أيام');
    }

    if (ctx.dayInRotationCycle >= 21) {
      score += 10;
      reasons.add(
          'اليوم ${ctx.dayInRotationCycle} من دورة 28/28 — تجاوز عتبة التراكم النفسي الموثقة ميدانياً');
    }

    if (ctx.hoursWorkedLast24h > 12) {
      score += 8;
      reasons.add(
          '${ctx.hoursWorkedLast24h.toStringAsFixed(1)} ساعة عمل خلال 24 ساعة — يتجاوز عتبة API RP 755 للإرهاق');
    }

    if (ctx.isNightShift) {
      score += 5;
      reasons.add('مناوبة ليلية — عامل خطر إضافي موثّق');
    }

    if (ctx.distanceFromFamilyKm >= 700) {
      score += 5;
      reasons.add(
          'بُعد جغرافي عن الأسرة يفوق 700 كم — عتبة العزلة الموثّقة في الدراسة الميدانية');
    }

    return (score.clamp(0, 100).toDouble(), reasons);
  }

  static RiskLevel _classify(double score) {
    if (score < 30) return RiskLevel.green;
    if (score < 55) return RiskLevel.yellow;
    if (score < 75) return RiskLevel.orange;
    return RiskLevel.red;
  }

  /// Point d'entrée principal. Toujours exécuté localement — aucune
  /// dépendance réseau, aucun appel API. C'est ce qui garantit le
  /// fonctionnement "Offline-First" même dans l'isolement total.
  static BprsResult compute({
    BprsInputs? declarativeInputs,
    required RotationContext rotationContext,
  }) {
    // Si l'employé n'a rien rempli, on ne calcule PAS de score déclaratif
    // fictif : on part de 0 et on laisse les facteurs passifs (contexte
    // objectif de rotation) porter entièrement le score. C'est
    // délibéré : le système ne doit jamais halluciner un état
    // psychologique que l'utilisateur n'a pas déclaré.
    final base = declarativeInputs != null
        ? _declarativeScore(declarativeInputs)
        : 0.0;

    final (finalScore, reasons) =
        _applyPassiveRiskFactors(base, rotationContext);

    return BprsResult(
      score: finalScore,
      level: _classify(finalScore),
      passiveRiskFactors: reasons,
    );
  }
}
