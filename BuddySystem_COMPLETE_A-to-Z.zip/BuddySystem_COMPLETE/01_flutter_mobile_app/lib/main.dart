/// lib/main.dart
library main;

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'screens/entry_screen.dart';
import 'services/local_storage_service.dart';
import 'services/providers.dart';
import 'services/sync_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialisation Offline-First : la base locale chiffrée doit être prête
  // AVANT le premier rendu — l'app ne doit jamais afficher un écran vide
  // en attendant un serveur.
  final storage = LocalStorageService();
  await storage.init();

  final syncService = SyncService(storage);
  syncService.listenForConnectivity();

  // 🔧 CORRECTIF Offline → Sync : listenForConnectivity() ne déclenche une
  // synchronisation QUE lors d'un CHANGEMENT de connectivité. Sans cet
  // appel, un employé qui remplit son check-in hors-ligne, ferme
  // complètement l'app, puis la rouvre alors que le réseau est déjà
  // disponible (Wi-Fi de la base de vie déjà connecté) voyait ses
  // données rester bloquées en attente jusqu'au prochain check-in ou
  // jusqu'à une coupure/reprise réseau — un vrai trou dans le scénario
  // "Offline → Sync". On tente donc aussi une synchronisation au
  // démarrage, en arrière-plan (fire-and-forget) : échoue silencieusement
  // si hors-ligne, exactement comme le reste de SyncService.
  unawaited(syncService.syncPendingCheckins());

  runApp(
    ProviderScope(
      overrides: [
        localStorageProvider.overrideWithValue(storage),
      ],
      child: const BuddySystemApp(),
    ),
  );
}

class BuddySystemApp extends StatelessWidget {
  const BuddySystemApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Buddy System',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      theme: ThemeData(
        fontFamily: 'Cairo', // à ajouter aux assets — voir README
        scaffoldBackgroundColor: BuddyColors.paper,
        useMaterial3: true,
      ),
      home: const EntryScreen(),
    );
  }
}
