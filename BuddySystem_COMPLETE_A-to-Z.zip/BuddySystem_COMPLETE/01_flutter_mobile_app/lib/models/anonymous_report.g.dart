// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'anonymous_report.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class AnonymousReportAdapter extends TypeAdapter<AnonymousReport> {
  @override
  final int typeId = 2;

  @override
  AnonymousReport read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return AnonymousReport(
      id: fields[0] as String,
      createdAt: fields[1] as DateTime,
      category: fields[2] as String,
      siteCode: fields[3] as String?,
      message: fields[4] as String,
      syncedToServer: fields[5] == null ? false : fields[5] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, AnonymousReport obj) {
    writer
      ..writeByte(6)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.createdAt)
      ..writeByte(2)
      ..write(obj.category)
      ..writeByte(3)
      ..write(obj.siteCode)
      ..writeByte(4)
      ..write(obj.message)
      ..writeByte(5)
      ..write(obj.syncedToServer);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AnonymousReportAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
