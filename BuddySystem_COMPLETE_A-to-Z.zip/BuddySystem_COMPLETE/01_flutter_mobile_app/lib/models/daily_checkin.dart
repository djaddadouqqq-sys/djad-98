/// lib/models/daily_checkin.dart
///
/// Modèle de données pour le "Pouls de Bien-être Quotidien".
/// Stocké intégralement en local (Hive), jamais envoyé en clair au serveur.
///
/// ⚠️ MISE À JOUR : ce modèle envoie désormais aussi ses 6 sous-scores
/// bruts + le contexte de rotation complet vers POST /v1/checkins/full
/// (voir toFullCheckinPayload() plus bas), et non plus uniquement le
/// score composite comme le faisait toAnonymizedPayload() vers l'ancien
/// /v1/checkins/anonymous (conservée pour compatibilité, toujours
/// fonctionnelle côté serveur). C'est un changement de posture de
/// confidentialité assumé et documenté, pas un oubli : le commentaire
/// original de ce fichier précisait que les sous-scores n'étaient PAS
/// transmis individuellement pour limiter la ré-identification indirecte.
/// Le compromis retenu ici (identique à celui fait dans
/// 03_pwa_app/js/sync.js et 04_website/worker_unified.html) : le serveur
/// devient la SEULE source de vérité pour le calcul BPRS + les 8 risques
/// + le moteur de fatigue (cohérence garantie entre toutes les
/// interfaces), au prix de sous-scores bruts désormais visibles côté
/// serveur, toujours liés uniquement au workerIdHash haché (jamais au
/// matricule en clair). ⚠️ Cette bascule de confidentialité doit être
/// validée par un responsable conformité avant tout déploiement réel
/// avec des employés — voir COMPLIANCE_MAPPING.md.
library daily_checkin;

import 'package:hive/hive.dart';

part 'daily_checkin.g.dart'; // généré par build_runner (hive_generator)

@HiveType(typeId: 1)
class DailyCheckin extends HiveObject {
  @HiveField(0)
  final String id; // uuid v4, généré localement

  @HiveField(1)
  final String workerIdHash; // identifiant haché, jamais le matricule en clair

  @HiveField(2)
  final DateTime createdAt;

  @HiveField(3)
  final double physicalFatigue; // 0-10, saisi via slider

  @HiveField(4)
  final double mentalFatigue; // 0-10

  @HiveField(5)
  final double sleepQuality; // 0-10 (10 = excellent sommeil)

  @HiveField(6)
  final double empowermentFeeling; // 0-10 (10 = empowerment élevé)

  @HiveField(7)
  final double resilienceFeeling; // 0-10 (10 = résilience élevée)

  @HiveField(8)
  final double isolationFeeling; // 0-10 (10 = isolement total)

  @HiveField(9)
  final double bprsScoreAtEntry; // score calculé au moment de la saisie (estimation locale)

  @HiveField(10)
  final String riskLevelAtEntry; // 'green' | 'yellow' | 'orange' | 'red' (estimation locale)

  @HiveField(11)
  bool syncedToServer; // false tant que non transmis (mode hors-ligne)

  // 🆕 Contexte de rotation — désormais capturé réellement à la saisie
  // (voir screens/checkin_screen.dart), plus des constantes de démo en
  // dur comme avant. Champs 12-17.
  @HiveField(12)
  final int dayInRotationCycle; // 1-28

  @HiveField(13)
  final int daysSinceLastCheckinAtEntry; // capturé au moment précis de la saisie

  @HiveField(14)
  final double hoursWorkedLast24h;

  @HiveField(15)
  final bool isNightShift;

  @HiveField(16)
  final double distanceFromFamilyKm;

  @HiveField(17)
  final double? sleepHoursLast24h; // optionnel — Fatigue Engine, null si non renseigné

  // 🆕 Résultat officiel du serveur une fois synchronisé (JSON brut tel
  // que retourné par POST /v1/checkins/full) — null tant que non
  // synchronisé. Permet à l'UI d'afficher "estimation locale" avant
  // synchronisation puis "officiel (serveur)" après, comme dans le PWA.
  @HiveField(18)
  String? serverResultJson;

  DailyCheckin({
    required this.id,
    required this.workerIdHash,
    required this.createdAt,
    required this.physicalFatigue,
    required this.mentalFatigue,
    required this.sleepQuality,
    required this.empowermentFeeling,
    required this.resilienceFeeling,
    required this.isolationFeeling,
    required this.bprsScoreAtEntry,
    required this.riskLevelAtEntry,
    this.syncedToServer = false,
    required this.dayInRotationCycle,
    required this.daysSinceLastCheckinAtEntry,
    required this.hoursWorkedLast24h,
    required this.isNightShift,
    required this.distanceFromFamilyKm,
    this.sleepHoursLast24h,
    this.serverResultJson,
  });

  /// Représentation anonymisée historique destinée à l'ancien endpoint
  /// POST /v1/checkins/anonymous — conservée telle quelle, toujours
  /// fonctionnelle côté serveur, mais plus utilisée par défaut par
  /// SyncService (voir toFullCheckinPayload() ci-dessous).
  Map<String, dynamic> toAnonymizedPayload() {
    return {
      'workerIdHash': workerIdHash,
      'createdAt': createdAt.toIso8601String(),
      'bprsScore': bprsScoreAtEntry,
      'riskLevel': riskLevelAtEntry,
    };
  }

  /// 🆕 Payload complet pour POST /v1/checkins/full — le serveur
  /// recalcule BPRS + les 8 risques + le moteur de fatigue à partir des
  /// valeurs brutes ci-dessous (source de vérité unique, cohérente avec
  /// le site web et le PWA).
  Map<String, dynamic> toFullCheckinPayload() {
    final payload = {
      'workerIdHash': workerIdHash,
      'createdAt': createdAt.toIso8601String(),
      'physicalFatigue': physicalFatigue,
      'mentalFatigue': mentalFatigue,
      'sleepDisruption': 10 - sleepQuality,
      'lowEmpowerment': 10 - empowermentFeeling,
      'lowResilience': 10 - resilienceFeeling,
      'isolation': isolationFeeling,
      'dayInRotationCycle': dayInRotationCycle,
      'daysSinceLastCheckin': daysSinceLastCheckinAtEntry,
      'hoursWorkedLast24h': hoursWorkedLast24h,
      'isNightShift': isNightShift,
      'distanceFromFamilyKm': distanceFromFamilyKm,
    };
    if (sleepHoursLast24h != null) {
      payload['sleepHoursLast24h'] = sleepHoursLast24h as double;
    }
    return payload;
  }
}
