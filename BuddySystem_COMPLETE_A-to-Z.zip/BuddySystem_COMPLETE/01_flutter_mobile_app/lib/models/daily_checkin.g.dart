// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'daily_checkin.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class DailyCheckinAdapter extends TypeAdapter<DailyCheckin> {
  @override
  final int typeId = 1;

  @override
  DailyCheckin read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return DailyCheckin(
      id: fields[0] as String,
      workerIdHash: fields[1] as String,
      createdAt: fields[2] as DateTime,
      physicalFatigue: fields[3] as double,
      mentalFatigue: fields[4] as double,
      sleepQuality: fields[5] as double,
      empowermentFeeling: fields[6] as double,
      resilienceFeeling: fields[7] as double,
      isolationFeeling: fields[8] as double,
      bprsScoreAtEntry: fields[9] as double,
      riskLevelAtEntry: fields[10] as String,
      syncedToServer: fields[11] == null ? false : fields[11] as bool,
      dayInRotationCycle: fields[12] as int,
      daysSinceLastCheckinAtEntry: fields[13] as int,
      hoursWorkedLast24h: fields[14] as double,
      isNightShift: fields[15] as bool,
      distanceFromFamilyKm: fields[16] as double,
      sleepHoursLast24h: fields[17] as double?,
      serverResultJson: fields[18] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, DailyCheckin obj) {
    writer
      ..writeByte(19)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.workerIdHash)
      ..writeByte(2)
      ..write(obj.createdAt)
      ..writeByte(3)
      ..write(obj.physicalFatigue)
      ..writeByte(4)
      ..write(obj.mentalFatigue)
      ..writeByte(5)
      ..write(obj.sleepQuality)
      ..writeByte(6)
      ..write(obj.empowermentFeeling)
      ..writeByte(7)
      ..write(obj.resilienceFeeling)
      ..writeByte(8)
      ..write(obj.isolationFeeling)
      ..writeByte(9)
      ..write(obj.bprsScoreAtEntry)
      ..writeByte(10)
      ..write(obj.riskLevelAtEntry)
      ..writeByte(11)
      ..write(obj.syncedToServer)
      ..writeByte(12)
      ..write(obj.dayInRotationCycle)
      ..writeByte(13)
      ..write(obj.daysSinceLastCheckinAtEntry)
      ..writeByte(14)
      ..write(obj.hoursWorkedLast24h)
      ..writeByte(15)
      ..write(obj.isNightShift)
      ..writeByte(16)
      ..write(obj.distanceFromFamilyKm)
      ..writeByte(17)
      ..write(obj.sleepHoursLast24h)
      ..writeByte(18)
      ..write(obj.serverResultJson);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DailyCheckinAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
