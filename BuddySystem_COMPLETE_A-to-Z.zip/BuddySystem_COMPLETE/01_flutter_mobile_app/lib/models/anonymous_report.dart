/// lib/models/anonymous_report.dart
///
/// Modèle du signalement anonyme (mobbing, harcèlement, épuisement...).
/// AUCUN champ d'identité de l'auteur n'existe dans ce modèle — c'est
/// une garantie structurelle, pas une simple politique : même une future
/// erreur de code ne pourra pas faire fuiter une identité qui n'a jamais
/// été stockée. Conforme au schéma testé du backend
/// (buddy_backend/app/db.py — table anonymous_reports).
library anonymous_report;

import 'package:hive/hive.dart';

part 'anonymous_report.g.dart'; // généré par build_runner (hive_generator)

enum ReportCategory { mobbing, harassment, burnout, other }

extension ReportCategoryX on ReportCategory {
  String get apiValue {
    switch (this) {
      case ReportCategory.mobbing:
        return 'mobbing';
      case ReportCategory.harassment:
        return 'harassment';
      case ReportCategory.burnout:
        return 'burnout';
      case ReportCategory.other:
        return 'other';
    }
  }

  String get labelAr {
    switch (this) {
      case ReportCategory.mobbing:
        return 'تنكيد مهني';
      case ReportCategory.harassment:
        return 'مضايقة أو تحرش';
      case ReportCategory.burnout:
        return 'احتراق وظيفي';
      case ReportCategory.other:
        return 'أخرى';
    }
  }
}

@HiveType(typeId: 2)
class AnonymousReport extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final DateTime createdAt;

  @HiveField(2)
  final String category; // valeur de ReportCategory.apiValue

  @HiveField(3)
  final String? siteCode;

  @HiveField(4)
  final String message;

  @HiveField(5)
  bool syncedToServer;

  AnonymousReport({
    required this.id,
    required this.createdAt,
    required this.category,
    required this.message,
    this.siteCode,
    this.syncedToServer = false,
  });

  /// Correspond EXACTEMENT au schéma attendu par
  /// POST /v1/reports/anonymous (voir buddy_backend/app/server.py).
  Map<String, dynamic> toApiPayload() {
    return {
      'category': category,
      'message': message,
      if (siteCode != null) 'siteCode': siteCode,
    };
  }
}
