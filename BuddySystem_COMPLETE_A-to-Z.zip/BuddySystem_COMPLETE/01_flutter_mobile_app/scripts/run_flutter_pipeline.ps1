# =============================================================================
# run_flutter_pipeline.ps1 — يُشغَّل على جهازك أنت (Windows)، لا في أي بيئة
# سحابية بلا Flutter SDK. هذا السكربت لم يُنفَّذ من طرف Claude — لا يوجد
# Flutter SDK ولا اتصال شبكة صادر في بيئة العمل التي بُني فيها هذا المشروع
# (موثَّق صراحة في MASTER_README.md §4.6). أنت أول من يُشغّله فعلياً.
#
# الاستخدام (PowerShell كمسؤول أو عادي، لا فرق هنا):
#   cd 01_flutter_mobile_app
#   .\scripts\run_flutter_pipeline.ps1
#
# لبناء APK فقط دون تشغيل مباشر:
#   .\scripts\run_flutter_pipeline.ps1 -BuildOnly
# =============================================================================

param([switch]$BuildOnly = $false)

$ErrorActionPreference = "Stop"
$LogDir = ".\pipeline_logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Ts = Get-Date -Format "yyyyMMdd_HHmmss"

function Step($msg) { Write-Host "`n▶ $msg" -ForegroundColor Cyan }
function Ok($msg)   { Write-Host "✓ $msg" -ForegroundColor Green }
function Warn($msg) { Write-Host "⚠ $msg" -ForegroundColor Yellow }
function Fail($msg) { Write-Host "✗ $msg" -ForegroundColor Red; exit 1 }

# --- 0) التأكد أننا داخل مجلد Flutter الصحيح ---
if (-not (Test-Path "pubspec.yaml") -or -not (Select-String -Path "pubspec.yaml" -Pattern "^name: buddy_system" -Quiet)) {
    Fail "شغّل هذا السكربت من داخل مجلد 01_flutter_mobile_app نفسه (حيث يوجد pubspec.yaml)."
}

# --- 1) التحقق من Flutter SDK ---
Step "1/6 — التحقق من Flutter SDK"
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
    Fail "لم يُعثر على 'flutter' في PATH. ثبّته أولاً: https://docs.flutter.dev/get-started/install"
}
flutter --version | Tee-Object -FilePath "$LogDir\00_flutter_version_$Ts.log"
Ok "Flutter SDK موجود"

Step "1b/6 — flutter doctor (تشخيص شامل للبيئة، Android toolchain خصوصاً)"
flutter doctor -v | Tee-Object -FilePath "$LogDir\00_flutter_doctor_$Ts.log"
Warn "راجع الأسطر أعلاه يدوياً — أي علامة [X] بجانب Android toolchain تعني أن التشغيل على جهاز Android لن ينجح حتى تُصلَح"

# --- 2) pub get ---
Step "2/6 — flutter pub get (تنزيل الاعتماديات + توليد daily_checkin.g.dart عبر hive_generator)"
flutter pub get 2>&1 | Tee-Object -FilePath "$LogDir\01_pub_get_$Ts.log"
if (Test-Path "lib\models\daily_checkin.g.dart") {
    Ok "تم توليد lib\models\daily_checkin.g.dart بنجاح (الملف المُولَّد الذي لم يكن موجوداً في الحزمة المُسلَّمة)"
} else {
    Warn "daily_checkin.g.dart لم يظهر بعد pub get — قد تحتاج: flutter pub run build_runner build --delete-conflicting-outputs"
}

# --- 3) flutter analyze ---
Step "3/6 — flutter analyze (يكشف أي خطأ نحوي/نوعي فاتته المراجعة اليدوية في هذه الجلسة)"
flutter analyze 2>&1 | Tee-Object -FilePath "$LogDir\02_analyze_$Ts.log"
if ($LASTEXITCODE -ne 0) {
    Fail "flutter analyze وجد أخطاء — راجع $LogDir\02_analyze_$Ts.log قبل المتابعة. لا تتجاهل هذه الخطوة."
}
Ok "لا أخطاء نحوية/نوعية"

# --- 4) flutter test ---
Step "4/6 — flutter test (تشغيل فعلي لـ test/bprs_engine_test.dart)"
flutter test 2>&1 | Tee-Object -FilePath "$LogDir\03_test_$Ts.log"
if ($LASTEXITCODE -ne 0) {
    Fail "flutter test فشل — راجع $LogDir\03_test_$Ts.log. لا تُكمل للتشغيل الفعلي قبل إصلاح هذا."
}
Ok "كل اختبارات Dart نجحت فعلياً (أول تنفيذ حقيقي لها منذ كتابتها)"

# --- 5) اختيار الجهاز ---
Step "5/6 — الأجهزة/المحاكيات المتصلة"
flutter devices | Tee-Object -FilePath "$LogDir\04_devices_$Ts.log"
$DeviceId = Read-Host "أدخل معرّف الجهاز (device id) من القائمة أعلاه"
if ([string]::IsNullOrWhiteSpace($DeviceId)) { Fail "لم تُدخل معرّف جهاز." }

Warn "قبل المتابعة — تحقّق من lib\services\sync_config.dart:"
Warn "  - محاكي Android:  apiBaseUrl = 'http://10.0.2.2:8000'  (القيمة الافتراضية الحالية، صحيحة كما هي)"
Warn "  - جهاز Android حقيقي على نفس شبكة Wi-Fi: استبدلها بعنوان IP الفعلي لجهازك، مثال 'http://192.168.1.50:8000'"
Warn "  - تأكد أن 02_backend_api\app\server.py يعمل فعلاً قبل المتابعة (نافذة PowerShell أخرى)"
Read-Host "اضغط Enter للمتابعة بعد التأكد من الخادم وعنوان الشبكة"

# --- 6) build أو run ---
if ($BuildOnly) {
    Step "6/6 — flutter build apk --debug"
    flutter build apk --debug 2>&1 | Tee-Object -FilePath "$LogDir\05_build_$Ts.log"
    Ok "APK جاهز: build\app\outputs\flutter-apk\app-debug.apk — ثبّته عبر: adb install -r build\app\outputs\flutter-apk\app-debug.apk"
} else {
    Step "6/6 — flutter run -d $DeviceId (تشغيل حقيقي — راقب الطرفية لأي أخطاء وقت التشغيل)"
    flutter run -d $DeviceId 2>&1 | Tee-Object -FilePath "$LogDir\05_run_$Ts.log"
}

Write-Host ""
Ok "انتهى السكربت الآلي. الخطوة التالية يدوية بالكامل: نفّذ سيناريو الاختبار الكامل"
Ok "الموصوف في FULL_SYSTEM_INTEGRATION_TEST_GUIDE.md (Login -> Check-in -> BPRS -> المخاطر -> Fatigue -> Buddy -> Offline -> Sync)"
Write-Host "كل السجلات محفوظة في: $LogDir\" -ForegroundColor Cyan
