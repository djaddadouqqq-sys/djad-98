import 'package:flutter_test/flutter_test.dart';
import 'package:buddy_system/services/bprs_engine.dart';

void main() {
  group('BprsEngine.compute', () {
    test('un profil sain avec check-in récent reste en zone verte', () {
      final result = BprsEngine.compute(
        declarativeInputs: const BprsInputs(
          physicalFatigue: 1,
          mentalFatigue: 1,
          sleepDisruption: 1,
          lowEmpowerment: 1,
          lowResilience: 1,
          isolation: 1,
        ),
        rotationContext: const RotationContext(
          dayInRotationCycle: 3,
          daysSinceLastCheckin: 0,
          hoursWorkedLast24h: 8,
          isNightShift: false,
          distanceFromFamilyKm: 200,
        ),
      );

      expect(result.level, RiskLevel.green);
      expect(result.passiveRiskFactors, isEmpty);
    });

    test('absence de saisie depuis 7 jours ou plus déclenche une alerte '
        'même sans aucune donnée déclarative', () {
      final result = BprsEngine.compute(
        declarativeInputs: null,
        rotationContext: const RotationContext(
          dayInRotationCycle: 5,
          daysSinceLastCheckin: 9,
          hoursWorkedLast24h: 8,
          isNightShift: false,
          distanceFromFamilyKm: 100,
        ),
      );

      expect(result.score, greaterThan(0));
      expect(result.passiveRiskFactors, isNotEmpty);
    });

    test('cumul de facteurs de risque (fin de rotation + nuit + heures '
        'élevées + éloignement) doit atteindre au moins le niveau orange', () {
      final result = BprsEngine.compute(
        declarativeInputs: const BprsInputs(
          physicalFatigue: 6,
          mentalFatigue: 6,
          sleepDisruption: 6,
          lowEmpowerment: 5,
          lowResilience: 5,
          isolation: 6,
        ),
        rotationContext: const RotationContext(
          dayInRotationCycle: 25,
          daysSinceLastCheckin: 1,
          hoursWorkedLast24h: 13,
          isNightShift: true,
          distanceFromFamilyKm: 900,
        ),
      );

      expect(
        result.level == RiskLevel.orange || result.level == RiskLevel.red,
        isTrue,
        reason: 'Score obtenu: ${result.score}',
      );
    });

    test('le score final ne dépasse jamais 100 même avec un cumul extrême '
        'de tous les facteurs de risque', () {
      final result = BprsEngine.compute(
        declarativeInputs: const BprsInputs(
          physicalFatigue: 10,
          mentalFatigue: 10,
          sleepDisruption: 10,
          lowEmpowerment: 10,
          lowResilience: 10,
          isolation: 10,
        ),
        rotationContext: const RotationContext(
          dayInRotationCycle: 28,
          daysSinceLastCheckin: 20,
          hoursWorkedLast24h: 16,
          isNightShift: true,
          distanceFromFamilyKm: 1500,
        ),
      );

      expect(result.score, lessThanOrEqualTo(100));
      expect(result.level, RiskLevel.red);
    });
  });
}
