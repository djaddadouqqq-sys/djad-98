package com.buddysystem.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
