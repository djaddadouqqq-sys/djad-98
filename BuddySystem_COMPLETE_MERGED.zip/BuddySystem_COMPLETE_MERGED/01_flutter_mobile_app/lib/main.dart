/// lib/main.dart
library main;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'screens/entry_screen.dart';
import 'services/local_storage_service.dart';
import 'services/providers.dart';
import 'services/sync_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialisation Offline-First : la base locale chiffrée doit être prête
  // AVANT le premier rendu — l'app ne doit jamais afficher un écran vide
  // en attendant un serveur.
  final storage = LocalStorageService();
  await storage.init();

  final syncService = SyncService(storage);
  syncService.listenForConnectivity();

  runApp(
    ProviderScope(
      overrides: [
        localStorageProvider.overrideWithValue(storage),
      ],
      child: const BuddySystemApp(),
    ),
  );
}

class BuddySystemApp extends StatelessWidget {
  const BuddySystemApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Buddy System',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      theme: ThemeData(
        fontFamily: 'Cairo', // à ajouter aux assets — voir README
        scaffoldBackgroundColor: BuddyColors.paper,
        useMaterial3: true,
      ),
      home: const EntryScreen(),
    );
  }
}
