/// lib/models/daily_checkin.dart
///
/// Modèle de données pour le "Pouls de Bien-être Quotidien".
/// Stocké intégralement en local (Hive), jamais envoyé en clair au serveur.
/// Seuls les agrégats anonymisés remontent vers le tableau de bord HSE
/// (voir services/sync_service.dart).
library daily_checkin;

import 'package:hive/hive.dart';

part 'daily_checkin.g.dart'; // généré par build_runner (hive_generator)

@HiveType(typeId: 1)
class DailyCheckin extends HiveObject {
  @HiveField(0)
  final String id; // uuid v4, généré localement

  @HiveField(1)
  final String workerIdHash; // identifiant haché, jamais le matricule en clair

  @HiveField(2)
  final DateTime createdAt;

  @HiveField(3)
  final double physicalFatigue; // 0-10, saisi via slider

  @HiveField(4)
  final double mentalFatigue; // 0-10

  @HiveField(5)
  final double sleepQuality; // 0-10 (10 = excellent sommeil)

  @HiveField(6)
  final double empowermentFeeling; // 0-10 (10 = empowerment élevé)

  @HiveField(7)
  final double resilienceFeeling; // 0-10 (10 = résilience élevée)

  @HiveField(8)
  final double isolationFeeling; // 0-10 (10 = isolement total)

  @HiveField(9)
  final double bprsScoreAtEntry; // score calculé au moment de la saisie

  @HiveField(10)
  final String riskLevelAtEntry; // 'green' | 'yellow' | 'orange' | 'red'

  @HiveField(11)
  bool syncedToServer; // false tant que non transmis (mode hors-ligne)

  DailyCheckin({
    required this.id,
    required this.workerIdHash,
    required this.createdAt,
    required this.physicalFatigue,
    required this.mentalFatigue,
    required this.sleepQuality,
    required this.empowermentFeeling,
    required this.resilienceFeeling,
    required this.isolationFeeling,
    required this.bprsScoreAtEntry,
    required this.riskLevelAtEntry,
    this.syncedToServer = false,
  });

  /// Représentation anonymisée destinée à la synchronisation vers le
  /// tableau de bord HSE : AUCUN champ nominatif, uniquement l'identifiant
  /// haché et les valeurs agrégables. Conforme ISO 45003 art. 7.4
  /// (canaux de communication sûrs) et à la Loi algérienne 18-07.
  Map<String, dynamic> toAnonymizedPayload() {
    return {
      'workerIdHash': workerIdHash,
      'createdAt': createdAt.toIso8601String(),
      'bprsScore': bprsScoreAtEntry,
      'riskLevel': riskLevelAtEntry,
      // Note : les 6 sous-scores bruts ne sont PAS transmis individuellement
      // au HSE — seul le score composite et le niveau de couleur le sont,
      // pour empêcher toute ré-identification indirecte de l'employé.
    };
  }
}
