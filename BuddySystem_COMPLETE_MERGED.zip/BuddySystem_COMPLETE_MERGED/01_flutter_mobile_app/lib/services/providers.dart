/// lib/services/providers.dart
/// Câblage Riverpod — un seul point central pour accéder aux services.
library providers;

import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'local_storage_service.dart';
import 'sync_service.dart';

final localStorageProvider = Provider<LocalStorageService>((ref) {
  throw UnimplementedError(
      'localStorageProvider doit être surchargé (override) dans main.dart '
      'après l\'initialisation asynchrone de Hive.');
});

final syncServiceProvider = Provider<SyncService>((ref) {
  final storage = ref.watch(localStorageProvider);
  return SyncService(storage);
});
