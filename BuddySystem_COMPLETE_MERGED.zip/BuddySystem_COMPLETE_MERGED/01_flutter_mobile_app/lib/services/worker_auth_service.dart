/// lib/services/worker_auth_service.dart
///
/// Authentification individuelle de l'employé — appelle réellement
/// POST /v1/auth/worker/login (endpoint testé dans buddy_backend,
/// voir test_worker_provision_login_and_authenticated_checkin_flow).
///
/// Le jeton reçu est stocké dans flutter_secure_storage (Keystore/
/// Keychain natif) — jamais dans Hive ni en mémoire simple — car c'est
/// un secret de session, pas une donnée métier.
library worker_auth_service;

import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

import 'sync_config.dart';

class WorkerLoginResult {
  final bool success;
  final String? errorMessage;
  WorkerLoginResult.ok() : success = true, errorMessage = null;
  WorkerLoginResult.fail(this.errorMessage) : success = false;
}

class WorkerAuthService {
  static const _secureStorage = FlutterSecureStorage();
  static const _tokenKey = 'buddy_worker_token_v1';

  /// Appelle le backend réel. En cas d'échec réseau (site isolé, hors
  /// ligne), renvoie un échec explicite — l'appelant (entry_screen)
  /// doit alors proposer "الدخول بشكل مجهول" comme repli, jamais
  /// bloquer l'utilisateur.
  Future<WorkerLoginResult> login({
    required String employeeId,
    required String pin,
  }) async {
    try {
      final response = await http
          .post(
            Uri.parse('${SyncConfig.apiBaseUrl}/v1/auth/worker/login'),
            headers: {
              'Content-Type': 'application/json',
              'X-API-Key': SyncConfig.apiKey,
            },
            body: jsonEncode({'employeeId': employeeId, 'pin': pin}),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final body = jsonDecode(response.body) as Map<String, dynamic>;
        await _secureStorage.write(key: _tokenKey, value: body['token'] as String);
        return WorkerLoginResult.ok();
      }
      if (response.statusCode == 401) {
        return WorkerLoginResult.fail('الرقم الوظيفي أو الرمز السري غير صحيح.');
      }
      return WorkerLoginResult.fail('تعذّر تسجيل الدخول (رمز: ${response.statusCode}).');
    } catch (_) {
      return WorkerLoginResult.fail(
          'لا يوجد اتصال بالخادم الآن. يمكنك المتابعة والمزامنة لاحقاً، أو الدخول بشكل مجهول.');
    }
  }

  Future<String?> getStoredToken() => _secureStorage.read(key: _tokenKey);

  Future<void> clearToken() => _secureStorage.delete(key: _tokenKey);
}
