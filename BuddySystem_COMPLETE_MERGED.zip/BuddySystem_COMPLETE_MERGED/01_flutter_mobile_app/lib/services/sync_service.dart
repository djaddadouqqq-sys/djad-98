/// lib/services/sync_service.dart
///
/// Couche de synchronisation. Détecte le retour de connectivité (Wi-Fi de
/// la base de vie) et transmet UNIQUEMENT les données anonymisées
/// (voir DailyCheckin.toAnonymizedPayload()) vers le serveur central.
///
/// ✅ MISE À JOUR : ce fichier appelle désormais le vrai backend fourni
/// dans `buddy_backend/` (endpoints testés — 9/9 tests passants, voir
/// buddy_backend/README.md). Le champ `apiBaseUrl` et `apiKey` doivent
/// être configurés selon l'environnement (dev local vs. serveur Pilot
/// déployé) — voir la section "Configuration" ci-dessous.
library sync_service;

import 'dart:convert';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:http/http.dart' as http;

import 'local_storage_service.dart';
import 'worker_auth_service.dart';
import 'sync_config.dart';

class SyncService {
  final LocalStorageService storage;
  final WorkerAuthService workerAuth = WorkerAuthService();
  SyncService(this.storage);

  /// À appeler au démarrage de l'app et à chaque changement de
  /// connectivité détecté (voir main.dart).
  void listenForConnectivity() {
    Connectivity().onConnectivityChanged.listen((results) async {
      final hasConnection =
          results.any((r) => r != ConnectivityResult.none);
      if (hasConnection) {
        await syncPendingCheckins();
      }
    });
  }

  Future<void> syncPendingCheckins() async {
    final pending = storage.getPendingSyncItems();
    for (final checkin in pending) {
      final success = await _pushCheckinToServer(checkin.toAnonymizedPayload());
      if (success) {
        await storage.markSynced(checkin.id);
      }
    }

    final pendingReports = storage.getPendingSyncReports();
    for (final report in pendingReports) {
      final success = await _pushReportToServer(report.toApiPayload());
      if (success) {
        await storage.markReportSynced(report.id);
      }
    }
  }

  /// Appel HTTP réel vers POST /v1/checkins/anonymous — endpoint testé
  /// dans buddy_backend/tests/test_api.py (test_checkin_valid_submission).
  /// Si un jeton d'employé authentifié existe (voir WorkerAuthService),
  /// il est joint via X-Worker-Token — le serveur l'utilise alors comme
  /// source de vérité pour l'identité, au lieu du workerIdHash local
  /// (voir buddy_backend/app/server.py, test
  /// test_worker_provision_login_and_authenticated_checkin_flow).
  Future<bool> _pushCheckinToServer(Map<String, dynamic> payload) async {
    try {
      final token = await workerAuth.getStoredToken();
      final headers = {
        'Content-Type': 'application/json',
        'X-API-Key': SyncConfig.apiKey,
        if (token != null) 'X-Worker-Token': token,
      };

      final response = await http
          .post(
            Uri.parse('${SyncConfig.apiBaseUrl}/v1/checkins/anonymous'),
            headers: headers,
            body: jsonEncode(payload),
          )
          .timeout(const Duration(seconds: 10));

      return response.statusCode == 201;
    } catch (_) {
      return false;
    }
  }

  /// Appel HTTP réel vers POST /v1/reports/anonymous — endpoint testé
  /// dans buddy_backend/tests/test_api.py (test_anonymous_report_submission).
  Future<bool> _pushReportToServer(Map<String, dynamic> payload) async {
    try {
      final response = await http
          .post(
            Uri.parse('${SyncConfig.apiBaseUrl}/v1/reports/anonymous'),
            headers: {
              'Content-Type': 'application/json',
              'X-API-Key': SyncConfig.apiKey,
            },
            body: jsonEncode(payload),
          )
          .timeout(const Duration(seconds: 10));

      return response.statusCode == 201;
    } catch (_) {
      // Pas de connexion, serveur injoignable, timeout, etc. — normal et
      // attendu dans un environnement pétrolier isolé. On réessaiera plus
      // tard, aucune donnée n'est perdue (elle reste dans Hive en local).
      return false;
    }
  }
}

