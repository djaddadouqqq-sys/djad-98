/// lib/screens/home_screen.dart
/// الشاشة الرئيسية — MVP scope 3/3.
library home_screen;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../services/bprs_engine.dart';
import '../services/providers.dart';
import 'anonymous_report_screen.dart';
import 'checkin_screen.dart';
import 'entry_screen.dart' show BuddyColors;

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  Color _colorForLevel(String levelName) {
    switch (levelName) {
      case 'green':
        return const Color(0xFF63B583);
      case 'yellow':
        return const Color(0xFFD8B34E);
      case 'orange':
        return const Color(0xFFCE7C4C);
      case 'red':
      default:
        return const Color(0xFFB8544A);
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final storage = ref.watch(localStorageProvider);
    final latest = storage.getLatestCheckin();
    final daysSince = storage.daysSinceLastCheckin();

    return Scaffold(
      backgroundColor: BuddyColors.paper,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('مساء الخير',
                  style: TextStyle(color: BuddyColors.inkSoft, fontSize: 12)),
              const Text('كريم',
                  style: TextStyle(
                      color: BuddyColors.navy, fontWeight: FontWeight.w800, fontSize: 20)),
              const SizedBox(height: 28),
              if (latest == null)
                Card(
                  color: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  child: const Padding(
                    padding: EdgeInsets.all(20),
                    child: Text(
                      'لا يوجد بعد أي تسجيل يومي.\nالنظام يعتمد حالياً على مؤشرات الدورة (28/28) فقط.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: BuddyColors.inkSoft),
                    ),
                  ),
                )
              else
                Center(
                  child: Column(
                    children: [
                      CircleAvatar(
                        radius: 56,
                        backgroundColor:
                            _colorForLevel(latest.riskLevelAtEntry).withOpacity(0.15),
                        child: Text(
                          latest.bprsScoreAtEntry.toStringAsFixed(0),
                          style: TextStyle(
                            fontSize: 34,
                            fontWeight: FontWeight.w800,
                            color: _colorForLevel(latest.riskLevelAtEntry),
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text('آخر تسجيل: قبل $daysSince يوم',
                          style: const TextStyle(color: BuddyColors.inkSoft, fontSize: 12)),
                    ],
                  ),
                ),
              const Spacer(),
              OutlinedButton(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const AnonymousReportScreen()),
                ),
                style: OutlinedButton.styleFrom(
                  foregroundColor: BuddyColors.navy,
                  side: const BorderSide(color: Color(0xFFE1DACB)),
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
                ),
                child: const Text('الإبلاغ المجهول', style: TextStyle(fontWeight: FontWeight.w800)),
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const CheckinScreen()),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: BuddyColors.sage,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
                ),
                child: const Text('نبض العافية اليومي',
                    style: TextStyle(fontWeight: FontWeight.w800)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
