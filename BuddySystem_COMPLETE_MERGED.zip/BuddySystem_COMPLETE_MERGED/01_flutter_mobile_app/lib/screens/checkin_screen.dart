/// lib/screens/checkin_screen.dart
/// "نبض العافية اليومي" — MVP scope 2/3.
/// Écran le plus important du projet : 4 sliders, moins de 30 secondes,
/// calcul BPRS immédiat et local, écriture Hive optimiste.
library checkin_screen;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';

import '../models/daily_checkin.dart';
import '../services/bprs_engine.dart';
import '../services/providers.dart';
import 'entry_screen.dart' show BuddyColors;

class CheckinScreen extends ConsumerStatefulWidget {
  const CheckinScreen({super.key});

  @override
  ConsumerState<CheckinScreen> createState() => _CheckinScreenState();
}

class _CheckinScreenState extends ConsumerState<CheckinScreen> {
  double _physicalFatigue = 3;
  double _mentalFatigue = 3;
  double _sleepQuality = 6;
  double _empowerment = 6;
  double _resilience = 6;
  double _isolation = 3;

  bool _saved = false;
  BprsResult? _result;

  Future<void> _submit() async {
    final storage = ref.read(localStorageProvider);

    final inputs = BprsInputs(
      physicalFatigue: _physicalFatigue,
      mentalFatigue: _mentalFatigue,
      sleepDisruption: 10 - _sleepQuality,
      lowEmpowerment: 10 - _empowerment,
      lowResilience: 10 - _resilience,
      isolation: _isolation,
    );

    // Contexte de rotation — dans le MVP réel, dayInRotationCycle et
    // hoursWorkedLast24h proviendraient du profil employé configuré à
    // l'installation. Valeurs d'exemple ici pour la démonstration.
    final rotationContext = RotationContext(
      dayInRotationCycle: 14,
      daysSinceLastCheckin: storage.daysSinceLastCheckin(),
      hoursWorkedLast24h: 10,
      isNightShift: false,
      distanceFromFamilyKm: 750,
    );

    final result = BprsEngine.compute(
      declarativeInputs: inputs,
      rotationContext: rotationContext,
    );

    final checkin = DailyCheckin(
      id: const Uuid().v4(),
      workerIdHash: 'local-fallback-hash', // Écrasé côté serveur par le
      // X-Worker-Token si l'employé est connecté (voir sync_service.dart
      // et WorkerAuthService) — cette valeur locale ne sert que si
      // l'utilisateur a choisi "الدخول بشكل مجهول".
      createdAt: DateTime.now(),
      physicalFatigue: _physicalFatigue,
      mentalFatigue: _mentalFatigue,
      sleepQuality: _sleepQuality,
      empowermentFeeling: _empowerment,
      resilienceFeeling: _resilience,
      isolationFeeling: _isolation,
      bprsScoreAtEntry: result.score,
      riskLevelAtEntry: result.level.name,
    );

    // Écriture locale immédiate — aucune attente réseau (Offline-First).
    await storage.saveCheckin(checkin);

    setState(() {
      _saved = true;
      _result = result;
    });
  }

  Widget _slider(String label, double value, ValueChanged<double> onChanged,
      {String lowHint = '', String highHint = ''}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(value.toStringAsFixed(0),
                  style: const TextStyle(fontWeight: FontWeight.w800, color: BuddyColors.navy)),
              Text(label,
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
            ],
          ),
          Slider(
            value: value,
            min: 0,
            max: 10,
            divisions: 10,
            activeColor: BuddyColors.sage,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: BuddyColors.paper,
      appBar: AppBar(
        backgroundColor: BuddyColors.paper,
        elevation: 0,
        title: const Text('نبض العافية اليومي',
            style: TextStyle(color: BuddyColors.navy, fontWeight: FontWeight.w800)),
        iconTheme: const IconThemeData(color: BuddyColors.navy),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: _saved && _result != null
            ? _buildResult(_result!)
            : ListView(
                children: [
                  _slider('الإرهاق الجسدي', _physicalFatigue,
                      (v) => setState(() => _physicalFatigue = v)),
                  _slider('الإرهاق الذهني', _mentalFatigue,
                      (v) => setState(() => _mentalFatigue = v)),
                  _slider('جودة النوم', _sleepQuality,
                      (v) => setState(() => _sleepQuality = v)),
                  _slider('الشعور بالتمكين', _empowerment,
                      (v) => setState(() => _empowerment = v)),
                  _slider('الشعور بالصمود', _resilience,
                      (v) => setState(() => _resilience = v)),
                  _slider('الشعور بالعزلة', _isolation,
                      (v) => setState(() => _isolation = v)),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: BuddyColors.terracotta,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 15),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(11),
                      ),
                    ),
                    child: const Text('إرسال', style: TextStyle(fontWeight: FontWeight.w800)),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _buildResult(BprsResult result) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(result.score.toStringAsFixed(0),
            style: const TextStyle(
                fontSize: 48, fontWeight: FontWeight.w800, color: BuddyColors.navy)),
        const SizedBox(height: 6),
        Text(result.levelLabelAr,
            style: const TextStyle(fontWeight: FontWeight.w800, color: BuddyColors.terracotta)),
        const SizedBox(height: 20),
        if (result.passiveRiskFactors.isNotEmpty) ...[
          const Text('عوامل رفعت المؤشر تلقائياً:',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
          const SizedBox(height: 8),
          ...result.passiveRiskFactors.map(
            (r) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Text('• $r',
                  textAlign: TextAlign.right,
                  style: const TextStyle(fontSize: 11.5, color: BuddyColors.inkSoft)),
            ),
          ),
        ],
        const SizedBox(height: 24),
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('عودة للرئيسية',
              style: TextStyle(color: BuddyColors.sage, fontWeight: FontWeight.w700)),
        ),
      ],
    );
  }
}
