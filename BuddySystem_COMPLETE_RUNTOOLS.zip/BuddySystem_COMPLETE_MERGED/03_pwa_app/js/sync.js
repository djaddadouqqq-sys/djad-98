/**
 * js/sync.js
 *
 * يزامن فعلياً مع الخادم الحقيقي المُختبر (buddy_backend). عند فشل
 * الاتصال (لا خادم، لا إنترنت)، يفشل بصمت ويُبقي العنصر غير مُزامَن
 * محلياً — نفس سلوك sync_service.dart في نسخة Flutter تماماً.
 *
 * ⚠️ تحديث: يستخدم الآن /v1/checkins/full (لا /v1/checkins/anonymous) —
 * يُرسِل المتغيرات الستة الخام + سياق الدورة الكامل، ويترك الخادم هو
 * مصدر الحقيقة الوحيد لحساب BPRS والمخاطر الثمانية ومحرك الإرهاق،
 * بنفس القرار المعماري المتّبع في 04_website/worker_unified.html —
 * لا حساب مزدوج قد ينحرف صامتاً بين نسخة محلية وأخرى في الخادم.
 * المسار القديم /v1/checkins/anonymous لم يُحذف من الخادم (لا يزال
 * يعمل ومُختبراً)، لكن هذا العميل لم يعد يستخدمه.
 */

const BuddySync = {
  config: { apiUrl: '', apiKey: '', workerToken: null },

  configure({ apiUrl, apiKey, workerToken }) {
    this.config.apiUrl = apiUrl.replace(new RegExp('/+$'), '');
    this.config.apiKey = apiKey;
    this.config.workerToken = workerToken || null;
  },

  async syncAll() {
    const result = { checkinsPushed: 0, reportsPushed: 0, failed: 0, checkinResults: [] };
    if (!this.config.apiUrl || !this.config.apiKey) return result;

    const pendingCheckins = await BuddyDB.getPendingCheckins();
    for (const c of pendingCheckins) {
      const serverResult = await this._pushCheckin(c);
      if (serverResult) {
        await BuddyDB.markCheckinSynced(c.id, serverResult);
        result.checkinsPushed++;
        result.checkinResults.push(serverResult);
      } else {
        result.failed++;
      }
    }

    const pendingReports = await BuddyDB.getPendingReports();
    for (const r of pendingReports) {
      const ok = await this._pushReport(r);
      if (ok) { await BuddyDB.markReportSynced(r.id); result.reportsPushed++; }
      else result.failed++;
    }

    return result;
  },

  async _pushCheckin(c) {
    try {
      const headers = { 'Content-Type': 'application/json', 'X-API-Key': this.config.apiKey };
      if (this.config.workerToken) headers['X-Worker-Token'] = this.config.workerToken;

      const payload = {
        workerIdHash: c.workerIdHash,
        createdAt: c.createdAt,
        siteCode: c.siteCode,
        physicalFatigue: c.inputs.physicalFatigue,
        mentalFatigue: c.inputs.mentalFatigue,
        sleepDisruption: c.inputs.sleep,
        lowEmpowerment: c.inputs.empowerment,
        lowResilience: c.inputs.resilience,
        isolation: c.inputs.isolation,
        dayInRotationCycle: c.context.dayInCycle,
        daysSinceLastCheckin: c.context.daysSinceCheckin,
        hoursWorkedLast24h: c.context.hoursWorked,
        isNightShift: c.context.nightShift,
        distanceFromFamilyKm: c.context.distanceKm,
      };
      if (c.context.sleepHoursLast24h !== null && c.context.sleepHoursLast24h !== undefined) {
        payload.sleepHoursLast24h = c.context.sleepHoursLast24h;
      }

      const res = await fetch(this.config.apiUrl + '/v1/checkins/full', {
        method: 'POST', headers, body: JSON.stringify(payload),
      });
      if (res.status !== 201) return null;
      return await res.json();
    } catch (e) {
      return null;
    }
  },

  async _pushReport(r) {
    try {
      const res = await fetch(this.config.apiUrl + '/v1/reports/anonymous', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-API-Key': this.config.apiKey },
        // ملاحظة أمانة متعمَّدة: X-Worker-Token لا يُرفَق هنا إطلاقاً،
        // تماماً كما في sync_service.dart — البلاغ المجهول يبقى مجهولاً
        // حتى لو كان العامل مسجّلاً دخوله.
        body: JSON.stringify({ category: r.category, message: r.message, siteCode: r.siteCode }),
      });
      return res.status === 201;
    } catch (e) {
      return false;
    }
  },

  async login(apiUrl, apiKey, employeeId, pin) {
    try {
      const res = await fetch(apiUrl.replace(new RegExp('/+$'), '') + '/v1/auth/worker/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-API-Key': apiKey },
        body: JSON.stringify({ employeeId, pin }),
      });
      const body = await res.json();
      if (res.status === 200) return { success: true, token: body.token, workerIdHash: body.workerIdHash };
      return { success: false, error: body.error || res.status, detail: body.detail };
    } catch (e) {
      return { success: false, error: 'network_error' };
    }
  },

  // 🆕 نظام Buddy — العامل يرى Buddy Officer الخاص به + تاريخه عبر
  // GET /v1/workers/timeline (نفس نقطة worker_unified.html بالضبط).
  // ملاحظة أمانة: نقاط /v1/buddy/officers|assign|intervention|workers
  // هي نقاط إدارية لـHSE/Buddy Officer أنفسهم (تُدار من buddy_dashboard.html)،
  // لا معنى لاستدعائها من تطبيق عامل ميداني لا يدير تعيينات أو تدخلات —
  // العامل "يستهلك" حالة تعيينه فقط، لا "يُدير" النظام.
  async fetchMyTimeline(workerIdHash) {
    if (!this.config.apiUrl || !this.config.apiKey || !workerIdHash) return null;
    try {
      const headers = { 'X-API-Key': this.config.apiKey };
      if (this.config.workerToken) headers['X-Worker-Token'] = this.config.workerToken;
      const res = await fetch(
        `${this.config.apiUrl}/v1/workers/timeline?workerIdHash=${encodeURIComponent(workerIdHash)}`,
        { headers }
      );
      if (!res.ok) return null;
      return await res.json();
    } catch (e) {
      return null;
    }
  },
};
