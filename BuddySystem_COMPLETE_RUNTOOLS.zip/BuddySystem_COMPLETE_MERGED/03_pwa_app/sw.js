/**
 * sw.js — Service Worker حقيقي.
 * يخزّن هيكل التطبيق (app-shell) محلياً عند أول زيارة، ثم يخدمه من
 * الذاكرة المؤقتة (Cache) في أي زيارة لاحقة حتى بدون إنترنت إطلاقاً —
 * هذا ما يجعل فتح التطبيق نفسه ممكناً دون اتصال، لا فقط تخزين البيانات.
 */

const CACHE_NAME = 'buddy-system-shell-v2';
const APP_SHELL = [
  './app.html',
  './manifest.json',
  './js/db.js',
  './js/bprs.js',
  './js/sync.js',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // لا نتدخل أبداً في طلبات الـAPI الحقيقية (يجب أن تصل للخادم أو تفشل
  // بوضوح، لا أن تُخدَم من ذاكرة مؤقتة قديمة).
  if (url.pathname.startsWith('/v1/') || url.pathname === '/health') {
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request))
  );
});
