/// lib/screens/checkin_screen.dart
/// "نبض العافية اليومي" — MVP scope 2/3.
/// Écran le plus important du projet : 4 sliders, moins de 30 secondes,
/// calcul BPRS immédiat et local, écriture Hive optimiste.
library checkin_screen;

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';

import '../models/daily_checkin.dart';
import '../services/bprs_engine.dart';
import '../services/providers.dart';
import 'entry_screen.dart' show BuddyColors;

class CheckinScreen extends ConsumerStatefulWidget {
  const CheckinScreen({super.key});

  @override
  ConsumerState<CheckinScreen> createState() => _CheckinScreenState();
}

class _CheckinScreenState extends ConsumerState<CheckinScreen> {
  double _physicalFatigue = 3;
  double _mentalFatigue = 3;
  double _sleepQuality = 6;
  double _empowerment = 6;
  double _resilience = 6;
  double _isolation = 3;

  // 🆕 Contexte de rotation — désormais saisi réellement par l'utilisateur
  // (auparavant des constantes en dur non éditables). Valeurs par défaut
  // raisonnables conservées pour ne pas allonger le MVP inutilement.
  double _dayInCycle = 14;
  double _hoursWorked = 10;
  bool _nightShift = false;
  double _distanceKm = 750;
  double? _sleepHours; // optionnel — Fatigue Engine

  bool _saved = false;
  BprsResult? _result;

  Future<void> _submit() async {
    final storage = ref.read(localStorageProvider);

    final inputs = BprsInputs(
      physicalFatigue: _physicalFatigue,
      mentalFatigue: _mentalFatigue,
      sleepDisruption: 10 - _sleepQuality,
      lowEmpowerment: 10 - _empowerment,
      lowResilience: 10 - _resilience,
      isolation: _isolation,
    );

    final daysSinceAtEntry = storage.daysSinceLastCheckin();

    final rotationContext = RotationContext(
      dayInRotationCycle: _dayInCycle.round(),
      daysSinceLastCheckin: daysSinceAtEntry,
      hoursWorkedLast24h: _hoursWorked,
      isNightShift: _nightShift,
      distanceFromFamilyKm: _distanceKm,
    );

    // تقدير محلي فوري (Offline-First) — نفس محرك bprs_engine.dart،
    // معروض قبل أي مزامنة. الدرجة الرسمية الوحيدة تصل لاحقاً من
    // /v1/checkins/full عبر SyncService (انظر sync_service.dart).
    final result = BprsEngine.compute(
      declarativeInputs: inputs,
      rotationContext: rotationContext,
    );

    final checkin = DailyCheckin(
      id: const Uuid().v4(),
      workerIdHash: 'local-fallback-hash', // Écrasé côté serveur par le
      // X-Worker-Token si l'employé est connecté (voir sync_service.dart
      // et WorkerAuthService) — cette valeur locale ne sert que si
      // l'utilisateur a choisi "الدخول بشكل مجهول".
      createdAt: DateTime.now(),
      physicalFatigue: _physicalFatigue,
      mentalFatigue: _mentalFatigue,
      sleepQuality: _sleepQuality,
      empowermentFeeling: _empowerment,
      resilienceFeeling: _resilience,
      isolationFeeling: _isolation,
      bprsScoreAtEntry: result.score,
      riskLevelAtEntry: result.level.name,
      dayInRotationCycle: _dayInCycle.round(),
      daysSinceLastCheckinAtEntry: daysSinceAtEntry,
      hoursWorkedLast24h: _hoursWorked,
      isNightShift: _nightShift,
      distanceFromFamilyKm: _distanceKm,
      sleepHoursLast24h: _sleepHours,
    );

    // Écriture locale immédiate — aucune attente réseau (Offline-First).
    await storage.saveCheckin(checkin);

    setState(() {
      _saved = true;
      _result = result;
    });

    // 🆕 محاولة مزامنة فورية إن كان الاتصال متوفراً — نفس سلوك trySync()
    // في PWA. لا يحجب واجهة المستخدم (fire-and-forget)؛ SyncService
    // يتعامل بصمت مع فشل الاتصال (انظر listenForConnectivity()).
    final sync = ref.read(syncServiceProvider);
    unawaited(sync.syncPendingCheckins());
  }

  Widget _slider(String label, double value, ValueChanged<double> onChanged,
      {String lowHint = '', String highHint = '', double min = 0, double max = 10, int? divisions}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(value.toStringAsFixed(max > 20 ? 0 : 1),
                  style: const TextStyle(fontWeight: FontWeight.w800, color: BuddyColors.navy)),
              Text(label,
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
            ],
          ),
          Slider(
            value: value,
            min: min,
            max: max,
            divisions: divisions ?? 10,
            activeColor: BuddyColors.sage,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: BuddyColors.paper,
      appBar: AppBar(
        backgroundColor: BuddyColors.paper,
        elevation: 0,
        title: const Text('نبض العافية اليومي',
            style: TextStyle(color: BuddyColors.navy, fontWeight: FontWeight.w800)),
        iconTheme: const IconThemeData(color: BuddyColors.navy),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: _saved && _result != null
            ? _buildResult(_result!)
            : ListView(
                children: [
                  _slider('الإرهاق الجسدي', _physicalFatigue,
                      (v) => setState(() => _physicalFatigue = v)),
                  _slider('الإرهاق الذهني', _mentalFatigue,
                      (v) => setState(() => _mentalFatigue = v)),
                  _slider('جودة النوم', _sleepQuality,
                      (v) => setState(() => _sleepQuality = v)),
                  _slider('الشعور بالتمكين', _empowerment,
                      (v) => setState(() => _empowerment = v)),
                  _slider('الشعور بالصمود', _resilience,
                      (v) => setState(() => _resilience = v)),
                  _slider('الشعور بالعزلة', _isolation,
                      (v) => setState(() => _isolation = v)),
                  const SizedBox(height: 8),
                  const Text('سياق الدورة (يُرسَل رسمياً للخادم)',
                      style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5, color: BuddyColors.navy)),
                  const SizedBox(height: 6),
                  _slider('يوم الدورة (1-28)', _dayInCycle,
                      (v) => setState(() => _dayInCycle = v),
                      min: 1, max: 28, divisions: 27),
                  _slider('ساعات العمل آخر 24 ساعة', _hoursWorked,
                      (v) => setState(() => _hoursWorked = v),
                      min: 0, max: 24, divisions: 48),
                  _slider('البعد عن الأسرة (كم)', _distanceKm,
                      (v) => setState(() => _distanceKm = v),
                      min: 0, max: 2000, divisions: 40),
                  SwitchListTile(
                    value: _nightShift,
                    onChanged: (v) => setState(() => _nightShift = v),
                    activeColor: BuddyColors.sage,
                    title: const Text('مناوبة ليلية', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700)),
                    contentPadding: EdgeInsets.zero,
                  ),
                  const SizedBox(height: 4),
                  const Text('ساعات النوم الفعلية (اختياري — محرك الإرهاق)',
                      style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                  TextField(
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(hintText: 'اتركه فارغاً إن لم تكن متأكداً'),
                    onChanged: (v) => _sleepHours = double.tryParse(v),
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: BuddyColors.terracotta,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 15),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(11),
                      ),
                    ),
                    child: const Text('إرسال', style: TextStyle(fontWeight: FontWeight.w800)),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _buildResult(BprsResult result) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(result.score.toStringAsFixed(0),
            style: const TextStyle(
                fontSize: 48, fontWeight: FontWeight.w800, color: BuddyColors.navy)),
        const SizedBox(height: 6),
        Text(result.levelLabelAr,
            style: const TextStyle(fontWeight: FontWeight.w800, color: BuddyColors.terracotta)),
        const SizedBox(height: 20),
        if (result.passiveRiskFactors.isNotEmpty) ...[
          const Text('عوامل رفعت المؤشر تلقائياً:',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
          const SizedBox(height: 8),
          ...result.passiveRiskFactors.map(
            (r) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Text('• $r',
                  textAlign: TextAlign.right,
                  style: const TextStyle(fontSize: 11.5, color: BuddyColors.inkSoft)),
            ),
          ),
        ],
        const SizedBox(height: 24),
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('عودة للرئيسية',
              style: TextStyle(color: BuddyColors.sage, fontWeight: FontWeight.w700)),
        ),
      ],
    );
  }
}
