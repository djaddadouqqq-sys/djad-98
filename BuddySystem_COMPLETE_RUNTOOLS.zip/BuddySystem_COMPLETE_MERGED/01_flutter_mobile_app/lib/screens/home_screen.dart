/// lib/screens/home_screen.dart
/// الشاشة الرئيسية — MVP scope 3/3.
library home_screen;

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../services/providers.dart';
import 'anonymous_report_screen.dart';
import 'checkin_screen.dart';
import 'entry_screen.dart' show BuddyColors;

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  Map<String, dynamic>? _timeline;
  bool _loadingBuddy = true;

  @override
  void initState() {
    super.initState();
    _loadBuddyInfo();
  }

  // 🆕 نظام Buddy — يُحمَّل عند فتح الشاشة الرئيسية، عبر
  // GET /v1/workers/timeline (نفس السلوك في PWA وworker_unified.html).
  // يفشل بصمت عند غياب الاتصال، بلا حجب لبقية الواجهة.
  Future<void> _loadBuddyInfo() async {
    final storage = ref.read(localStorageProvider);
    final latest = storage.getLatestCheckin();
    final workerIdHash = latest?.workerIdHash ?? 'local-fallback-hash';
    final sync = ref.read(syncServiceProvider);
    final result = await sync.fetchMyTimeline(workerIdHash);
    if (!mounted) return;
    setState(() {
      _timeline = result;
      _loadingBuddy = false;
    });
  }

  Color _colorForLevel(String levelName) {
    switch (levelName) {
      case 'green':
        return const Color(0xFF63B583);
      case 'yellow':
        return const Color(0xFFD8B34E);
      case 'orange':
        return const Color(0xFFCE7C4C);
      case 'red':
      default:
        return const Color(0xFFB8544A);
    }
  }

  Widget _buildBuddyCard() {
    if (_loadingBuddy) return const SizedBox.shrink();
    final buddyOfficer = _timeline?['buddyOfficer'] as Map<String, dynamic>?;
    if (_timeline == null) return const SizedBox.shrink(); // لا اتصال — لا نعرض شيئاً بدل بيانات وهمية

    const trendLabels = {
      'improving': 'حالتك تتحسّن 📈',
      'worsening': 'حالتك تتراجع — تواصل مع Buddy Officer 📉',
      'stable': 'حالتك مستقرة ➡️',
    };
    final trend = _timeline?['improvementTrend'] as String?;

    return Padding(
      padding: const EdgeInsets.only(top: 16),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: BuddyColors.sage.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              buddyOfficer != null ? '👤 ${buddyOfficer['name']}' : '👤 لا Buddy Officer معيَّن لك حالياً',
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5, color: BuddyColors.navy),
            ),
            if (trend != null && trendLabels.containsKey(trend)) ...[
              const SizedBox(height: 4),
              Text(trendLabels[trend]!,
                  style: const TextStyle(fontSize: 11.5, color: BuddyColors.inkSoft, fontWeight: FontWeight.w700)),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final storage = ref.watch(localStorageProvider);
    final latest = storage.getLatestCheckin();
    final daysSince = storage.daysSinceLastCheckin();

    // 🆕 الدرجة الرسمية من الخادم (إن تمت المزامنة) تُستبدل بها الدرجة
    // المحلية المؤقتة — نفس منطق renderScoreRing() في PWA. serverResultJson
    // يبقى null قبل أول مزامنة ناجحة، فنعرض التقدير المحلي عندها فقط.
    Map<String, dynamic>? serverResult;
    if (latest?.serverResultJson != null) {
      serverResult = jsonDecode(latest!.serverResultJson!) as Map<String, dynamic>;
    }
    final displayScore = serverResult != null
        ? (serverResult['bprs']['score'] as num).toStringAsFixed(0)
        : latest?.bprsScoreAtEntry.toStringAsFixed(0);
    final displayLevel = serverResult != null
        ? serverResult['bprs']['level'] as String
        : latest?.riskLevelAtEntry;
    final isOfficial = serverResult != null;

    return Scaffold(
      backgroundColor: BuddyColors.paper,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('مساء الخير',
                  style: TextStyle(color: BuddyColors.inkSoft, fontSize: 12)),
              const Text('كريم',
                  style: TextStyle(
                      color: BuddyColors.navy, fontWeight: FontWeight.w800, fontSize: 20)),
              const SizedBox(height: 28),
              if (latest == null)
                Card(
                  color: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  child: const Padding(
                    padding: EdgeInsets.all(20),
                    child: Text(
                      'لا يوجد بعد أي تسجيل يومي.\nالنظام يعتمد حالياً على مؤشرات الدورة (28/28) فقط.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: BuddyColors.inkSoft),
                    ),
                  ),
                )
              else
                Center(
                  child: Column(
                    children: [
                      CircleAvatar(
                        radius: 56,
                        backgroundColor: _colorForLevel(displayLevel!).withOpacity(0.15),
                        child: Text(
                          displayScore!,
                          style: TextStyle(
                            fontSize: 34,
                            fontWeight: FontWeight.w800,
                            color: _colorForLevel(displayLevel),
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        isOfficial ? 'رسمي من الخادم' : 'تقدير محلي فوري (بانتظار المزامنة)',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: isOfficial ? BuddyColors.sage : BuddyColors.terracotta,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text('آخر تسجيل: قبل $daysSince يوم',
                          style: const TextStyle(color: BuddyColors.inkSoft, fontSize: 12)),
                    ],
                  ),
                ),
              _buildBuddyCard(),
              const Spacer(),
              OutlinedButton(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const AnonymousReportScreen()),
                ),
                style: OutlinedButton.styleFrom(
                  foregroundColor: BuddyColors.navy,
                  side: const BorderSide(color: Color(0xFFE1DACB)),
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
                ),
                child: const Text('الإبلاغ المجهول', style: TextStyle(fontWeight: FontWeight.w800)),
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: () async {
                  await Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const CheckinScreen()),
                  );
                  // عند العودة من شاشة Check-in، أعد تحميل بيانات Buddy —
                  // قد تكون نبضة جديدة صعّدت المستوى وأنشأت إشعاراً.
                  _loadBuddyInfo();
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: BuddyColors.sage,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
                ),
                child: const Text('نبض العافية اليومي',
                    style: TextStyle(fontWeight: FontWeight.w800)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
