"""
tests/test_fatigue_engine.py — اختبارات وحدة حقيقية لمحرك الإرهاق
(app/fatigue_engine.py). حساب فعلي، لا محاكاة.
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.bprs_engine import RotationContext, RiskLevel
from app.fatigue_engine import compute_instant_fatigue, blend_with_rolling_average, estimate_sleep_hours


class TestFatigueEngine(unittest.TestCase):
    def test_healthy_context_stays_green(self):
        ctx = RotationContext(day_in_rotation_cycle=3, days_since_last_checkin=0,
                               hours_worked_last_24h=8, is_night_shift=False,
                               distance_from_family_km=50)
        result = compute_instant_fatigue(ctx, sleep_hours_last_24h=7.5)
        self.assertEqual(result.level, RiskLevel.GREEN)
        self.assertFalse(result.sleep_hours_is_estimated)

    def test_critical_context_reaches_red(self):
        ctx = RotationContext(day_in_rotation_cycle=27, days_since_last_checkin=0,
                               hours_worked_last_24h=15, is_night_shift=True,
                               distance_from_family_km=900)
        result = compute_instant_fatigue(ctx, sleep_hours_last_24h=3)
        self.assertEqual(result.level, RiskLevel.RED)

    def test_missing_sleep_hours_falls_back_to_estimate_and_flags_it(self):
        ctx = RotationContext(day_in_rotation_cycle=5, days_since_last_checkin=0,
                               hours_worked_last_24h=9, is_night_shift=False,
                               distance_from_family_km=100)
        result = compute_instant_fatigue(ctx, sleep_hours_last_24h=None, sleep_disruption_fallback=8)
        self.assertTrue(result.sleep_hours_is_estimated)
        self.assertAlmostEqual(result.sleep_hours_used, estimate_sleep_hours(8), places=1)
        self.assertTrue(any("مُقدَّرة" in r for r in result.reasons))

    def test_score_clamped_between_0_and_100(self):
        ctx = RotationContext(day_in_rotation_cycle=28, days_since_last_checkin=0,
                               hours_worked_last_24h=24, is_night_shift=True,
                               distance_from_family_km=2000)
        result = compute_instant_fatigue(ctx, sleep_hours_last_24h=0)
        self.assertGreaterEqual(result.score, 0.0)
        self.assertLessEqual(result.score, 100.0)

    def test_rolling_average_with_no_history_returns_instant_unchanged(self):
        ctx = RotationContext(day_in_rotation_cycle=5, days_since_last_checkin=0,
                               hours_worked_last_24h=9, is_night_shift=False,
                               distance_from_family_km=100)
        instant = compute_instant_fatigue(ctx, sleep_hours_last_24h=7)
        blended = blend_with_rolling_average(instant, [])
        self.assertEqual(blended.score, instant.score)
        self.assertIsNone(blended.rolling_average_7d)

    def test_rolling_average_computed_from_past_scores(self):
        ctx = RotationContext(day_in_rotation_cycle=5, days_since_last_checkin=0,
                               hours_worked_last_24h=9, is_night_shift=False,
                               distance_from_family_km=100)
        instant = compute_instant_fatigue(ctx, sleep_hours_last_24h=7)
        past = [40, 42, 38, 41, 39, 40, 41]  # الأحدث أولاً
        blended = blend_with_rolling_average(instant, past)
        self.assertAlmostEqual(blended.rolling_average_7d, sum(past) / len(past), places=1)
        self.assertEqual(blended.rolling_sample_size, 7)
        self.assertEqual(blended.trend_direction, "stable")

    def test_rolling_average_detects_rising_trend(self):
        ctx = RotationContext(day_in_rotation_cycle=5, days_since_last_checkin=0,
                               hours_worked_last_24h=9, is_night_shift=False,
                               distance_from_family_km=100)
        instant = compute_instant_fatigue(ctx, sleep_hours_last_24h=7)
        # الأحدث أولاً: قيم حديثة عالية جداً، قديمة منخفضة جداً => ترتفع
        past = [90, 88, 85, 20, 18, 15]
        blended = blend_with_rolling_average(instant, past)
        self.assertEqual(blended.trend_direction, "rising")

    def test_estimate_sleep_hours_bounds(self):
        self.assertEqual(estimate_sleep_hours(0), 8.0)
        self.assertGreaterEqual(estimate_sleep_hours(10), 3.0)


if __name__ == "__main__":
    unittest.main()
