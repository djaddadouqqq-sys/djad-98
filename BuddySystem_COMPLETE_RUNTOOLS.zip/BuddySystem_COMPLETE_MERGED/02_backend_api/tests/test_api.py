"""
tests/test_api.py

Tests d'intégration RÉELS : démarre le serveur HTTP sur un port de test,
puis envoie de vraies requêtes HTTP (via urllib, bibliothèque standard)
et vérifie les réponses. Ce ne sont pas des tests simulés — ils exercent
le code exactement comme le ferait l'application Flutter en production.

Exécution : python3 -m pytest tests/test_api.py -v
(ou, sans pytest : python3 tests/test_api.py)
"""

import json
import os
import sys
import threading
import time
import unittest
import urllib.request
import urllib.error
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import db
from app.server import create_server

TEST_PORT = 8731
BASE_URL = f"http://127.0.0.1:{TEST_PORT}"
API_KEY = "pilot-demo-key-2026"  # tenant "Sonatrach — Pilot CPH" (seed par défaut)
API_KEY_TENANT_B = "tenant-b-schlumberger-demo-key"


def now_iso():
    """طابع زمني ديناميكي دائماً — إصلاح حقيقي: تواريخ مُثبَّتة
    يدوياً كانت تخرج بصمت من نافذة الـ30 يوماً المتحركة مع تقدّم
    الزمن الفعلي، مسبِّبة فشلاً حتمياً لاحقاً بلا أي تغيير بالكود."""
    return datetime.now(timezone.utc).isoformat()


def _request(method, path, payload=None, headers=None):
    url = BASE_URL + path
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode("utf-8"))


class TestBuddyApi(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        os.environ["BUDDY_DB_PATH"] = "test_buddy_system.db"
        db.reset_db_for_tests()
        cls.server = create_server(host="127.0.0.1", port=TEST_PORT)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        time.sleep(0.3)  # laisse le serveur démarrer

        # Ajoute un second tenant pour prouver l'isolation multi-tenant.
        import uuid
        from datetime import datetime, timezone
        conn = db.get_connection()
        conn.execute(
            "INSERT INTO tenants (id, name, api_key, rotation_cycle_days, created_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (str(uuid.uuid4()), "Schlumberger — Démo", API_KEY_TENANT_B, 14,
             datetime.now(timezone.utc).isoformat()),
        )
        conn.commit()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        db.reset_db_for_tests()

    def test_health_check(self):
        status, body = _request("GET", "/health")
        self.assertEqual(status, 200)
        self.assertEqual(body["status"], "ok")

    def test_checkin_requires_auth(self):
        status, body = _request("POST", "/v1/checkins/anonymous", payload={
            "workerIdHash": "abc123",
            "createdAt": now_iso(),
            "bprsScore": 42,
            "riskLevel": "yellow",
        })
        self.assertEqual(status, 401)

    def test_checkin_valid_submission(self):
        status, body = _request("POST", "/v1/checkins/anonymous", payload={
            "workerIdHash": "hash-worker-001",
            "createdAt": now_iso(),
            "bprsScore": 42,
            "riskLevel": "yellow",
            "siteCode": "CPH-12",
        }, headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 201)
        self.assertTrue(body["stored"])
        self.assertIn("id", body)

    def test_checkin_rejects_invalid_risk_level(self):
        status, body = _request("POST", "/v1/checkins/anonymous", payload={
            "workerIdHash": "hash-worker-002",
            "createdAt": now_iso(),
            "bprsScore": 90,
            "riskLevel": "purple",  # invalide
        }, headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 422)
        self.assertEqual(body["error"], "invalid_risk_level")

    def test_checkin_rejects_missing_fields(self):
        status, body = _request("POST", "/v1/checkins/anonymous", payload={
            "workerIdHash": "hash-worker-003",
        }, headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 422)
        self.assertEqual(body["error"], "missing_fields")

    def test_dashboard_summary_reflects_submitted_checkins(self):
        # Soumet plusieurs check-ins puis vérifie l'agrégation.
        for score, level in [(20, "green"), (40, "yellow"), (80, "red")]:
            _request("POST", "/v1/checkins/anonymous", payload={
                "workerIdHash": f"hash-{score}",
                "createdAt": now_iso(),
                "bprsScore": score,
                "riskLevel": level,
                "siteCode": "CPH-12",
            }, headers={"X-API-Key": API_KEY})

        status, body = _request("GET", "/v1/dashboard/summary?days=30&site_code=CPH-12",
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 200)
        self.assertGreaterEqual(body["total_checkins"], 3)
        self.assertGreaterEqual(body["red_alert_count"], 1)

    def test_anonymous_report_submission(self):
        status, body = _request("POST", "/v1/reports/anonymous", payload={
            "category": "mobbing",
            "message": "زميل يتعرض لضغط متكرر من المشرف المباشر.",
            "siteCode": "CPH-12",
        }, headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 201)
        self.assertTrue(body["stored"])

    def test_dashboard_summary_includes_anonymous_report_counts(self):
        """Le tableau de bord HSE doit refléter les signalements anonymes,
        agrégés par catégorie, sans jamais exposer leur contenu ni leur
        auteur — uniquement des totaux."""
        for category in ["mobbing", "harassment", "burnout"]:
            status, _ = _request("POST", "/v1/reports/anonymous", payload={
                "category": category,
                "message": f"Signalement de test — {category}",
                "siteCode": "REPORT-SITE",
            }, headers={"X-API-Key": API_KEY})
            self.assertEqual(status, 201)

        status, body = _request("GET", "/v1/dashboard/summary?site_code=REPORT-SITE",
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 200)
        self.assertIn("anonymous_reports", body)
        self.assertEqual(body["anonymous_reports"]["total"], 3)
        self.assertEqual(body["anonymous_reports"]["by_category"]["mobbing"], 1)
        self.assertEqual(body["anonymous_reports"]["by_category"]["harassment"], 1)
        self.assertEqual(body["anonymous_reports"]["by_category"]["burnout"], 1)
        self.assertEqual(body["anonymous_reports"]["by_category"]["other"], 0)

        # Le contenu textuel des signalements ne doit JAMAIS apparaître
        # dans la réponse du tableau de bord (agrégats uniquement).
        body_str = json.dumps(body)
        self.assertNotIn("Signalement de test", body_str)

    def test_anonymous_report_rejects_invalid_category(self):
        status, body = _request("POST", "/v1/reports/anonymous", payload={
            "category": "not_a_real_category",
            "message": "test",
        }, headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 422)

    def test_unknown_route_returns_404(self):
        status, body = _request("GET", "/v1/does/not/exist", headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 404)


    def test_multi_tenant_data_isolation(self):
        """Le test le plus important de cette suite : deux clients
        (tenants) différents, même code de site (par coïncidence),
        et on vérifie qu'AUCUNE donnée ne fuit de l'un vers l'autre."""

        # Tenant A (Sonatrach) soumet 2 check-ins.
        for score, level in [(30, "yellow"), (85, "red")]:
            status, _ = _request("POST", "/v1/checkins/anonymous", payload={
                "workerIdHash": f"tenantA-{score}",
                "createdAt": now_iso(),
                "bprsScore": score,
                "riskLevel": level,
                "siteCode": "SITE-01",
            }, headers={"X-API-Key": API_KEY})
            self.assertEqual(status, 201)

        # Tenant B (Schlumberger) soumet 1 seul check-in, même site_code.
        status, _ = _request("POST", "/v1/checkins/anonymous", payload={
            "workerIdHash": "tenantB-only",
            "createdAt": now_iso(),
            "bprsScore": 10,
            "riskLevel": "green",
            "siteCode": "SITE-01",
        }, headers={"X-API-Key": API_KEY_TENANT_B})
        self.assertEqual(status, 201)

        # Le tableau de bord du Tenant B ne doit voir QUE son propre
        # check-in (1), jamais les 2 du Tenant A, même si les autres
        # tests précédents ont déjà ajouté des données pour le Tenant A.
        status, body_b = _request("GET", "/v1/dashboard/summary?site_code=SITE-01",
                                   headers={"X-API-Key": API_KEY_TENANT_B})
        self.assertEqual(status, 200)
        self.assertEqual(body_b["total_checkins"], 1)
        self.assertEqual(body_b["risk_level_distribution"]["red"], 0)

        # Le tableau de bord du Tenant A, sur le même site_code, doit
        # voir ses 2 check-ins et surtout ne JAMAIS inclure celui du
        # Tenant B (donc jamais de score de 10 / green comptabilisé ici
        # au-delà de ce que le Tenant A a lui-même soumis).
        status, body_a = _request("GET", "/v1/dashboard/summary?site_code=SITE-01",
                                   headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 200)
        self.assertEqual(body_a["total_checkins"], 2)
        self.assertEqual(body_a["risk_level_distribution"]["red"], 1)

        # Un jeton invalide ne doit jamais résoudre à un tenant existant.
        status, _ = _request("GET", "/v1/dashboard/summary",
                              headers={"X-API-Key": "totally-invalid-key"})
        self.assertEqual(status, 401)

    def test_tenant_identity_endpoint(self):
        status, body = _request("GET", "/v1/tenant/me", headers={"X-API-Key": API_KEY_TENANT_B})
        self.assertEqual(status, 200)
        self.assertEqual(body["tenant"]["name"], "Schlumberger — Démo")
        self.assertEqual(body["tenant"]["rotation_cycle_days"], 14)

    def test_admin_create_tenant_requires_admin_key(self):
        status, body = _request("POST", "/v1/admin/tenants", payload={
            "name": "Halliburton — Test",
            "apiKey": "halliburton-key-should-fail",
        })  # aucun X-Admin-Key fourni
        self.assertEqual(status, 403)

    def test_admin_create_tenant_success_and_immediate_use(self):
        status, body = _request("POST", "/v1/admin/tenants", payload={
            "name": "Halliburton — Pilot",
            "apiKey": "halliburton-real-key-2026",
            "rotationCycleDays": 21,
        }, headers={"X-Admin-Key": "founder-admin-key-2026"})
        self.assertEqual(status, 201)
        self.assertTrue(body["stored"])
        new_tenant_id = body["id"]

        # Le tenant fraîchement créé doit pouvoir s'authentifier
        # IMMÉDIATEMENT et soumettre un check-in — preuve que la création
        # via API est réellement opérationnelle de bout en bout.
        status, me_body = _request("GET", "/v1/tenant/me",
                                    headers={"X-API-Key": "halliburton-real-key-2026"})
        self.assertEqual(status, 200)
        self.assertEqual(me_body["tenant"]["id"], new_tenant_id)
        self.assertEqual(me_body["tenant"]["rotation_cycle_days"], 21)

        status, _ = _request("POST", "/v1/checkins/anonymous", payload={
            "workerIdHash": "halliburton-worker-001",
            "createdAt": now_iso(),
            "bprsScore": 22,
            "riskLevel": "green",
            "siteCode": "HAL-SITE-1",
        }, headers={"X-API-Key": "halliburton-real-key-2026"})
        self.assertEqual(status, 201)

    def test_admin_create_tenant_rejects_duplicate_api_key(self):
        status, _ = _request("POST", "/v1/admin/tenants", payload={
            "name": "Doublon Tentative",
            "apiKey": API_KEY,  # déjà utilisée par le tenant Sonatrach seedé
        }, headers={"X-Admin-Key": "founder-admin-key-2026"})
        self.assertEqual(status, 409)

    def test_admin_list_tenants(self):
        status, body = _request("GET", "/v1/admin/tenants",
                                 headers={"X-Admin-Key": "founder-admin-key-2026"})
        self.assertEqual(status, 200)
        names = [t["name"] for t in body["tenants"]]
        self.assertIn("Sonatrach — Pilot CPH", names)
        self.assertIn("Schlumberger — Démo", names)
        # La clé API ne doit JAMAIS apparaître en clair dans cette réponse.
        for t in body["tenants"]:
            self.assertNotIn("api_key", t)
            self.assertIn("api_key_suffix", t)

    # ---------------- Authentification individuelle des employés ----------------

    def test_admin_provision_worker_requires_admin_key(self):
        status, _ = _request("POST", "/v1/admin/workers", payload={
            "tenantId": "whatever", "employeeId": "SNTR-001", "pin": "1234",
        })
        self.assertEqual(status, 403)

    def test_admin_provision_worker_rejects_short_pin(self):
        status, body = _request("POST", "/v1/admin/workers", payload={
            "tenantId": "whatever", "employeeId": "SNTR-002", "pin": "12",
        }, headers={"X-Admin-Key": "founder-admin-key-2026"})
        self.assertEqual(status, 422)
        self.assertEqual(body["error"], "pin_too_short")

    def _get_sonatrach_tenant_id(self):
        status, body = _request("GET", "/v1/tenant/me", headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 200)
        return body["tenant"]["id"]

    def test_worker_provision_login_and_authenticated_checkin_flow(self):
        """Le scénario complet, de bout en bout : un administrateur
        provisionne un employé, l'employé se connecte avec son PIN,
        obtient un jeton, et ce jeton fait autorité sur l'identité
        enregistrée dans le check-in — même si un workerIdHash différent
        est fourni dans le corps de la requête (le jeton doit l'emporter)."""
        tenant_id = self._get_sonatrach_tenant_id()

        status, prov_body = _request("POST", "/v1/admin/workers", payload={
            "tenantId": tenant_id,
            "employeeId": "SNTR-20481",
            "pin": "7391",
        }, headers={"X-Admin-Key": "founder-admin-key-2026"})
        self.assertEqual(status, 201)

        status, _ = _request("POST", "/v1/auth/worker/login", payload={
            "employeeId": "SNTR-20481", "pin": "0000",
        }, headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 401)

        status, login_body = _request("POST", "/v1/auth/worker/login", payload={
            "employeeId": "SNTR-20481", "pin": "7391",
        }, headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 200)
        self.assertIn("token", login_body)
        real_worker_hash = login_body["workerIdHash"]

        status, checkin_body = _request("POST", "/v1/checkins/anonymous", payload={
            "workerIdHash": "fake-identity-attempt",
            "createdAt": now_iso(),
            "bprsScore": 15,
            "riskLevel": "green",
            "siteCode": "CPH-AUTH-TEST",
        }, headers={"X-API-Key": API_KEY, "X-Worker-Token": login_body["token"]})
        self.assertEqual(status, 201)

        from app.db import execute_read
        row = execute_read(
            "SELECT worker_id_hash FROM checkins WHERE id = ?", (checkin_body["id"],), one=True
        )
        self.assertEqual(row["worker_id_hash"], real_worker_hash)
        self.assertNotEqual(row["worker_id_hash"], "fake-identity-attempt")

    def test_checkin_rejects_worker_token_from_wrong_tenant(self):
        status, body = _request("GET", "/v1/tenant/me", headers={"X-API-Key": API_KEY_TENANT_B})
        tenant_b_id = body["tenant"]["id"]

        _request("POST", "/v1/admin/workers", payload={
            "tenantId": tenant_b_id, "employeeId": "SLB-001", "pin": "5555",
        }, headers={"X-Admin-Key": "founder-admin-key-2026"})

        status, login_body = _request("POST", "/v1/auth/worker/login", payload={
            "employeeId": "SLB-001", "pin": "5555",
        }, headers={"X-API-Key": API_KEY_TENANT_B})
        self.assertEqual(status, 200)

        status, err_body = _request("POST", "/v1/checkins/anonymous", payload={
            "workerIdHash": "irrelevant",
            "createdAt": now_iso(),
            "bprsScore": 15,
            "riskLevel": "green",
        }, headers={"X-API-Key": API_KEY, "X-Worker-Token": login_body["token"]})
        self.assertEqual(status, 403)
        self.assertEqual(err_body["error"], "worker_token_tenant_mismatch")

    def test_checkin_rejects_garbage_worker_token(self):
        status, body = _request("POST", "/v1/checkins/anonymous", payload={
            "workerIdHash": "irrelevant",
            "createdAt": now_iso(),
            "bprsScore": 15,
            "riskLevel": "green",
        }, headers={"X-API-Key": API_KEY, "X-Worker-Token": "not.a.realtoken"})
        self.assertEqual(status, 401)
        self.assertEqual(body["error"], "invalid_or_expired_worker_token")

    def test_anonymous_report_remains_anonymous_even_with_worker_token(self):
        """Garde-fou critique : même authentifié, un employé qui soumet
        un signalement anonyme ne doit JAMAIS voir son identité liée au
        signalement — l'endpoint ignore totalement X-Worker-Token."""
        tenant_id = self._get_sonatrach_tenant_id()
        _request("POST", "/v1/admin/workers", payload={
            "tenantId": tenant_id, "employeeId": "SNTR-ANON-TEST", "pin": "9999",
        }, headers={"X-Admin-Key": "founder-admin-key-2026"})
        status, login_body = _request("POST", "/v1/auth/worker/login", payload={
            "employeeId": "SNTR-ANON-TEST", "pin": "9999",
        }, headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 200)

        status, report_body = _request("POST", "/v1/reports/anonymous", payload={
            "category": "harassment",
            "message": "Test d'anonymat malgré authentification.",
        }, headers={"X-API-Key": API_KEY, "X-Worker-Token": login_body["token"]})
        self.assertEqual(status, 201)

        from app.db import execute_read
        cols = [r["name"] for r in execute_read("PRAGMA table_info(anonymous_reports)")]
        self.assertNotIn("worker_id_hash", cols)
        self.assertNotIn("employee_id", cols)

    # ---------------- Protection contre la force brute (rate limiting) ----------------

    def test_brute_force_lockout_after_max_attempts(self):
        from app import rate_limiter
        rate_limiter.configure(max_attempts=3, window_seconds=600, lockout_seconds=2)
        rate_limiter.reset_all_for_tests()

        tenant_id = self._get_sonatrach_tenant_id()
        _request("POST", "/v1/admin/workers", payload={
            "tenantId": tenant_id, "employeeId": "SNTR-BRUTE-TEST", "pin": "1357",
        }, headers={"X-Admin-Key": "founder-admin-key-2026"})

        # 3 محاولات خاطئة متتالية (تصل للعتبة بالضبط)
        for _ in range(3):
            status, _ = _request("POST", "/v1/auth/worker/login", payload={
                "employeeId": "SNTR-BRUTE-TEST", "pin": "0000",
            }, headers={"X-API-Key": API_KEY})
            self.assertEqual(status, 401)

        # المحاولة الرابعة — حتى برمز سري صحيح — يجب أن تُرفض بـ429
        status, body = _request("POST", "/v1/auth/worker/login", payload={
            "employeeId": "SNTR-BRUTE-TEST", "pin": "1357",  # الرمز الصحيح فعلياً
        }, headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 429)
        self.assertEqual(body["error"], "too_many_attempts")
        self.assertIn("retryAfterSeconds", body)
        self.assertGreater(body["retryAfterSeconds"], 0)

        # بعد انتهاء مدة القفل (2 ثانية في هذا الاختبار)، يجب أن يُسمح بالدخول مجدداً
        time.sleep(2.2)
        status, body = _request("POST", "/v1/auth/worker/login", payload={
            "employeeId": "SNTR-BRUTE-TEST", "pin": "1357",
        }, headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 200)
        self.assertIn("token", body)

        rate_limiter.configure(max_attempts=5, window_seconds=600, lockout_seconds=300)  # إعادة القيم الافتراضية

    def test_successful_login_resets_failure_counter(self):
        from app import rate_limiter
        rate_limiter.configure(max_attempts=3, window_seconds=600, lockout_seconds=300)
        rate_limiter.reset_all_for_tests()

        tenant_id = self._get_sonatrach_tenant_id()
        _request("POST", "/v1/admin/workers", payload={
            "tenantId": tenant_id, "employeeId": "SNTR-RESET-TEST", "pin": "2468",
        }, headers={"X-Admin-Key": "founder-admin-key-2026"})

        # محاولتان فاشلتان فقط (دون الوصول للعتبة)
        for _ in range(2):
            _request("POST", "/v1/auth/worker/login", payload={
                "employeeId": "SNTR-RESET-TEST", "pin": "0000",
            }, headers={"X-API-Key": API_KEY})

        # نجاح — يجب أن يُصفّر العداد
        status, _ = _request("POST", "/v1/auth/worker/login", payload={
            "employeeId": "SNTR-RESET-TEST", "pin": "2468",
        }, headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 200)

        # محاولتان فاشلتان إضافيتان بعد النجاح — يجب ألا تُقفَل الحساب
        # (لأن النجاح صفّر العداد، فهذه بداية جديدة تحت العتبة 3)
        for _ in range(2):
            status, _ = _request("POST", "/v1/auth/worker/login", payload={
                "employeeId": "SNTR-RESET-TEST", "pin": "0000",
            }, headers={"X-API-Key": API_KEY})
            self.assertEqual(status, 401)  # فشل عادي، ليس 429

        rate_limiter.configure(max_attempts=5, window_seconds=600, lockout_seconds=300)


    # ---------------- سجل التدقيق (Audit Log) ----------------

    def test_audit_log_requires_admin_key(self):
        status, _ = _request("GET", "/v1/admin/audit-log")
        self.assertEqual(status, 403)

    def test_tenant_creation_is_audited(self):
        status, body = _request("POST", "/v1/admin/tenants", payload={
            "name": "Audit Test Co", "apiKey": "audit-test-tenant-key",
        }, headers={"X-Admin-Key": "founder-admin-key-2026"})
        self.assertEqual(status, 201)
        new_tenant_id = body["id"]

        status, log_body = _request("GET", f"/v1/admin/audit-log?tenant_id={new_tenant_id}",
                                     headers={"X-Admin-Key": "founder-admin-key-2026"})
        self.assertEqual(status, 200)
        actions = [e["action"] for e in log_body["entries"]]
        self.assertIn("tenant_created", actions)

    def test_worker_provisioning_and_login_are_audited_without_leaking_pin(self):
        tenant_id = self._get_sonatrach_tenant_id()
        _request("POST", "/v1/admin/workers", payload={
            "tenantId": tenant_id, "employeeId": "SNTR-AUDIT-TEST", "pin": "6060",
        }, headers={"X-Admin-Key": "founder-admin-key-2026"})

        _request("POST", "/v1/auth/worker/login", payload={
            "employeeId": "SNTR-AUDIT-TEST", "pin": "0000",  # فشل متعمّد
        }, headers={"X-API-Key": API_KEY})

        _request("POST", "/v1/auth/worker/login", payload={
            "employeeId": "SNTR-AUDIT-TEST", "pin": "6060",  # نجاح
        }, headers={"X-API-Key": API_KEY})

        status, log_body = _request("GET", f"/v1/admin/audit-log?tenant_id={tenant_id}&limit=200",
                                     headers={"X-Admin-Key": "founder-admin-key-2026"})
        self.assertEqual(status, 200)

        actions = [e["action"] for e in log_body["entries"]]
        self.assertIn("worker_provisioned", actions)
        self.assertIn("login_failed", actions)
        self.assertIn("login_success", actions)

        # الفحص الأمني الأهم: لا وجود مطلقاً لأي PIN (لا الصحيح 6060 ولا
        # الخاطئ 0000) في أي مكان من نص السجل بأكمله.
        full_log_text = json.dumps(log_body)
        self.assertNotIn("6060", full_log_text)
        self.assertNotIn('"0000"', full_log_text)

    def test_audit_log_filters_by_action(self):
        status, body = _request("GET", "/v1/admin/audit-log?action=tenant_created&limit=500",
                                 headers={"X-Admin-Key": "founder-admin-key-2026"})
        self.assertEqual(status, 200)
        for entry in body["entries"]:
            self.assertEqual(entry["action"], "tenant_created")

    # ---------------- PsychoTech Layer : /v1/checkins/full + /v1/dashboard/risks ----------------

    FULL_CHECKIN_HEALTHY = {
        "physicalFatigue": 1, "mentalFatigue": 1, "sleepDisruption": 1,
        "lowEmpowerment": 1, "lowResilience": 1, "isolation": 1,
        "dayInRotationCycle": 3, "daysSinceLastCheckin": 0,
        "hoursWorkedLast24h": 8, "isNightShift": False, "distanceFromFamilyKm": 50,
    }

    FULL_CHECKIN_CRITICAL = {
        "physicalFatigue": 10, "mentalFatigue": 10, "sleepDisruption": 10,
        "lowEmpowerment": 10, "lowResilience": 10, "isolation": 10,
        "dayInRotationCycle": 27, "daysSinceLastCheckin": 10,
        "hoursWorkedLast24h": 14, "isNightShift": True, "distanceFromFamilyKm": 900,
    }

    def test_full_checkin_requires_auth(self):
        payload = dict(self.FULL_CHECKIN_HEALTHY, workerIdHash="hash-full-001", createdAt=now_iso())
        status, body = _request("POST", "/v1/checkins/full", payload=payload)
        self.assertEqual(status, 401)

    def test_full_checkin_rejects_missing_fields(self):
        status, body = _request("POST", "/v1/checkins/full", payload={"workerIdHash": "x"},
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 422)
        self.assertEqual(body["error"], "missing_fields")

    def test_full_checkin_computes_server_side_and_returns_eight_risks(self):
        payload = dict(self.FULL_CHECKIN_HEALTHY, workerIdHash="hash-full-002",
                       createdAt=now_iso(), siteCode="CPH-12")
        status, body = _request("POST", "/v1/checkins/full", payload=payload,
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 201)
        self.assertTrue(body["stored"])
        self.assertEqual(body["bprs"]["level"], "green")
        self.assertEqual(len(body["risks"]), 8)
        self.assertFalse(body["urgent"])
        self.assertEqual(body["urgentActions"], [])
        for r in body["risks"]:
            self.assertIn("interventions", r)
            self.assertTrue(len(r["interventions"]) > 0)

    def test_full_checkin_critical_inputs_trigger_urgent_flag_and_actions(self):
        payload = dict(self.FULL_CHECKIN_CRITICAL, workerIdHash="hash-full-003",
                       createdAt=now_iso(), siteCode="CPH-12")
        status, body = _request("POST", "/v1/checkins/full", payload=payload,
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 201)
        self.assertTrue(body["urgent"])
        self.assertTrue(len(body["urgentActions"]) > 0)
        self.assertTrue(any("SOS" in a for a in body["urgentActions"]))
        red_risks = [r for r in body["risks"] if r["level"] == "red"]
        self.assertTrue(len(red_risks) > 0)

    def test_full_checkin_rejects_invalid_field_types(self):
        payload = dict(self.FULL_CHECKIN_HEALTHY, workerIdHash="hash-full-004", createdAt=now_iso())
        payload["physicalFatigue"] = "not-a-number"
        status, body = _request("POST", "/v1/checkins/full", payload=payload,
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 422)
        self.assertEqual(body["error"], "invalid_field_type")

    def test_dashboard_risks_requires_auth(self):
        status, body = _request("GET", "/v1/dashboard/risks")
        self.assertEqual(status, 401)

    def test_dashboard_risks_reflects_submitted_full_checkins(self):
        site = "RISKBOARD-01"
        payload = dict(self.FULL_CHECKIN_CRITICAL, workerIdHash="hash-full-005",
                       createdAt=now_iso(), siteCode=site)
        _request("POST", "/v1/checkins/full", payload=payload, headers={"X-API-Key": API_KEY})

        status, body = _request("GET", f"/v1/dashboard/risks?days=30&site_code={site}",
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 200)
        self.assertEqual(len(body["risks"]), 8)
        self.assertTrue(body["any_red_alert"])
        burnout = next(r for r in body["risks"] if r["id"] == "burnout")
        self.assertEqual(burnout["status"], "ok")
        self.assertEqual(burnout["latest_level"], "red")

    def test_dashboard_risks_reports_no_data_for_untouched_tenant(self):
        # Tenant B n'a soumis aucun /v1/checkins/full — chaque risque doit
        # revenir 'no_data', jamais un niveau vert par défaut inventé.
        status, body = _request("GET", "/v1/dashboard/risks?days=30",
                                 headers={"X-API-Key": API_KEY_TENANT_B})
        self.assertEqual(status, 200)
        for r in body["risks"]:
            self.assertEqual(r["status"], "no_data")
        self.assertFalse(body["any_red_alert"])

    def test_dashboard_risk_trend_requires_valid_risk_id(self):
        status, body = _request("GET", "/v1/dashboard/risk-trend?risk_id=not_a_real_risk",
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 422)
        self.assertEqual(body["error"], "invalid_risk_id")

    def test_dashboard_risk_trend_returns_weekly_series(self):
        status, body = _request("GET", "/v1/dashboard/risk-trend?risk_id=burnout&weeks=4",
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 200)
        self.assertEqual(body["risk_id"], "burnout")
        self.assertEqual(len(body["trend"]), 4)

    def test_full_checkin_mobbing_signal_blends_with_real_anonymous_reports(self):
        # يُثبت أن خطر 'mobbing' في /v1/dashboard/risks يتأثر فعلياً
        # ببلاغات mobbing الحقيقية المخزَّنة، لا فقط بالمُدخلات الذاتية.
        site = "MOBBING-BLEND-01"
        payload = dict(self.FULL_CHECKIN_HEALTHY, workerIdHash="hash-full-006",
                       createdAt=now_iso(), siteCode=site)
        _request("POST", "/v1/checkins/full", payload=payload, headers={"X-API-Key": API_KEY})

        status_before, body_before = _request(
            "GET", f"/v1/dashboard/risks?days=30&site_code={site}", headers={"X-API-Key": API_KEY})
        mobbing_before = next(r for r in body_before["risks"] if r["id"] == "mobbing")

        for _ in range(3):
            _request("POST", "/v1/reports/anonymous", payload={
                "category": "mobbing", "message": "ضغط متكرر من مشرف مباشر.", "siteCode": site,
            }, headers={"X-API-Key": API_KEY})

        status_after, body_after = _request(
            "GET", f"/v1/dashboard/risks?days=30&site_code={site}", headers={"X-API-Key": API_KEY})
        mobbing_after = next(r for r in body_after["risks"] if r["id"] == "mobbing")

        self.assertGreater(mobbing_after["average_score"], mobbing_before["average_score"])
        self.assertIsNotNone(mobbing_after["blended_note"])

    # ---------------- Fatigue Engine : /v1/dashboard/fatigue + fatigue في /v1/checkins/full ----------------

    def test_full_checkin_response_includes_fatigue_block(self):
        payload = dict(self.FULL_CHECKIN_HEALTHY, workerIdHash="fatigue-w-001", createdAt=now_iso())
        status, body = _request("POST", "/v1/checkins/full", payload=payload, headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 201)
        self.assertIn("fatigue", body)
        self.assertIn(body["fatigue"]["level"], ("green", "yellow", "orange", "red"))
        self.assertTrue(body["fatigue"]["sleepHoursIsEstimated"])  # لا sleepHoursLast24h في هذا الـpayload

    def test_full_checkin_accepts_explicit_sleep_hours(self):
        payload = dict(self.FULL_CHECKIN_HEALTHY, workerIdHash="fatigue-w-002", createdAt=now_iso(),
                       sleepHoursLast24h=7.5)
        status, body = _request("POST", "/v1/checkins/full", payload=payload, headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 201)
        self.assertFalse(body["fatigue"]["sleepHoursIsEstimated"])
        self.assertEqual(body["fatigue"]["sleepHoursUsed"], 7.5)

    def test_full_checkin_critical_fatigue_context_triggers_urgent(self):
        payload = dict(self.FULL_CHECKIN_HEALTHY, workerIdHash="fatigue-w-003", createdAt=now_iso(),
                       sleepHoursLast24h=2, hoursWorkedLast24h=15, dayInRotationCycle=27, isNightShift=True)
        status, body = _request("POST", "/v1/checkins/full", payload=payload, headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 201)
        self.assertEqual(body["fatigue"]["level"], "red")
        self.assertTrue(body["urgent"])  # الإرهاق الأحمر وحده كافٍ لرفع urgent

    def test_full_checkin_rolling_average_accumulates_across_checkins_for_same_worker(self):
        worker = "fatigue-w-rolling-01"
        for _ in range(3):
            payload = dict(self.FULL_CHECKIN_HEALTHY, workerIdHash=worker, createdAt=now_iso(),
                           sleepHoursLast24h=7.5)
            _request("POST", "/v1/checkins/full", payload=payload, headers={"X-API-Key": API_KEY})

        payload = dict(self.FULL_CHECKIN_HEALTHY, workerIdHash=worker, createdAt=now_iso(),
                       sleepHoursLast24h=7.5)
        status, body = _request("POST", "/v1/checkins/full", payload=payload, headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 201)
        self.assertIsNotNone(body["fatigue"]["rollingAverage7d"])
        self.assertEqual(body["fatigue"]["rollingSampleSize"], 3)

    def test_dashboard_fatigue_requires_auth(self):
        status, body = _request("GET", "/v1/dashboard/fatigue")
        self.assertEqual(status, 401)

    def test_dashboard_fatigue_reflects_submitted_checkins(self):
        site = "FATIGUE-BOARD-01"
        payload = dict(self.FULL_CHECKIN_HEALTHY, workerIdHash="fatigue-w-004", createdAt=now_iso(),
                       siteCode=site, sleepHoursLast24h=7.5)
        _request("POST", "/v1/checkins/full", payload=payload, headers={"X-API-Key": API_KEY})

        status, body = _request("GET", f"/v1/dashboard/fatigue?site_code={site}", headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 200)
        self.assertEqual(body["status"], "ok")
        self.assertEqual(body["sample_size"], 1)
        self.assertIsNotNone(body["average_score"])

    def test_dashboard_fatigue_reports_no_data_for_untouched_tenant(self):
        status, body = _request("GET", "/v1/dashboard/fatigue", headers={"X-API-Key": API_KEY_TENANT_B})
        self.assertEqual(status, 200)
        self.assertEqual(body["status"], "no_data")
        self.assertEqual(body["sample_size"], 0)

    # ---------------- Timeline العامل : /v1/workers/timeline ----------------

    def test_worker_timeline_requires_auth(self):
        status, body = _request("GET", "/v1/workers/timeline?workerIdHash=x")
        self.assertEqual(status, 401)

    def test_worker_timeline_requires_worker_id(self):
        status, body = _request("GET", "/v1/workers/timeline", headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 422)
        self.assertEqual(body["error"], "missing_fields")

    def test_worker_timeline_returns_chronological_history_with_bprs_risks_fatigue(self):
        worker = "timeline-w-001"
        for day in (5, 12, 20):
            payload = dict(self.FULL_CHECKIN_HEALTHY, workerIdHash=worker, createdAt=now_iso(),
                           dayInRotationCycle=day, sleepHoursLast24h=7)
            status, _ = _request("POST", "/v1/checkins/full", payload=payload, headers={"X-API-Key": API_KEY})
            self.assertEqual(status, 201)

        status, body = _request("GET", f"/v1/workers/timeline?workerIdHash={worker}", headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 200)
        self.assertEqual(body["count"], 3)
        entry = body["timeline"][0]
        self.assertIn("bprs", entry)
        self.assertIn("risks", entry)
        self.assertEqual(len(entry["risks"]), 8)
        self.assertIn("fatigue", entry)
        self.assertIn("dayInRotationCycle", entry)

    def test_worker_timeline_empty_for_unknown_worker(self):
        status, body = _request("GET", "/v1/workers/timeline?workerIdHash=never-existed",
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 200)
        self.assertEqual(body["count"], 0)
        self.assertEqual(body["timeline"], [])

    def test_worker_timeline_isolated_between_tenants(self):
        # عامل بنفس المُعرِّف الاسمي عند تينانت آخر يجب ألا يظهر هنا
        worker = "cross-tenant-worker-01"
        payload = dict(self.FULL_CHECKIN_HEALTHY, workerIdHash=worker, createdAt=now_iso())
        _request("POST", "/v1/checkins/full", payload=payload, headers={"X-API-Key": API_KEY})

        status, body = _request("GET", f"/v1/workers/timeline?workerIdHash={worker}",
                                 headers={"X-API-Key": API_KEY_TENANT_B})
        self.assertEqual(status, 200)
        self.assertEqual(body["count"], 0)

    # ---------------- Buddy System : تعيين ----------------

    def _create_officer(self, name="Karim B.", contact="karim@example.com", username=None, password=None):
        payload = {"name": name, "contactInfo": contact}
        if username:
            payload["username"] = username
            payload["password"] = password
        status, body = _request("POST", "/v1/buddy/officers",
                                 payload=payload,
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 201)
        return body["id"]

    def test_create_buddy_officer_requires_auth(self):
        status, body = _request("POST", "/v1/buddy/officers", payload={"name": "X"})
        self.assertEqual(status, 401)

    def test_create_buddy_officer_requires_name(self):
        status, body = _request("POST", "/v1/buddy/officers", payload={},
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 422)

    def test_create_and_list_buddy_officers(self):
        officer_id = self._create_officer(name="Officer List Test")
        status, body = _request("GET", "/v1/buddy/officers", headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 200)
        self.assertTrue(any(o["id"] == officer_id for o in body["officers"]))

    def test_assign_requires_auth(self):
        status, body = _request("POST", "/v1/buddy/assign", payload={"workerIdHash": "w", "buddyOfficerId": "x"})
        self.assertEqual(status, 401)

    def test_assign_requires_fields(self):
        status, body = _request("POST", "/v1/buddy/assign", payload={}, headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 422)

    def test_assign_rejects_unknown_officer(self):
        status, body = _request("POST", "/v1/buddy/assign",
                                 payload={"workerIdHash": "w-assign-01", "buddyOfficerId": "does-not-exist"},
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 404)

    def test_assign_success_and_worker_appears_in_officer_list(self):
        officer_id = self._create_officer()
        worker = "buddy-worker-001"
        status, body = _request("POST", "/v1/buddy/assign",
                                 payload={"workerIdHash": worker, "buddyOfficerId": officer_id},
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 201)

        status, body = _request("GET", f"/v1/buddy/workers?buddyOfficerId={officer_id}",
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 200)
        self.assertTrue(any(w["workerIdHash"] == worker for w in body["workers"]))
        entry = next(w for w in body["workers"] if w["workerIdHash"] == worker)
        self.assertEqual(entry["status"], "no_data")  # لا نبضة عافية بعد

    def test_reassignment_deactivates_previous_assignment(self):
        officer_a = self._create_officer(name="Officer A")
        officer_b = self._create_officer(name="Officer B")
        worker = "buddy-worker-reassign-01"

        _request("POST", "/v1/buddy/assign", payload={"workerIdHash": worker, "buddyOfficerId": officer_a},
                  headers={"X-API-Key": API_KEY})
        _request("POST", "/v1/buddy/assign", payload={"workerIdHash": worker, "buddyOfficerId": officer_b},
                  headers={"X-API-Key": API_KEY})

        status, body_a = _request("GET", f"/v1/buddy/workers?buddyOfficerId={officer_a}",
                                   headers={"X-API-Key": API_KEY})
        status, body_b = _request("GET", f"/v1/buddy/workers?buddyOfficerId={officer_b}",
                                   headers={"X-API-Key": API_KEY})
        self.assertFalse(any(w["workerIdHash"] == worker for w in body_a["workers"]))
        self.assertTrue(any(w["workerIdHash"] == worker for w in body_b["workers"]))

    # ---------------- Buddy System : المتابعة ----------------

    def test_buddy_workers_requires_auth(self):
        status, body = _request("GET", "/v1/buddy/workers?buddyOfficerId=x")
        self.assertEqual(status, 401)

    def test_buddy_workers_requires_officer_id(self):
        status, body = _request("GET", "/v1/buddy/workers", headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 422)

    def test_buddy_workers_unknown_officer_404(self):
        status, body = _request("GET", "/v1/buddy/workers?buddyOfficerId=nope", headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 404)

    def test_buddy_workers_reflects_real_bprs_status_and_top_risks(self):
        officer_id = self._create_officer()
        worker = "buddy-worker-status-01"
        _request("POST", "/v1/buddy/assign", payload={"workerIdHash": worker, "buddyOfficerId": officer_id},
                  headers={"X-API-Key": API_KEY})
        payload = dict(self.FULL_CHECKIN_CRITICAL, workerIdHash=worker, createdAt=now_iso())
        _request("POST", "/v1/checkins/full", payload=payload, headers={"X-API-Key": API_KEY})

        status, body = _request("GET", f"/v1/buddy/workers?buddyOfficerId={officer_id}",
                                 headers={"X-API-Key": API_KEY})
        entry = next(w for w in body["workers"] if w["workerIdHash"] == worker)
        self.assertEqual(entry["status"], "ok")
        self.assertEqual(entry["bprs"]["level"], "red")
        self.assertEqual(len(entry["topRisks"]), 3)

    def test_buddy_workers_level_filter(self):
        officer_id = self._create_officer()
        healthy_worker, critical_worker = "buddy-filter-healthy", "buddy-filter-critical"
        for w in (healthy_worker, critical_worker):
            _request("POST", "/v1/buddy/assign", payload={"workerIdHash": w, "buddyOfficerId": officer_id},
                      headers={"X-API-Key": API_KEY})
        _request("POST", "/v1/checkins/full",
                  payload=dict(self.FULL_CHECKIN_HEALTHY, workerIdHash=healthy_worker, createdAt=now_iso()),
                  headers={"X-API-Key": API_KEY})
        _request("POST", "/v1/checkins/full",
                  payload=dict(self.FULL_CHECKIN_CRITICAL, workerIdHash=critical_worker, createdAt=now_iso()),
                  headers={"X-API-Key": API_KEY})

        status, body = _request("GET", f"/v1/buddy/workers?buddyOfficerId={officer_id}&level=red",
                                 headers={"X-API-Key": API_KEY})
        worker_hashes = [w["workerIdHash"] for w in body["workers"]]
        self.assertIn(critical_worker, worker_hashes)
        self.assertNotIn(healthy_worker, worker_hashes)

    def test_buddy_workers_invalid_level_filter(self):
        officer_id = self._create_officer()
        status, body = _request("GET", f"/v1/buddy/workers?buddyOfficerId={officer_id}&level=purple",
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 422)

    # ---------------- Buddy System : التدخلات ----------------

    def test_intervention_requires_fields(self):
        status, body = _request("POST", "/v1/buddy/intervention", payload={}, headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 422)

    def test_intervention_rejects_worker_not_assigned_to_this_officer(self):
        officer_id = self._create_officer()
        status, body = _request("POST", "/v1/buddy/intervention", payload={
            "workerIdHash": "never-assigned-worker", "buddyOfficerId": officer_id,
            "interventionType": "محادثة", "createdAt": now_iso(),
        }, headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 409)

    def test_intervention_success_and_appears_in_worker_timeline(self):
        officer_id = self._create_officer(name="Officer Intervention Test")
        worker = "buddy-worker-intervention-01"
        _request("POST", "/v1/buddy/assign", payload={"workerIdHash": worker, "buddyOfficerId": officer_id},
                  headers={"X-API-Key": API_KEY})
        _request("POST", "/v1/checkins/full",
                  payload=dict(self.FULL_CHECKIN_CRITICAL, workerIdHash=worker, createdAt=now_iso()),
                  headers={"X-API-Key": API_KEY})

        status, body = _request("POST", "/v1/buddy/intervention", payload={
            "workerIdHash": worker, "buddyOfficerId": officer_id,
            "interventionType": "محادثة وجاهية عاجلة", "notes": "تمت الإحالة لأخصائي نفسي",
            "createdAt": now_iso(),
        }, headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 201)

        status, body = _request("GET", f"/v1/workers/timeline?workerIdHash={worker}",
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(len(body["interventions"]), 1)
        self.assertEqual(body["interventions"][0]["intervention_type"], "محادثة وجاهية عاجلة")
        self.assertEqual(body["interventions"][0]["officer_name"], "Officer Intervention Test")

    # ---------------- Buddy System : الإشعارات عند التصعيد ----------------

    def test_notification_created_on_escalation_for_assigned_worker(self):
        officer_id = self._create_officer(name="Officer Notif Test")
        worker = "buddy-worker-escalate-01"
        _request("POST", "/v1/buddy/assign", payload={"workerIdHash": worker, "buddyOfficerId": officer_id},
                  headers={"X-API-Key": API_KEY})

        status, body1 = _request("POST", "/v1/checkins/full",
                                  payload=dict(self.FULL_CHECKIN_HEALTHY, workerIdHash=worker, createdAt=now_iso()),
                                  headers={"X-API-Key": API_KEY})
        self.assertFalse(body1["buddyNotificationCreated"])  # لا مستوى سابق للمقارنة

        status, body2 = _request("POST", "/v1/checkins/full",
                                  payload=dict(self.FULL_CHECKIN_CRITICAL, workerIdHash=worker, createdAt=now_iso()),
                                  headers={"X-API-Key": API_KEY})
        self.assertTrue(body2["buddyNotificationCreated"])  # أخضر → أحمر = تصعيد

        status, body = _request("GET", f"/v1/buddy/notifications?buddyOfficerId={officer_id}",
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 200)
        matching = [n for n in body["notifications"] if n["worker_id_hash"] == worker]
        self.assertEqual(len(matching), 1)
        self.assertEqual(matching[0]["previous_level"], "green")
        self.assertEqual(matching[0]["new_level"], "red")

    def test_no_notification_when_no_active_assignment(self):
        worker = "buddy-worker-unassigned-escalate-01"
        _request("POST", "/v1/checkins/full",
                  payload=dict(self.FULL_CHECKIN_HEALTHY, workerIdHash=worker, createdAt=now_iso()),
                  headers={"X-API-Key": API_KEY})
        status, body = _request("POST", "/v1/checkins/full",
                                 payload=dict(self.FULL_CHECKIN_CRITICAL, workerIdHash=worker, createdAt=now_iso()),
                                 headers={"X-API-Key": API_KEY})
        self.assertFalse(body["buddyNotificationCreated"])

    def test_no_notification_when_level_improves_or_stable(self):
        officer_id = self._create_officer()
        worker = "buddy-worker-improve-01"
        _request("POST", "/v1/buddy/assign", payload={"workerIdHash": worker, "buddyOfficerId": officer_id},
                  headers={"X-API-Key": API_KEY})
        _request("POST", "/v1/checkins/full",
                  payload=dict(self.FULL_CHECKIN_CRITICAL, workerIdHash=worker, createdAt=now_iso()),
                  headers={"X-API-Key": API_KEY})
        status, body = _request("POST", "/v1/checkins/full",
                                 payload=dict(self.FULL_CHECKIN_HEALTHY, workerIdHash=worker, createdAt=now_iso()),
                                 headers={"X-API-Key": API_KEY})
        self.assertFalse(body["buddyNotificationCreated"])  # أحمر → أخضر = تحسّن، لا إشعار

    # ---------------- Timeline: مؤشر التحسّن + Buddy Officer ----------------

    def test_timeline_includes_buddy_officer_when_assigned(self):
        officer_id = self._create_officer(name="Officer Timeline Test")
        worker = "buddy-worker-timeline-officer-01"
        _request("POST", "/v1/buddy/assign", payload={"workerIdHash": worker, "buddyOfficerId": officer_id},
                  headers={"X-API-Key": API_KEY})
        status, body = _request("GET", f"/v1/workers/timeline?workerIdHash={worker}",
                                 headers={"X-API-Key": API_KEY})
        self.assertIsNotNone(body["buddyOfficer"])
        self.assertEqual(body["buddyOfficer"]["id"], officer_id)
        self.assertEqual(body["buddyOfficer"]["name"], "Officer Timeline Test")

    def test_timeline_buddy_officer_is_null_when_unassigned(self):
        status, body = _request("GET", "/v1/workers/timeline?workerIdHash=never-assigned-timeline-01",
                                 headers={"X-API-Key": API_KEY})
        self.assertIsNone(body["buddyOfficer"])

    def test_timeline_improvement_trend_detects_worsening(self):
        worker = "buddy-worker-trend-worsening-01"
        for _ in range(2):
            _request("POST", "/v1/checkins/full",
                      payload=dict(self.FULL_CHECKIN_HEALTHY, workerIdHash=worker, createdAt=now_iso()),
                      headers={"X-API-Key": API_KEY})
        for _ in range(2):
            _request("POST", "/v1/checkins/full",
                      payload=dict(self.FULL_CHECKIN_CRITICAL, workerIdHash=worker, createdAt=now_iso()),
                      headers={"X-API-Key": API_KEY})
        status, body = _request("GET", f"/v1/workers/timeline?workerIdHash={worker}",
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(body["improvementTrend"], "worsening")

    def test_timeline_improvement_trend_none_for_single_checkin(self):
        worker = "buddy-worker-trend-single-01"
        _request("POST", "/v1/checkins/full",
                  payload=dict(self.FULL_CHECKIN_HEALTHY, workerIdHash=worker, createdAt=now_iso()),
                  headers={"X-API-Key": API_KEY})
        status, body = _request("GET", f"/v1/workers/timeline?workerIdHash={worker}",
                                 headers={"X-API-Key": API_KEY})
        self.assertIsNone(body["improvementTrend"])

    def test_buddy_endpoints_isolated_between_tenants(self):
        officer_id = self._create_officer(name="Tenant A Officer")
        status, body = _request("GET", "/v1/buddy/officers", headers={"X-API-Key": API_KEY_TENANT_B})
        self.assertFalse(any(o["id"] == officer_id for o in body["officers"]))

        status, body = _request("GET", f"/v1/buddy/workers?buddyOfficerId={officer_id}",
                                 headers={"X-API-Key": API_KEY_TENANT_B})
        self.assertEqual(status, 404)  # الضابط غير موجود من منظور تينانت آخر

    # ---------------- Buddy System : صلاحيات دخول شخصية آمنة لـBuddy Officer ----------------

    def test_create_officer_with_username_requires_password(self):
        status, body = _request("POST", "/v1/buddy/officers",
                                 payload={"name": "بلا كلمة مرور", "username": "orphan_user"},
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 422)
        self.assertEqual(body["error"], "password_required_with_username")

    def test_create_officer_without_username_has_no_login_credentials(self):
        status, body = _request("POST", "/v1/buddy/officers",
                                 payload={"name": "بلا حساب شخصي"},
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 201)
        self.assertFalse(body["hasLoginCredentials"])

    def test_create_officer_with_username_reports_has_login_credentials(self):
        status, body = _request("POST", "/v1/buddy/officers",
                                 payload={"name": "له حساب شخصي", "username": "officer_creds_flag",
                                          "password": "Str0ngP@ss!"},
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 201)
        self.assertTrue(body["hasLoginCredentials"])

    def test_duplicate_username_within_same_tenant_rejected(self):
        self._create_officer(name="Officer One", username="dup_username_01", password="pass1234")
        status, body = _request("POST", "/v1/buddy/officers",
                                 payload={"name": "Officer Two", "username": "dup_username_01", "password": "other"},
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 409)
        self.assertEqual(body["error"], "username_already_taken")

    def test_same_username_allowed_across_different_tenants(self):
        self._create_officer(name="Tenant A Officer", username="shared_username_01", password="pass1234")
        status, body = _request("POST", "/v1/buddy/officers",
                                 payload={"name": "Tenant B Officer", "username": "shared_username_01",
                                          "password": "otherpass"},
                                 headers={"X-API-Key": API_KEY_TENANT_B})
        self.assertEqual(status, 201)  # لا تعارض — نفس اسم المستخدم في تينانت مختلف

    def test_buddy_login_requires_auth(self):
        status, body = _request("POST", "/v1/auth/buddy/login", payload={"username": "x", "password": "y"})
        self.assertEqual(status, 401)

    def test_buddy_login_requires_fields(self):
        status, body = _request("POST", "/v1/auth/buddy/login", payload={}, headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 422)

    def test_buddy_login_wrong_password_rejected(self):
        self._create_officer(name="Login Test Officer", username="login_wrong_pw", password="correct123")
        status, body = _request("POST", "/v1/auth/buddy/login",
                                 payload={"username": "login_wrong_pw", "password": "wrong"},
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 401)
        self.assertEqual(body["error"], "invalid_credentials")

    def test_buddy_login_unknown_username_rejected(self):
        status, body = _request("POST", "/v1/auth/buddy/login",
                                 payload={"username": "never-registered-buddy", "password": "whatever"},
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 401)

    def test_buddy_login_officer_without_credentials_rejected(self):
        # ضابط مُسجَّل بلا username/password إطلاقاً — لا يمكن الدخول أبداً
        self._create_officer(name="No Creds Officer")
        status, body = _request("POST", "/v1/auth/buddy/login",
                                 payload={"username": "", "password": "anything"},
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 401)

    def test_buddy_login_success_returns_token(self):
        officer_id = self._create_officer(name="Successful Login Officer",
                                           username="login_success_01", password="correct123")
        status, body = _request("POST", "/v1/auth/buddy/login",
                                 payload={"username": "login_success_01", "password": "correct123"},
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 200)
        self.assertEqual(body["buddyOfficerId"], officer_id)
        self.assertIn("token", body)
        self.assertTrue(len(body["token"]) > 10)

    def test_buddy_login_rate_limited_after_repeated_failures(self):
        self._create_officer(name="Rate Limited Officer", username="rate_limited_01", password="correct123")
        for _ in range(5):
            _request("POST", "/v1/auth/buddy/login",
                      payload={"username": "rate_limited_01", "password": "wrong"},
                      headers={"X-API-Key": API_KEY})
        status, body = _request("POST", "/v1/auth/buddy/login",
                                 payload={"username": "rate_limited_01", "password": "correct123"},
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 429)
        self.assertEqual(body["error"], "too_many_attempts")

    def test_buddy_login_namespace_does_not_collide_with_worker_employee_id(self):
        # عامل بمعرّف وظيفي "shared_id_01" وضابط باسم مستخدم "shared_id_01"
        # في نفس التينانت — يجب ألا يتشارك عداد محاولات تسجيل الدخول
        tenant_id = self._get_sonatrach_tenant_id()
        create_worker_status, _ = _request("POST", "/v1/admin/workers",
                                            payload={"tenantId": tenant_id, "employeeId": "shared_id_01", "pin": "1234"},
                                            headers={"X-Admin-Key": "founder-admin-key-2026"})
        self._create_officer(name="Namespace Test Officer", username="shared_id_01", password="correct123")

        for _ in range(5):
            _request("POST", "/v1/auth/worker/login",
                      payload={"employeeId": "shared_id_01", "pin": "0000"},
                      headers={"X-API-Key": API_KEY})

        # محاولات فاشلة على حساب العامل لا يجب أن تُقفل حساب الضابط بنفس الاسم
        status, body = _request("POST", "/v1/auth/buddy/login",
                                 payload={"username": "shared_id_01", "password": "correct123"},
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 200)

    def test_buddy_token_allows_access_to_own_data(self):
        officer_id = self._create_officer(name="Own Data Officer", username="own_data_01", password="pass123")
        worker = "buddy-token-own-data-worker"
        _request("POST", "/v1/buddy/assign", payload={"workerIdHash": worker, "buddyOfficerId": officer_id},
                  headers={"X-API-Key": API_KEY})

        status, login_body = _request("POST", "/v1/auth/buddy/login",
                                       payload={"username": "own_data_01", "password": "pass123"},
                                       headers={"X-API-Key": API_KEY})
        token = login_body["token"]

        status, body = _request("GET", f"/v1/buddy/workers?buddyOfficerId={officer_id}",
                                 headers={"X-API-Key": API_KEY, "X-Buddy-Token": token})
        self.assertEqual(status, 200)
        self.assertTrue(any(w["workerIdHash"] == worker for w in body["workers"]))

    def test_buddy_token_rejects_access_to_other_officer_data(self):
        officer_a = self._create_officer(name="Officer A Scoped", username="scoped_a_01", password="passA123")
        officer_b = self._create_officer(name="Officer B Scoped", username="scoped_b_01", password="passB123")

        status, login_body = _request("POST", "/v1/auth/buddy/login",
                                       payload={"username": "scoped_a_01", "password": "passA123"},
                                       headers={"X-API-Key": API_KEY})
        token_a = login_body["token"]

        # توكن الضابط A يحاول الوصول لبيانات الضابط B — يجب الرفض
        status, body = _request("GET", f"/v1/buddy/workers?buddyOfficerId={officer_b}",
                                 headers={"X-API-Key": API_KEY, "X-Buddy-Token": token_a})
        self.assertEqual(status, 403)
        self.assertEqual(body["error"], "buddy_token_scope_mismatch")

    def test_buddy_token_scoping_applies_to_notifications_endpoint(self):
        officer_a = self._create_officer(name="Notif Scoped A", username="notif_scoped_a", password="passA123")
        officer_b = self._create_officer(name="Notif Scoped B", username="notif_scoped_b", password="passB123")
        status, login_body = _request("POST", "/v1/auth/buddy/login",
                                       payload={"username": "notif_scoped_a", "password": "passA123"},
                                       headers={"X-API-Key": API_KEY})
        token_a = login_body["token"]

        status, body = _request("GET", f"/v1/buddy/notifications?buddyOfficerId={officer_b}",
                                 headers={"X-API-Key": API_KEY, "X-Buddy-Token": token_a})
        self.assertEqual(status, 403)

    def test_buddy_token_scoping_applies_to_intervention_endpoint(self):
        officer_a = self._create_officer(name="Interv Scoped A", username="interv_scoped_a", password="passA123")
        officer_b = self._create_officer(name="Interv Scoped B", username="interv_scoped_b", password="passB123")
        worker = "buddy-token-interv-scope-worker"
        _request("POST", "/v1/buddy/assign", payload={"workerIdHash": worker, "buddyOfficerId": officer_b},
                  headers={"X-API-Key": API_KEY})

        status, login_body = _request("POST", "/v1/auth/buddy/login",
                                       payload={"username": "interv_scoped_a", "password": "passA123"},
                                       headers={"X-API-Key": API_KEY})
        token_a = login_body["token"]

        # الضابط A (متوكَّن) يحاول تسجيل تدخل باسم الضابط B — يجب الرفض
        # حتى لو كان B فعلاً هو المعيَّن للعامل (السلامة المرجعية وحدها
        # غير كافية هنا؛ نطاق التوكن يُرفَض أولاً).
        status, body = _request("POST", "/v1/buddy/intervention", payload={
            "workerIdHash": worker, "buddyOfficerId": officer_b,
            "interventionType": "محاولة انتحال", "createdAt": now_iso(),
        }, headers={"X-API-Key": API_KEY, "X-Buddy-Token": token_a})
        self.assertEqual(status, 403)
        self.assertEqual(body["error"], "buddy_token_scope_mismatch")

    def test_invalid_buddy_token_rejected(self):
        officer_id = self._create_officer(name="Invalid Token Officer")
        status, body = _request("GET", f"/v1/buddy/workers?buddyOfficerId={officer_id}",
                                 headers={"X-API-Key": API_KEY, "X-Buddy-Token": "not-a-real-token"})
        self.assertEqual(status, 401)
        self.assertEqual(body["error"], "invalid_or_expired_buddy_token")

    def test_buddy_token_cross_tenant_rejected(self):
        officer_id = self._create_officer(name="Cross Tenant Token Officer",
                                           username="cross_tenant_officer", password="pass123")
        status, login_body = _request("POST", "/v1/auth/buddy/login",
                                       payload={"username": "cross_tenant_officer", "password": "pass123"},
                                       headers={"X-API-Key": API_KEY})
        token = login_body["token"]

        # نفس التوكن، لكن يُستخدَم مع مفتاح API لتينانت آخر تماماً
        status, body = _request("GET", f"/v1/buddy/workers?buddyOfficerId={officer_id}",
                                 headers={"X-API-Key": API_KEY_TENANT_B, "X-Buddy-Token": token})
        self.assertIn(status, (403, 404))  # الضابط أصلاً غير موجود من منظور تينانت B، والفحصان كلاهما مقبولان أمنياً

    def test_tenant_key_alone_still_works_without_buddy_token_backward_compat(self):
        # توافق خلفي: HSE يستخدم مفتاح التينانت وحده (بلا X-Buddy-Token)
        # ويرى أي ضابط — تماماً كسلوك الجولات السابقة، لم يُكسَر شيء.
        officer_id = self._create_officer(name="Backward Compat Officer")
        status, body = _request("GET", f"/v1/buddy/workers?buddyOfficerId={officer_id}",
                                 headers={"X-API-Key": API_KEY})
        self.assertEqual(status, 200)


if __name__ == "__main__":
    unittest.main(verbosity=2)
