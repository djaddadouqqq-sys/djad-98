"""
tests/test_e2e_full_system.py

اختبار E2E واحد متصل يعبر النظام بالكامل من البداية إلى النهاية، بدل
اختبارات منفصلة لكل نقطة نهاية (تلك موجودة في test_api.py وتبقى كما
هي). هذا الملف يحاكي **سيناريو حقيقي واحد متكامل**، تماماً كما يحدث
فعلياً في الاستخدام الميداني:

  عامل يُدخل بياناته (Check-in) → الخادم يحسب BPRS →
  يحدَّد المخاطر النفسية-الاجتماعية الثمانية → يُحسب محرك الإرهاق →
  يُحدَّد اللون (أخضر/أصفر/برتقالي/أحمر) → إن تصعَّد المستوى وله Buddy
  Officer نشط، يُنشأ إشعار تلقائياً → التدخل المناسب يُعرض ويُسجَّل من
  طرف Buddy Officer → النتيجة تُحفظ وتُقارَن عبر الزمن (Timeline +
  مؤشر التحسّن) → تظهر البيانات للوحة HSE المخوَّلة (dashboard/risks،
  dashboard/fatigue، buddy/workers).

⚠️ نطاق صادق: هذا اختبار Backend-to-Backend حقيقي (خادم HTTP فعلي، طلبات
حقيقية عبر urllib، قاعدة بيانات SQLite حقيقية) يعبر DB→API→محركات
الحساب→التجميع→نقاط نهاية HSE/Buddy معاً في سيناريو واحد متصل. هو **لا**
يشغّل PWA أو Flutter أو متصفحاً فعلياً — التحقق من تلك الطبقات موثَّق
بشكل منفصل بلقطات شاشة حقيقية عبر Playwright (انظر MASTER_README.md
§4.2)، وليس جزءاً من هذا الملف الآلي.
"""

import json
import os
import sys
import threading
import time
import unittest
import urllib.request
import urllib.error
from datetime import datetime, timezone, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import db
from app.server import create_server

TEST_PORT = 8744
BASE_URL = f"http://127.0.0.1:{TEST_PORT}"
API_KEY = "pilot-demo-key-2026"


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def _request(method, path, payload=None, headers=None):
    url = BASE_URL + path
    data = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode())


class TestFullSystemE2E(unittest.TestCase):
    """سيناريو واحد متصل، لا اختبارات ذرّية معزولة — كل خطوة تعتمد على
    نتيجة الخطوة التي قبلها، تماماً كما يحدث في الاستخدام الحقيقي."""

    @classmethod
    def setUpClass(cls):
        os.environ["BUDDY_DB_PATH"] = "test_e2e_full_system.db"
        db.reset_db_for_tests()
        cls.server = create_server(host="127.0.0.1", port=TEST_PORT)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        time.sleep(0.3)

        # تينانت ثانٍ لإثبات العزل الكامل بين العملاء في الخطوة 8 —
        # نفس أسلوب test_api.py بالضبط (pilot-demo-key-2026 يُزرَع
        # تلقائياً في init_db()، أما هذا الثاني فيدوي هنا فقط).
        import uuid
        conn = db.get_connection()
        conn.execute(
            "INSERT INTO tenants (id, name, api_key, rotation_cycle_days, created_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (str(uuid.uuid4()), "Schlumberger — Démo", "tenant-b-schlumberger-demo-key", 14,
             datetime.now(timezone.utc).isoformat()),
        )
        conn.commit()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.thread.join(timeout=2)
        for suffix in ("", "-wal", "-shm"):
            path = "test_e2e_full_system.db" + suffix
            if os.path.exists(path):
                os.remove(path)

    def test_full_worker_journey_from_checkin_to_hse_visibility(self):
        headers = {"X-API-Key": API_KEY}
        worker = "e2e-full-journey-worker"
        site = "E2E-FULL-SITE"

        # ============================================================
        # الخطوة 0 — HSE يُسجّل Buddy Officer ويعيّنه للعامل *قبل* أي
        # نبضة عافية (السيناريو الواقعي: التعيين يسبق أول حالة تصعيد)
        # ============================================================
        status, officer = _request("POST", "/v1/buddy/officers",
                                    {"name": "أمينة قدور", "contactInfo": "amina@example.dz"}, headers)
        self.assertEqual(status, 201, "فشل تسجيل Buddy Officer")
        officer_id = officer["id"]

        status, assignment = _request("POST", "/v1/buddy/assign",
                                       {"workerIdHash": worker, "buddyOfficerId": officer_id}, headers)
        self.assertEqual(status, 201, "فشل التعيين")

        # ============================================================
        # الخطوة 1 — عامل يُدخل بياناته (نبضة عافية سليمة، اليوم 5 من
        # الدورة) → الخادم يحسب BPRS + المخاطر الثمانية + الإرهاق
        # ============================================================
        healthy_payload = {
            "workerIdHash": worker, "createdAt": now_iso(), "siteCode": site,
            "physicalFatigue": 2, "mentalFatigue": 2, "sleepDisruption": 2,
            "lowEmpowerment": 2, "lowResilience": 2, "isolation": 2,
            "dayInRotationCycle": 5, "daysSinceLastCheckin": 0,
            "hoursWorkedLast24h": 8, "isNightShift": False, "distanceFromFamilyKm": 200,
            "sleepHoursLast24h": 7.5,
        }
        status, result1 = _request("POST", "/v1/checkins/full", healthy_payload, headers)
        self.assertEqual(status, 201, "فشل حفظ نبضة العافية الأولى")
        self.assertEqual(result1["bprs"]["level"], "green", "الحالة السليمة يجب أن تُصنَّف أخضر")
        self.assertEqual(len(result1["risks"]), 8, "يجب حساب المخاطر الثمانية كاملة")
        self.assertIn("fatigue", result1, "يجب أن يتضمن الرد بلوك الإرهاق")
        self.assertFalse(result1["urgent"], "لا تدخل عاجل مطلوب لحالة سليمة")
        self.assertFalse(result1["buddyNotificationCreated"], "لا إشعار عند أول نبضة (لا مستوى سابق للمقارنة)")

        # ============================================================
        # الخطوة 2 — الحالة تتدهور بشدة (اليوم 27، إرهاق حاد، مناوبة
        # ليلية) → BPRS يقفز للأحمر → إشعار Buddy Officer تلقائياً
        # ============================================================
        critical_payload = {
            "workerIdHash": worker, "createdAt": now_iso(), "siteCode": site,
            "physicalFatigue": 9, "mentalFatigue": 9, "sleepDisruption": 9,
            "lowEmpowerment": 8, "lowResilience": 9, "isolation": 9,
            "dayInRotationCycle": 27, "daysSinceLastCheckin": 5,
            "hoursWorkedLast24h": 14, "isNightShift": True, "distanceFromFamilyKm": 900,
            "sleepHoursLast24h": 2,
        }
        status, result2 = _request("POST", "/v1/checkins/full", critical_payload, headers)
        self.assertEqual(status, 201, "فشل حفظ نبضة العافية الحرجة")
        self.assertEqual(result2["bprs"]["level"], "red", "الحالة الحرجة يجب أن تُصنَّف أحمر")
        self.assertTrue(result2["urgent"], "يجب تفعيل التدخل العاجل عند الأحمر")
        self.assertTrue(len(result2["urgentActions"]) > 0, "يجب توفر إجراءات عاجلة فعلية")
        self.assertTrue(any("SOS" in a for a in result2["urgentActions"]), "يجب ذكر بروتوكول SOS صراحة")
        self.assertEqual(result2["fatigue"]["level"], "red", "محرك الإرهاق المستقل يجب أن يُصنِّف هذه الحالة أحمر أيضاً")
        self.assertTrue(result2["buddyNotificationCreated"],
                         "التصعيد أخضر→أحمر لعامل معيَّن يجب أن يُنشئ إشعاراً تلقائياً")

        # ============================================================
        # الخطوة 3 — Buddy Officer يفتح لوحته، يرى الإشعار والعامل ضمن
        # قائمة عماله بالحالة الصحيحة (لا حالة مُختلَقة، من البيانات
        # الفعلية المخزَّنة في الخطوة السابقة)
        # ============================================================
        status, notifications = _request("GET", f"/v1/buddy/notifications?buddyOfficerId={officer_id}", headers=headers)
        self.assertEqual(status, 200)
        matching_notif = [n for n in notifications["notifications"] if n["worker_id_hash"] == worker]
        self.assertEqual(len(matching_notif), 1, "يجب وجود إشعار تصعيد واحد بالضبط لهذا العامل")
        self.assertEqual(matching_notif[0]["previous_level"], "green")
        self.assertEqual(matching_notif[0]["new_level"], "red")

        status, officer_workers = _request("GET", f"/v1/buddy/workers?buddyOfficerId={officer_id}", headers=headers)
        self.assertEqual(status, 200)
        entry = next(w for w in officer_workers["workers"] if w["workerIdHash"] == worker)
        self.assertEqual(entry["status"], "ok")
        self.assertEqual(entry["bprs"]["level"], "red")
        self.assertEqual(entry["bprs"]["score"], result2["bprs"]["score"], "الدرجة المعروضة للضابط يجب أن تطابق ما حُسِب فعلياً")
        self.assertTrue(len(entry["topRisks"]) > 0)

        # فلترة حسب المستوى — عامل واحد أحمر يجب أن يظهر مع فلتر red
        status, filtered = _request("GET", f"/v1/buddy/workers?buddyOfficerId={officer_id}&level=red", headers=headers)
        self.assertIn(worker, [w["workerIdHash"] for w in filtered["workers"]])
        status, filtered_green = _request("GET", f"/v1/buddy/workers?buddyOfficerId={officer_id}&level=green", headers=headers)
        self.assertNotIn(worker, [w["workerIdHash"] for w in filtered_green["workers"]])

        # ============================================================
        # الخطوة 4 — Buddy Officer يسجّل تدخلاً عاجلاً فعلياً
        # ============================================================
        status, intervention = _request("POST", "/v1/buddy/intervention", {
            "workerIdHash": worker, "buddyOfficerId": officer_id,
            "interventionType": "تدخل SOS عاجل", "notes": "تم التواصل الفوري وإحالة العامل للأخصائي النفسي بالموقع.",
            "createdAt": now_iso(),
        }, headers)
        self.assertEqual(status, 201, "فشل تسجيل التدخل")

        # ============================================================
        # الخطوة 5 — العامل نفسه يتعافى تدريجياً (نبضة عافية سليمة
        # لاحقة) → لا إشعار جديد لأن الاتجاه تحسّن لا تصعيد
        # ============================================================
        recovery_payload = dict(healthy_payload, createdAt=now_iso(), dayInRotationCycle=2)
        status, result3 = _request("POST", "/v1/checkins/full", recovery_payload, headers)
        self.assertEqual(status, 201)
        self.assertEqual(result3["bprs"]["level"], "green")
        self.assertFalse(result3["buddyNotificationCreated"], "التحسّن (أحمر→أخضر) لا يجب أن يُنشئ إشعار تصعيد")

        # ============================================================
        # الخطوة 6 — Timeline العامل يعكس السلسلة الكاملة: 3 نبضات،
        # بروفايل Buddy Officer، التدخل المسجَّل، ومؤشر التحسّن
        # ============================================================
        status, timeline = _request("GET", f"/v1/workers/timeline?workerIdHash={worker}", headers=headers)
        self.assertEqual(status, 200)
        self.assertEqual(timeline["count"], 3, "يجب ظهور النبضات الثلاث كاملة بالترتيب الزمني")
        self.assertIsNotNone(timeline["buddyOfficer"])
        self.assertEqual(timeline["buddyOfficer"]["id"], officer_id)
        self.assertEqual(len(timeline["interventions"]), 1)
        self.assertEqual(timeline["interventions"][0]["intervention_type"], "تدخل SOS عاجل")
        self.assertEqual(timeline["improvementTrend"], "improving",
                          "أحدث نبضتين سليمتين مقابل الأقدم الحرجة يجب أن تُصنَّف 'تتحسّن'")

        # ============================================================
        # الخطوة 7 — البيانات تظهر فعلياً في لوحات HSE (لا اختلاق):
        # dashboard/risks، dashboard/fatigue، dashboard/summary،
        # dashboard/risk-trend — كلها من نفس البيانات المحفوظة أعلاه
        # ============================================================
        status, risks_board = _request("GET", f"/v1/dashboard/risks?site_code={site}", headers=headers)
        self.assertEqual(status, 200)
        self.assertEqual(len(risks_board["risks"]), 8)
        # كانت هناك لحظة حمراء ضمن الفترة، لذا يجب أن تسجّلها لوحة HSE
        burnout = next(r for r in risks_board["risks"] if r["id"] == "burnout")
        self.assertEqual(burnout["status"], "ok")

        status, fatigue_board = _request("GET", f"/v1/dashboard/fatigue?site_code={site}", headers=headers)
        self.assertEqual(status, 200)
        self.assertEqual(fatigue_board["status"], "ok")
        self.assertEqual(fatigue_board["sample_size"], 3)
        self.assertGreaterEqual(fatigue_board["distribution"]["red"], 1)
        self.assertGreaterEqual(fatigue_board["distribution"]["green"], 1)

        status, summary = _request("GET", "/v1/dashboard/summary", headers=headers)
        self.assertEqual(status, 200)
        self.assertGreaterEqual(summary["total_checkins"], 3)

        status, trend = _request("GET", "/v1/dashboard/risk-trend?risk_id=burnout&weeks=2", headers=headers)
        self.assertEqual(status, 200)
        self.assertEqual(len(trend["trend"]), 2)

        # ============================================================
        # الخطوة 8 — سلامة العزل: تينانت آخر لا يرى أياً من هذا إطلاقاً
        # (لا العامل، لا الضابط، لا الإشعارات، لا البيانات المُجمَّعة)
        # ============================================================
        tenant_b_headers = {"X-API-Key": "tenant-b-schlumberger-demo-key"}
        status, foreign_officers = _request("GET", "/v1/buddy/officers", headers=tenant_b_headers)
        self.assertFalse(any(o["id"] == officer_id for o in foreign_officers["officers"]))

        status, foreign_workers_lookup = _request("GET", f"/v1/buddy/workers?buddyOfficerId={officer_id}", headers=tenant_b_headers)
        self.assertEqual(status, 404, "الضابط يجب ألا يكون موجوداً من منظور تينانت آخر")

        status, foreign_timeline = _request("GET", f"/v1/workers/timeline?workerIdHash={worker}", headers=tenant_b_headers)
        self.assertEqual(status, 200)
        self.assertEqual(foreign_timeline["count"], 0, "تينانت آخر يجب ألا يرى أي نبضة عافية لهذا العامل")


if __name__ == "__main__":
    unittest.main(verbosity=2)
