"""
app/tokens.py

Jetons de session signés pour l'authentification individuelle des
employés — une alternative légère à JWT, implémentée avec uniquement
`hmac` et `hashlib` (bibliothèque standard), puisque aucun paquet externe
(PyJWT, etc.) n'est installable dans cet environnement sans accès
internet.

Format du jeton : base64url(payload_json) + "." + hmac_sha256_signature
Le payload contient : tenantId, workerIdHash, issuedAt, expiresAt.

AVANT MISE À L'ÉCHELLE : ce format est fonctionnellement équivalent à un
JWT HS256 minimal. Migrer vers PyJWT (ou une bibliothèque standard du
marché) est recommandé pour bénéficier de l'écosystème (rotation de
clés, révocation, bibliothèques clientes existantes) — mais la logique
cryptographique ci-dessous (HMAC-SHA256, comparaison à temps constant)
est déjà correcte et sûre en soi.
"""

import base64
import hashlib
import hmac
import json
import os
import time

_SECRET = os.environ.get("BUDDY_TOKEN_SECRET", "pilot-token-secret-change-in-production-2026")
_DEFAULT_TTL_SECONDS = 12 * 3600  # 12h — couvre une garde/mission type


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _b64url_decode(data: str) -> bytes:
    padding = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + padding)


def _sign(payload_b64: str) -> str:
    sig = hmac.new(_SECRET.encode("utf-8"), payload_b64.encode("utf-8"), hashlib.sha256).digest()
    return _b64url_encode(sig)


def issue_token(tenant_id: str, worker_id_hash: str, ttl_seconds: int = _DEFAULT_TTL_SECONDS) -> str:
    now = int(time.time())
    payload = {
        "tenantId": tenant_id,
        "workerIdHash": worker_id_hash,
        "issuedAt": now,
        "expiresAt": now + ttl_seconds,
    }
    payload_b64 = _b64url_encode(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
    signature = _sign(payload_b64)
    return f"{payload_b64}.{signature}"


def issue_buddy_token(tenant_id: str, buddy_officer_id: str, ttl_seconds: int = _DEFAULT_TTL_SECONDS) -> str:
    """جلسة شخصية لـBuddy Officer — نفس الآلية الأمنية بالضبط (HMAC-SHA256
    موقَّع، صلاحية 12 ساعة افتراضياً)، لكن الحمولة تحمل buddyOfficerId لا
    workerIdHash. verify_token() أدناه عام بما يكفي للتحقق من كلا
    النوعين دون تمييز — الفرق فقط في أي مفتاح يقرأه الطرف المُستدعي من
    الحمولة المُعادة."""
    now = int(time.time())
    payload = {
        "tenantId": tenant_id,
        "buddyOfficerId": buddy_officer_id,
        "issuedAt": now,
        "expiresAt": now + ttl_seconds,
    }
    payload_b64 = _b64url_encode(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
    signature = _sign(payload_b64)
    return f"{payload_b64}.{signature}"


def verify_token(token: str):
    """Renvoie le payload (dict) si le jeton est valide et non expiré,
    sinon None. Toute erreur de format renvoie None plutôt que de lever
    une exception — un jeton invalide ne doit jamais faire planter le
    serveur, seulement échouer l'authentification."""
    if not token or "." not in token:
        return None

    payload_b64, _, signature = token.partition(".")
    expected_signature = _sign(payload_b64)

    if not hmac.compare_digest(signature, expected_signature):
        return None

    try:
        payload = json.loads(_b64url_decode(payload_b64))
    except (ValueError, UnicodeDecodeError):
        return None

    if payload.get("expiresAt", 0) < time.time():
        return None

    return payload
