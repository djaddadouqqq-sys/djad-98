"""
app/aggregates.py

Calcule les indicateurs agrégés destinés au tableau de bord HSE.
Chaque requête est strictement filtrée par tenant_id : un client ne peut
jamais, même par erreur de code ailleurs, voir les statistiques d'un
autre client. C'est le garde-fou central du multi-tenant.
"""

from datetime import datetime, timezone, timedelta
from .db import execute_read, latest_risk_scores, average_risk_scores, weekly_risk_trend
from .psychosocial_risks import RISK_DEFINITIONS, RISK_DEFINITIONS_BY_ID, LEVEL_LABEL_AR
from .bprs_engine import RiskLevel, _classify


def dashboard_summary(tenant_id: str, days: int = 30, site_code: str | None = None):
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()

    query = "SELECT bprs_score, risk_level, created_at FROM checkins WHERE tenant_id = ? AND created_at >= ?"
    params = [tenant_id, since]
    if site_code:
        query += " AND site_code = ?"
        params.append(site_code)

    rows = execute_read(query, tuple(params))

    report_summary = _anonymous_report_summary(tenant_id, since, site_code)

    if not rows:
        return {
            "period_days": days,
            "site_code": site_code,
            "total_checkins": 0,
            "average_bprs_score": None,
            "risk_level_distribution": {"green": 0, "yellow": 0, "orange": 0, "red": 0},
            "red_alert_count": 0,
            "anonymous_reports": report_summary,
        }

    scores = [r["bprs_score"] for r in rows]
    distribution = {"green": 0, "yellow": 0, "orange": 0, "red": 0}
    for r in rows:
        distribution[r["risk_level"]] += 1

    return {
        "period_days": days,
        "site_code": site_code,
        "total_checkins": len(rows),
        "average_bprs_score": round(sum(scores) / len(scores), 2),
        "risk_level_distribution": distribution,
        "red_alert_count": distribution["red"],
        "anonymous_reports": report_summary,
    }


def _anonymous_report_summary(tenant_id: str, since_iso: str, site_code: str | None = None):
    """Compte les signalements anonymes par catégorie — AUCUNE donnée
    individuelle n'est exposée ici, uniquement des totaux, exactement
    comme pour les check-ins. Alimente le KPI 'signalements' de la
    lettre au tableau de bord HSE."""
    query = "SELECT category FROM anonymous_reports WHERE tenant_id = ? AND created_at >= ?"
    params = [tenant_id, since_iso]
    if site_code:
        query += " AND site_code = ?"
        params.append(site_code)

    rows = execute_read(query, tuple(params))
    by_category = {"mobbing": 0, "harassment": 0, "burnout": 0, "other": 0}
    for r in rows:
        by_category[r["category"]] += 1

    return {
        "total": len(rows),
        "by_category": by_category,
    }


def risk_status_summary(tenant_id: str, days: int = 30, site_code: str | None = None):
    """الحالة الحية للمخاطر الثمانية — اللون هنا مُحسَب من آخر بيانات
    فعلية مخزَّنة في checkin_risk_scores، وليس لوناً ثابتاً بالواجهة.
    إن لم يصل أي checkin عبر /v1/checkins/full بعد لهذا التينانت خلال
    الفترة، يُعاد status='no_data' صراحة بدل اختلاق لون افتراضي مطمئن
    أو مقلق بلا أساس."""
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    latest = latest_risk_scores(tenant_id, since, site_code)
    averages = average_risk_scores(tenant_id, since, site_code)

    # إشارة سلوكية حقيقية إضافية لخطر "التنكيد المهني": كثافة البلاغات
    # المجهولة الفعلية من فئة mobbing خلال نفس الفترة — بيانات سلوكية
    # لا تصريحية، تُدمَج مع متوسط الدرجة التصريحية أدناه.
    mobbing_reports = _anonymous_report_summary(tenant_id, since, site_code)["by_category"].get("mobbing", 0)

    risks = []
    for definition in RISK_DEFINITIONS:
        rid = definition.id
        entry = latest.get(rid)
        avg_entry = averages.get(rid)

        if entry is None:
            risks.append({
                "id": rid, "name_ar": definition.name_ar, "icon": definition.icon,
                "status": "no_data",
                "latest_score": None, "latest_level": None, "latest_level_label_ar": None,
                "average_score": None, "sample_size": 0,
                "standard_refs": definition.standard_refs,
                "clinical_caution": definition.clinical_caution,
            })
            continue

        avg_score = avg_entry["avg_score"] if avg_entry else entry["score"]
        blended_note = None
        if rid == "mobbing" and mobbing_reports > 0:
            # ترجيح تحذيري بسيط وشفاف: كل بلاغ mobbing فعلي يرفع مؤشر
            # العرض 3 نقاط (سقف 15) — لا يُعدَّل السجل المخزَّن نفسه،
            # فقط ما يُعرَض في هذا الملخص، ويُوثَّق بوضوح في الاستجابة.
            bump = min(15, mobbing_reports * 3)
            avg_score = min(100.0, avg_score + bump)
            blended_note = (f"تم رفع المؤشر المعروض بمقدار {bump} نقطة بسبب "
                             f"{mobbing_reports} بلاغ/بلاغات mobbing فعلية مسجَّلة في نفس الفترة — "
                             f"البلاغات مجهولة الهوية ولا تُربط بأي عامل بعينه.")

        risks.append({
            "id": rid, "name_ar": definition.name_ar, "icon": definition.icon,
            "status": "ok",
            "latest_score": entry["score"], "latest_level": entry["level"],
            "latest_level_label_ar": LEVEL_LABEL_AR[RiskLevel(entry["level"])],
            "average_score": avg_score,
            "average_level": _classify(avg_score).value,
            "sample_size": avg_entry["n"] if avg_entry else 1,
            "standard_refs": definition.standard_refs,
            "clinical_caution": definition.clinical_caution,
            "blended_note": blended_note,
        })

    any_red = any(r["latest_level"] == "red" for r in risks if r["status"] == "ok")
    return {
        "period_days": days,
        "site_code": site_code,
        "risks": risks,
        "any_red_alert": any_red,
    }


def risk_weekly_trend(tenant_id: str, risk_id: str, weeks: int = 6, site_code: str | None = None):
    result = []
    for i in range(weeks, 0, -1):
        start = datetime.now(timezone.utc) - timedelta(weeks=i)
        end = start + timedelta(weeks=1)
        row = weekly_risk_trend(tenant_id, risk_id, start.isoformat(), end.isoformat(), site_code)
        result.append({
            "week_start": start.date().isoformat(),
            "average_score": round(row["avg_score"], 1) if row["avg_score"] is not None else None,
            "sample_size": row["n"],
        })
    return result


def fatigue_status_summary(tenant_id: str, days: int = 30, site_code: str | None = None):
    """توزيع مستويات الإرهاق (Fatigue Engine) على مستوى التينانت/الموقع
    — لخطوة 'الإرهاق' في Risk Dashboard، منفصل عن المخاطر الثمانية
    النفسية-الاجتماعية عمداً."""
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    query = ("SELECT level, COUNT(*) as n, AVG(score) as avg_score FROM checkin_fatigue_scores "
             "WHERE tenant_id = ? AND created_at >= ?")
    params = [tenant_id, since]
    if site_code:
        query += " AND site_code = ?"
        params.append(site_code)
    query += " GROUP BY level"
    rows = execute_read(query, tuple(params))

    distribution = {lvl: 0 for lvl in ("green", "yellow", "orange", "red")}
    total = 0
    weighted_sum = 0.0
    for r in rows:
        distribution[r["level"]] = r["n"]
        total += r["n"]
        weighted_sum += (r["avg_score"] or 0) * r["n"]

    return {
        "period_days": days, "site_code": site_code,
        "sample_size": total,
        "average_score": round(weighted_sum / total, 1) if total else None,
        "distribution": distribution,
        "status": "ok" if total > 0 else "no_data",
    }


def weekly_trend(tenant_id: str, weeks: int = 6, site_code: str | None = None):
    """Renvoie la moyenne BPRS par semaine — alimente le graphique en
    barres du tableau de bord (voir maquette fournie séparément)."""
    result = []
    for i in range(weeks, 0, -1):
        start = datetime.now(timezone.utc) - timedelta(weeks=i)
        end = start + timedelta(weeks=1)
        query = ("SELECT AVG(bprs_score) as avg_score, COUNT(*) as n FROM checkins "
                 "WHERE tenant_id = ? AND created_at >= ? AND created_at < ?")
        params = [tenant_id, start.isoformat(), end.isoformat()]
        if site_code:
            query += " AND site_code = ?"
            params.append(site_code)
        row = execute_read(query, tuple(params), one=True)
        result.append({
            "week_start": start.date().isoformat(),
            "average_bprs_score": round(row["avg_score"], 2) if row["avg_score"] is not None else None,
            "sample_size": row["n"],
        })
    return result
