"""
app/fatigue_engine.py — محرك الإرهاق المخصص (Fatigue Engine)

لماذا محرك منفصل عن psychosocial_risks.py؟
-------------------------------------------
خطر "السلوكيات الضارة والإرهاق" في psychosocial_risks.py هو أحد
المخاطر الثمانية النفسية-الاجتماعية (مصدره BPRS). هذا الملف مختلف
الغرض: محرك **فيزيولوجي/تشغيلي** مركّز حصراً على عوامل الإرهاق التي
تحدّدها API RP 755 (ساعات العمل، النوم، المناوبات، تراكم الدورة) بمعزل
عن الاستبيان النفسي الذاتي — ويضيف بُعداً لم يكن موجوداً من قبل: **تراكم
الإرهاق عبر الزمن لكل عامل على حدة** (متوسط متحرك)، لا لحظة واحدة معزولة.

المدخلات
--------
- hours_worked_last_24h  (من RotationContext الموجود، بلا تكرار)
- is_night_shift          (من RotationContext الموجود)
- day_in_rotation_cycle    (من RotationContext الموجود — يُستخدم أيضاً
  كمقياس مباشر لعدد أيام العمل المتتالية ضمن الدورة الحالية، لأن دورة
  28/28 تعني أن day_in_rotation_cycle = عدد أيام العمل المتتالية حتى
  الآن في هذه الدورة، بلا حاجة لحقل جديد منفصل)
- sleep_hours_last_24h     (⚠️ حقل اختياري جديد — عدد ساعات النوم
  الفعلية. إن لم يُرسَله العميل، يُقدَّر تقريبياً من sleep_disruption
  الموجود أصلاً في BprsInputs عبر estimate_sleep_hours()، ويُعلَّم
  الناتج صراحة is_estimated=True حتى لا يُعامَل كقياس فعلي)

⚠️ إخلاء مسؤولية: هذا محرك فحص تشغيلي وقائي (Screening)، وليس نظام
إدارة إرهاق طبي (FRMS) معتمد رسمياً. راجع COMPLIANCE_MAPPING.md.
"""

from dataclasses import dataclass
from typing import Optional

from .bprs_engine import RotationContext, RiskLevel, _classify

LEVEL_LABEL_AR = {
    RiskLevel.GREEN: "أخضر", RiskLevel.YELLOW: "أصفر",
    RiskLevel.ORANGE: "برتقالي", RiskLevel.RED: "أحمر",
}


def estimate_sleep_hours(sleep_disruption: float) -> float:
    """تقدير تقريبي فقط عندما لا يُرسِل العميل ساعات نوم فعلية — علاقة
    خطية بسيطة موثّقة كتقدير لا قياس: 0=نوم ممتاز (~8 ساعات)،
    10=اضطراب شديد (~3 ساعات). هذا ليس قياساً سريرياً."""
    return max(3.0, 8.0 - (sleep_disruption * 0.5))


@dataclass(frozen=True)
class FatigueScore:
    score: float
    level: RiskLevel
    level_label_ar: str
    reasons: list
    sleep_hours_used: float
    sleep_hours_is_estimated: bool
    rolling_average_7d: Optional[float] = None
    rolling_sample_size: int = 0
    trend_direction: Optional[str] = None  # 'rising' | 'stable' | 'falling' | None


def compute_instant_fatigue(ctx: RotationContext, sleep_hours_last_24h: Optional[float],
                             sleep_disruption_fallback: Optional[float] = None) -> FatigueScore:
    """درجة إرهاق لحظية واحدة (نبضة واحدة) — 0 إلى 100، بنفس عتبات
    التصنيف المستخدمة في بقية المشروع (30/55/75)."""
    reasons = []
    score = 0.0

    is_estimated = sleep_hours_last_24h is None
    if is_estimated:
        fallback = sleep_disruption_fallback if sleep_disruption_fallback is not None else 5.0
        sleep_hours = estimate_sleep_hours(fallback)
        reasons.append("ساعات النوم مُقدَّرة تقريبياً من مؤشر اضطراب النوم الذاتي — لم تُرسَل ساعات فعلية")
    else:
        sleep_hours = sleep_hours_last_24h

    # عامل ساعات النوم — API RP 755 وأدبيات الإرهاق تعتبر أقل من 6
    # ساعات نوم متواصلة عامل خطر مباشر لتراجع اليقظة
    if sleep_hours < 4:
        score += 35
        reasons.append(f"{sleep_hours:.1f} ساعة نوم فقط خلال 24 ساعة — عتبة حرجة")
    elif sleep_hours < 6:
        score += 20
        reasons.append(f"{sleep_hours:.1f} ساعة نوم — أقل من الحد الأدنى الموصى به (6 ساعات)")
    elif sleep_hours < 7:
        score += 8

    # عامل ساعات العمل — نفس عتبة API RP 755 المستخدمة في بقية المشروع
    if ctx.hours_worked_last_24h > 14:
        score += 30
        reasons.append(f"{ctx.hours_worked_last_24h:.1f} ساعة عمل خلال 24 ساعة — تجاوز خطير لعتبة API RP 755")
    elif ctx.hours_worked_last_24h > 12:
        score += 18
        reasons.append(f"{ctx.hours_worked_last_24h:.1f} ساعة عمل خلال 24 ساعة — يتجاوز عتبة API RP 755")

    # المناوبة الليلية — عامل خطر مستقل موثّق في أدبيات الإرهاق الفيزيولوجي
    if ctx.is_night_shift:
        score += 12
        reasons.append("مناوبة ليلية — اضطراب الساعة البيولوجية")

    # أيام العمل المتتالية ضمن دورة 28/28 (day_in_rotation_cycle يُستخدم
    # مباشرة كمقياس عدد أيام العمل المتتالية، لا حقل منفصل)
    if ctx.day_in_rotation_cycle >= 25:
        score += 20
        reasons.append(f"اليوم {ctx.day_in_rotation_cycle}/28 — قرب نهاية الدورة، تراكم إرهاق موثّق ميدانياً")
    elif ctx.day_in_rotation_cycle >= 18:
        score += 10
        reasons.append(f"اليوم {ctx.day_in_rotation_cycle}/28 — منتصف الدورة المتأخر")

    score = max(0.0, min(100.0, score))
    level = _classify(score)

    return FatigueScore(
        score=round(score, 1), level=level, level_label_ar=LEVEL_LABEL_AR[level],
        reasons=reasons, sleep_hours_used=round(sleep_hours, 1), sleep_hours_is_estimated=is_estimated,
    )


def blend_with_rolling_average(instant: FatigueScore, past_scores_desc: list) -> FatigueScore:
    """past_scores_desc: درجات الإرهاق اللحظية للسبع نبضات الأخيرة لنفس
    العامل (الأحدث أولاً)، لا تشمل النبضة الحالية. يُضيف متوسطاً متحركاً
    واتجاهاً (تراكم عبر الزمن)، دون تعديل الدرجة اللحظية نفسها — العرض
    فقط هو من يميّز بين الاثنين."""
    if not past_scores_desc:
        return instant

    window = past_scores_desc[:7]
    rolling_avg = round(sum(window) / len(window), 1)

    trend = "stable"
    if len(window) >= 2:
        recent_half = window[:max(1, len(window) // 2)]
        older_half = window[max(1, len(window) // 2):]
        recent_avg = sum(recent_half) / len(recent_half)
        older_avg = sum(older_half) / len(older_half) if older_half else recent_avg
        if recent_avg - older_avg > 8:
            trend = "rising"
        elif older_avg - recent_avg > 8:
            trend = "falling"

    return FatigueScore(
        score=instant.score, level=instant.level, level_label_ar=instant.level_label_ar,
        reasons=instant.reasons, sleep_hours_used=instant.sleep_hours_used,
        sleep_hours_is_estimated=instant.sleep_hours_is_estimated,
        rolling_average_7d=rolling_avg, rolling_sample_size=len(window), trend_direction=trend,
    )
