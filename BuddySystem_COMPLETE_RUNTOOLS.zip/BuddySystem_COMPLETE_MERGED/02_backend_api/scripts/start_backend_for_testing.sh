#!/usr/bin/env bash
# =============================================================================
# start_backend_for_testing.sh — يُشغَّل على جهازك أنت، في نافذة طرفية منفصلة
# تبقى مفتوحة طوال اختبار Flutter/PWA/الموقع. يطبع عنوان IP المحلي الذي
# يجب وضعه في lib/services/sync_config.dart عند الاختبار على جهاز Android
# حقيقي (لا محاكي) متصل بنفس شبكة Wi-Fi.
#
# الاستخدام:
#   chmod +x scripts/start_backend_for_testing.sh
#   ./scripts/start_backend_for_testing.sh
#
# لبدء قاعدة بيانات نظيفة (بدون بيانات اختبار سابقة):
#   ./scripts/start_backend_for_testing.sh --fresh
# =============================================================================

set -euo pipefail
cd "$(dirname "$0")/.."   # يضمن التشغيل من جذر 02_backend_api بغض النظر عن مكان الاستدعاء

if [[ ! -f "app/server.py" ]]; then
  echo "✗ شغّل هذا السكربت من داخل 02_backend_api أو اتركه بمكانه — لم يُعثر على app/server.py"
  exit 1
fi

if [[ "${1:-}" == "--fresh" ]]; then
  echo "▶ حذف قاعدة بيانات الاختبار السابقة (buddy_system.db) لبدء نظيف..."
  rm -f buddy_system.db buddy_system.db-shm buddy_system.db-wal
fi

echo "▶ عناوين IP المحلية على هذا الجهاز (اختر ما يطابق شبكة الـWi-Fi التي سيتصل بها هاتف Android الحقيقي):"
if command -v ipconfig &>/dev/null; then
  ipconfig getifaddr en0 2>/dev/null || true   # macOS Wi-Fi الشائع
elif command -v ip &>/dev/null; then
  ip -4 addr show scope global | grep -oP '(?<=inet\s)\d+(\.\d+){3}' || true
else
  hostname -I 2>/dev/null || true
fi
echo ""
echo "  → إن ظهر مثلاً 192.168.1.50، ضع في lib/services/sync_config.dart:"
echo "      static const String apiBaseUrl = 'http://192.168.1.50:8000';"
echo "  → لمحاكي Android فقط (لا جهاز حقيقي)، القيمة الافتراضية 'http://10.0.2.2:8000' تبقى صحيحة كما هي، تجاهل ما سبق."
echo ""
echo "▶ تشغيل الخادم على 0.0.0.0:8000 (يستقبل من الشبكة المحلية كاملة، لا 127.0.0.1 فقط)..."
echo "  مفتاح API الافتراضي للاختبار: pilot-demo-key-2026"
echo "  مفتاح الإدارة الافتراضي: founder-admin-key-2026"
echo "  اترك هذه النافذة مفتوحة طوال الاختبار — أوقفها بـ Ctrl+C عند الانتهاء."
echo ""

python3 -m app.server
