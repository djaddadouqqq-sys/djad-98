#!/usr/bin/env bash
# =============================================================================
# run_flutter_pipeline.sh — يُشغَّل على جهازك أنت (macOS أو Linux)، لا في أي
# بيئة سحابية بلا Flutter SDK. هذا السكربت لم يُنفَّذ من طرف Claude — لا
# يوجد Flutter SDK ولا اتصال شبكة صادر في بيئة العمل التي بُني فيها هذا
# المشروع (موثَّق صراحة في MASTER_README.md §4.6). أنت أول من يُشغّله فعلياً.
#
# ما يفعله بالترتيب، ويتوقف فوراً عند أول خطوة تفشل (set -e):
#   1) يتحقق من وجود Flutter SDK ويطبع نسخته
#   2) flutter pub get          — تنزيل الاعتماديات
#   3) dart run build_runner build --delete-conflicting-outputs
#      — توليد Hive adapters فعلياً (pub get وحده لا يولّدها)
#   4) flutter analyze          — يكشف أي خطأ نحوي فاتته المراجعة اليدوية
#   5) flutter test             — يُشغّل test/bprs_engine_test.dart فعلياً
#   6) يسرد الأجهزة/المحاكيات المتصلة ويطلب منك اختيار واحد
#   7) flutter run -d <device>  — تشغيل حقيقي على الجهاز المُختار
#
# الاستخدام:
#   chmod +x scripts/run_flutter_pipeline.sh
#   ./scripts/run_flutter_pipeline.sh
#
# لبناء APK فقط دون تشغيل مباشر (مفيد لتثبيت يدوي لاحق عبر adb install):
#   ./scripts/run_flutter_pipeline.sh --build-only
# =============================================================================

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
LOG_DIR="./pipeline_logs"
mkdir -p "$LOG_DIR"
TS="$(date +%Y%m%d_%H%M%S)"

step() { echo -e "\n${BLUE}▶ $1${NC}"; }
ok()   { echo -e "${GREEN}✓ $1${NC}"; }
warn() { echo -e "${YELLOW}⚠ $1${NC}"; }
fail() { echo -e "${RED}✗ $1${NC}"; exit 1; }

BUILD_ONLY=false
[[ "${1:-}" == "--build-only" ]] && BUILD_ONLY=true

# --- 0) التأكد أننا داخل مجلد Flutter الصحيح ---
if [[ ! -f "pubspec.yaml" ]] || ! grep -q "^name: buddy_system" pubspec.yaml; then
  fail "شغّل هذا السكربت من داخل مجلد 01_flutter_mobile_app نفسه (حيث يوجد pubspec.yaml)."
fi

# --- 1) التحقق من Flutter SDK ---
step "1/7 — التحقق من Flutter SDK"
if ! command -v flutter &>/dev/null; then
  fail "لم يُعثر على 'flutter' في PATH. ثبّته أولاً: https://docs.flutter.dev/get-started/install"
fi
flutter --version | tee "$LOG_DIR/00_flutter_version_$TS.log"
ok "Flutter SDK موجود"

step "1b/6 — flutter doctor (تشخيص شامل للبيئة، Android toolchain خصوصاً)"
flutter doctor -v | tee "$LOG_DIR/00_flutter_doctor_$TS.log"
warn "راجع الأسطر أعلاه يدوياً — أي علامة [✗] بجانب Android toolchain تعني أن التشغيل على جهاز Android لن ينجح حتى تُصلَح"

# --- 2) pub get + build_runner ---
step "2/7 — flutter pub get (تنزيل الاعتماديات)"
flutter pub get 2>&1 | tee "$LOG_DIR/01_pub_get_$TS.log"

step "3/7 — dart run build_runner build --delete-conflicting-outputs (توليد Hive adapters فعلياً)"
dart run build_runner build --delete-conflicting-outputs 2>&1 | tee "$LOG_DIR/01b_build_runner_$TS.log"
if [[ ! -f "lib/models/daily_checkin.g.dart" ]] || [[ ! -f "lib/models/anonymous_report.g.dart" ]]; then
  fail "ملفات Hive generated غير موجودة بعد build_runner."
fi
ok "Hive adapters generated موجودة"

# --- 4) flutter analyze ---
step "4/7 — flutter analyze (يكشف أي خطأ نحوي/نوعي فاتته المراجعة اليدوية في هذه الجلسة)"
set +e
flutter analyze 2>&1 | tee "$LOG_DIR/02_analyze_$TS.log"
ANALYZE_EXIT=${PIPESTATUS[0]}
set -e
if [[ $ANALYZE_EXIT -ne 0 ]]; then
  fail "flutter analyze وجد أخطاء — راجع $LOG_DIR/02_analyze_$TS.log قبل المتابعة. لا تتجاهل هذه الخطوة."
fi
ok "لا أخطاء نحوية/نوعية"

# --- 5) flutter test ---
step "5/7 — flutter test (تشغيل فعلي لـ test/bprs_engine_test.dart)"
set +e
flutter test 2>&1 | tee "$LOG_DIR/03_test_$TS.log"
TEST_EXIT=${PIPESTATUS[0]}
set -e
if [[ $TEST_EXIT -ne 0 ]]; then
  fail "flutter test فشل — راجع $LOG_DIR/03_test_$TS.log. لا تُكمل للتشغيل الفعلي قبل إصلاح هذا."
fi
ok "كل اختبارات Dart نجحت فعلياً (أول تنفيذ حقيقي لها منذ كتابتها)"

# --- 6) اختيار الجهاز ---
step "6/7 — الأجهزة/المحاكيات المتصلة"
flutter devices | tee "$LOG_DIR/04_devices_$TS.log"
DEVICE_COUNT=$(flutter devices --machine 2>/dev/null | python3 -c "import json,sys; print(len(json.load(sys.stdin)))" 2>/dev/null || echo "0")
if [[ "$DEVICE_COUNT" == "0" ]]; then
  fail "لا جهاز/محاكي متصل. وصّل هاتف Android حقيقي (مع تفعيل USB debugging) أو شغّل محاكياً عبر Android Studio ثم أعد المحاولة."
fi

echo ""
read -rp "أدخل معرّف الجهاز (device id) من القائمة أعلاه: " DEVICE_ID
[[ -z "$DEVICE_ID" ]] && fail "لم تُدخل معرّف جهاز."

# --- 5b) تنبيه بخصوص عنوان الخادم قبل التشغيل ---
warn "قبل المتابعة — تحقّق من lib/services/sync_config.dart:"
warn "  - محاكي Android:  apiBaseUrl = 'http://10.0.2.2:8000'  (القيمة الافتراضية الحالية، صحيحة كما هي)"
warn "  - جهاز Android حقيقي على نفس شبكة Wi-Fi: استبدلها بعنوان IP الفعلي لجهازك الذي يُشغِّل الخادم، مثال 'http://192.168.1.50:8000'"
warn "  - تأكد أن 02_backend_api/app/server.py يعمل فعلاً قبل المتابعة (شغّل ../02_backend_api/scripts/start_backend_for_testing.sh في نافذة طرفية أخرى)"
read -rp "اضغط Enter للمتابعة بعد التأكد من الخادم وعنوان الشبكة..." _

# --- 6) build أو run ---
if $BUILD_ONLY; then
  step "7/7 — flutter build apk --debug"
  flutter build apk --debug 2>&1 | tee "$LOG_DIR/05_build_$TS.log"
  ok "APK جاهز: build/app/outputs/flutter-apk/app-debug.apk — ثبّته يدوياً عبر: adb install -r build/app/outputs/flutter-apk/app-debug.apk"
else
  step "7/7 — flutter run -d $DEVICE_ID (تشغيل حقيقي — راقب الطرفية لأي أخطاء وقت التشغيل)"
  flutter run -d "$DEVICE_ID" 2>&1 | tee "$LOG_DIR/05_run_$TS.log"
fi

echo ""
ok "انتهى السكربت الآلي. الخطوة التالية يدوية بالكامل: نفّذ سيناريو الاختبار الكامل"
ok "الموصوف في FULL_SYSTEM_INTEGRATION_TEST_GUIDE.md (Login → Check-in → BPRS → المخاطر → Fatigue → Buddy → Offline → Sync)"
echo -e "${BLUE}كل السجلات محفوظة في: $LOG_DIR/${NC}"
