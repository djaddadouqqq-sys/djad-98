#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

echo '=== Flutter toolchain ==='
flutter --version
dart --version

echo '=== Dependencies ==='
flutter pub get

echo '=== Hive code generation ==='
dart run build_runner build --delete-conflicting-outputs

test -s lib/models/daily_checkin.g.dart
test -s lib/models/anonymous_report.g.dart

echo '=== Analyze ==='
flutter analyze

echo '=== Tests ==='
flutter test

echo '=== Gradle wrapper ==='
if [ ! -s android/gradle/wrapper/gradle-wrapper.jar ]; then
  echo 'gradle-wrapper.jar missing. Generate it with: (cd android && gradle wrapper --gradle-version 8.6 --distribution-type all)'
  exit 2
fi

echo '=== Android debug APK ==='
flutter build apk --debug

echo '=== SUCCESS ==='
echo "APK: build/app/outputs/flutter-apk/app-debug.apk"
