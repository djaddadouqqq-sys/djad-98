$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')

Write-Host '=== Flutter toolchain ==='
flutter --version
dart --version

Write-Host '=== Dependencies ==='
flutter pub get

Write-Host '=== Hive code generation ==='
dart run build_runner build --delete-conflicting-outputs

if (!(Test-Path 'lib/models/daily_checkin.g.dart')) { throw 'Missing daily_checkin.g.dart after build_runner.' }
if (!(Test-Path 'lib/models/anonymous_report.g.dart')) { throw 'Missing anonymous_report.g.dart after build_runner.' }

Write-Host '=== Analyze ==='
flutter analyze
Write-Host '=== Tests ==='
flutter test

Write-Host '=== Gradle wrapper ==='
$wrapperJar = 'android/gradle/wrapper/gradle-wrapper.jar'
if (!(Test-Path $wrapperJar)) {
  throw 'gradle-wrapper.jar is missing. Generate it with: Set-Location android; gradle wrapper --gradle-version 8.6 --distribution-type all'
}

Write-Host '=== Android debug APK ==='
flutter build apk --debug
Write-Host '=== SUCCESS ==='
Write-Host 'APK: build/app/outputs/flutter-apk/app-debug.apk'
