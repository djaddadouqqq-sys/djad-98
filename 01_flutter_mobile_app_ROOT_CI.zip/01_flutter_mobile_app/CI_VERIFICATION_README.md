# Real Flutter/Android verification

This project cannot honestly claim a working APK from static inspection alone.
The authoritative verification path is the GitHub Actions workflow:

`.github/workflows/flutter_android_ci.yml`

It runs, in order:

1. Flutter/Dart/Java toolchain verification.
2. `flutter pub get`.
3. Hive adapter generation with `dart run build_runner build --delete-conflicting-outputs`.
4. Verification that both generated adapters exist.
5. `flutter analyze`.
6. `flutter test`.
7. Real Gradle wrapper generation if `gradle-wrapper.jar` is absent.
8. `flutter build apk --debug`.
9. Upload of the resulting `app-debug.apk` as a CI artifact.

A green workflow is the evidence that the delivered Flutter/Android project can
compile and pass its automated checks in a real Flutter/Android environment.
A failed workflow must be treated as a real defect until fixed; no percentage
or completion claim should override a failing build/test.
